# Working with redSHOP Manufacturers

Manufacturers identify the companies or people responsible for products in your catalogue. They provide a way to group products by brand or maker, present manufacturer information on the storefront, and use manufacturer-based rules such as promotional discounts.

This guide covers manufacturer management, the current manufacturer editor, SEO, product associations, templates and storefront display.

## Open Manufacturer Management

1. Sign in to the Joomla administrator.
2. Open **Components → redSHOP**.
3. Open the **Manufacturers** management area from the product-related navigation.
4. Use the list to open an existing manufacturer or select **New**.

![Manufacturer listing](img/rs506-manufacturer-list.png)

A manufacturer does not automatically acquire products when it is created. Products must be assigned to it separately.

## Manufacturer listing

The manufacturer list is the central view for finding, editing and publishing manufacturer records.

The original redSHOP documentation describes a list with manufacturer names, publication state and actions for managing records. The current manufacturer form also exposes the name, email address, image, description and published status as data that can be used in administrator views.

### List actions

Depending on the permissions and available toolbar controls, manufacturer management supports the following actions:

| Action | Purpose |
| --- | --- |
| **New** | Create a manufacturer record. |
| **Edit** | Open a manufacturer to update its details. |
| **Copy** | Duplicate an existing manufacturer where the list provides this action. |
| **Delete** | Remove selected manufacturer records. |
| **Publish** | Set selected manufacturers to published. |
| **Unpublish** | Set selected manufacturers to unpublished. |
| **Check-in** | Release a record locked for editing. |

![Manufacturer toolbar](img/rs506-manufacturer-toolbar.png)

Before deleting a manufacturer, check the products assigned to it and any menu links or promotional rules referring to it. Copying a manufacturer is useful when records share common settings, but review the new name, contact information and SEO values before publication.

## Create a manufacturer

1. Select **New**.
2. Enter the **Manufacturer Name**.
3. Choose a **Manufacturer Template**.
4. Upload or select a **Manufacturer Image**, if desired.
5. Enter the manufacturer's email address and website URL, where relevant.
6. Set **Products per Page**.
7. Choose **Published** or **Unpublished**.
8. Enter a useful **Description**.
9. Review the SEO fields.
10. Save and verify the record in the manufacturer list.

![Manufacturer editor](img/rs506-manufacturer-editor.png)

### Manufacturer Name

The name displayed for the manufacturer. This field is required in the current manufacturer form. Use the official brand or manufacturer name consistently.

### Manufacturer Template

Choose the template used to display the manufacturer. The current form requires a template selection and offers templates from the `manufacturer_products` and `manufacturer_detail` sections.

A template can determine how the manufacturer's products, description and image are presented. Test the selected template on the storefront.

### Manufacturer Image

The current editor uses redSHOP's media control to select or upload a manufacturer image. The image may appear on manufacturer lists or detail pages, depending on the active template.

Use a clear image or logo with enough resolution for the intended display. Check cropping, aspect ratio and accessibility text after saving.

### Manufacturer Email

Optional email address associated with the manufacturer. The current field uses email validation.

redSHOP's global manufacturer configuration includes an option relating to manufacturer notifications. Entering an address alone does not guarantee that the manufacturer receives messages: notification settings and the relevant order workflow must also be configured.

### Manufacturer URL

Optional website URL for the manufacturer. The current field uses URL validation. Enter a complete website address and test the resulting link if your storefront template displays it.

### Products per Page

The number of products displayed on each page of a manufacturer product listing. The current form defaults this value to `12` for new records.

For example, a manufacturer with 30 products and a page size of 12 may require three pages. Actual pagination depends on the template and any additional list settings.

### Published

Controls the publication status of the manufacturer record. The current form defaults to **Yes** for new records.

If a manufacturer page is missing, check publication state, menu links, template selection and any access restrictions.

### Description

A rich-text description of the manufacturer. Include information useful to customers, such as what the manufacturer produces or how its products differ from alternatives.

Avoid repeating the same generic marketing copy across every manufacturer page.

## Manufacturer SEO

![Manufacturer SEO](img/rs506-manufacturer-seo.png)

The current manufacturer form includes a dedicated SEO fieldset.

| Field | Purpose |
| --- | --- |
| **Page Title** | Intended browser/page title. |
| **Page Heading** | Heading displayed where the manufacturer template supports it. |
| **SEF URL** | Manufacturer-specific search-engine-friendly URL value. |
| **Meta Keywords** | Optional keyword metadata. Major search engines generally do not use this as a ranking signal. |
| **Meta Description** | Concise summary of the manufacturer page for metadata and potential search snippets. |
| **Meta Language Setting** | Language metadata value where supported. |
| **Meta Robot Info** | Search-engine crawling/indexing instructions. |

### Example

For a manufacturer named *Example Paper Co.*, you might use:

- **Page Title:** `Example Paper Co. – Paper and Print Materials`
- **Page Heading:** `Example Paper Co.`
- **Meta Description:** `Explore paper and print materials from Example Paper Co., including available sizes and finishes.`

After saving, open the manufacturer page and inspect the actual URL, heading and generated metadata. Search engines may display different titles or descriptions.

## Assign products to a manufacturer

Manufacturer records and product records are linked through product management.

1. Open **Products** in the redSHOP administrator.
2. Edit an existing product or create a new one.
3. Locate the **Manufacturer** selection in **Product Information**.
4. Choose the manufacturer.
5. Save the product.
6. Open the manufacturer page and check that the product appears.

![Product manufacturer assignment](img/rs506-manufacturer-product-assignment.png)

The current product editor includes a manufacturer selector. If a product does not appear on the manufacturer page, confirm that the product and manufacturer are published and that the active template displays products.

### Assigning multiple products

When updating a large catalogue, consider the shop's supported import/export workflow or available bulk-editing tools. Test a small set of records first and verify that existing manufacturer assignments are not unintentionally replaced.

## Manufacturer-based discounts

The original redSHOP manual describes using manufacturers as a selection criterion for mass discounts.

A typical workflow is:

1. Open **Mass Discounts** in redSHOP.
2. Create a new discount rule.
3. Enter the discount name, type, amount and active period.
4. Select the manufacturer or manufacturers to which the rule applies.
5. Save the rule.
6. Test an eligible product and a product from a different manufacturer.

![Manufacturer mass discount](img/rs506-manufacturer-discount.png)

For example, a 15% promotion for one manufacturer should apply only to products that satisfy the rule's eligibility conditions. Verify how the promotion interacts with product-level discounts, shopper-group prices and tax.

Discount management is separate from manufacturer editing. Do not expect to configure the entire promotion inside the manufacturer record.

## Page access and storefront visibility

The historical documentation discusses access and SEO as part of manufacturer setup. Actual storefront visibility depends on publication state, menu assignments, product availability and any access rules configured in Joomla or redSHOP.

To test a manufacturer page:

1. Publish the manufacturer.
2. Assign at least one published product.
3. Create or locate a frontend route to the manufacturer view.
4. Visit the page while signed out.
5. Repeat with an appropriate shopper-group account if access restrictions are used.
6. Check the displayed manufacturer information and products.

Do not treat a hidden navigation link as a security restriction.

## Manufacturer templates and tags

Manufacturer templates determine how manufacturer information appears. The current manufacturer form offers template selections from manufacturer detail and manufacturer products template sections.

The original redSHOP documentation also discusses template tags for displaying manufacturer details and manufacturer names on product pages.

When editing templates:

1. Identify whether the template is a manufacturer detail, manufacturer products or product detail template.
2. Use tags supported by that template type.
3. Save the template.
4. Open the corresponding storefront page and verify the output.
5. Check desktop and mobile layouts.

A manufacturer image, description or website URL will not necessarily appear unless the active template includes the corresponding output.

### Display the manufacturer name on a product page

The historical documentation describes adding manufacturer information to product details through product-template output.

To display a manufacturer's name, ensure the product has a manufacturer assigned and use the manufacturer output supported by the active product detail template. Test the result with products that do and do not have a manufacturer.

## Show manufacturers on the storefront

![Manufacturer storefront](img/rs506-manufacturer-frontend.png)

Manufacturer pages can be exposed through supported redSHOP menu item types or links from product and manufacturer templates.

A practical workflow is:

1. Create and publish the manufacturer.
2. Assign products.
3. Open **Menus** in the Joomla administrator.
4. Create a menu item using the relevant redSHOP manufacturer view, if available.
5. Select the manufacturer or manufacturer listing as required.
6. Save and publish the menu item.
7. Open the frontend and check the layout, products and navigation.

The available menu item names depend on the installed redSHOP version and menu-view configuration.

## Global manufacturer configuration

The manufacturer record controls settings for one manufacturer. The global **Manufacturers** configuration area provides shop-wide defaults such as sorting, title truncation, notification settings, watermarking and image dimensions.

See [Manufacturers in Global Configuration](../global-configuration/manufacturers.md).

## Troubleshooting

### A manufacturer does not appear on the storefront

Check publication status, menu links, the chosen template and whether the page requires assigned products.

### Products are missing from the manufacturer page

Confirm that each product is published and assigned to the correct manufacturer. Check category, shopper-group and other product visibility restrictions.

### The manufacturer logo is missing

Check the selected image, the media record and the active manufacturer template. Image dimensions or cached thumbnails may also affect the display.

### The wrong template is used

Check the manufacturer-specific template selection and the global manufacturer default. Verify that the chosen template belongs to the intended manufacturer view.

### Manufacturer emails are not received

Check the email address, global manufacturer notification settings and Joomla mail delivery. Test with a safe account and review the relevant notification workflow.

### A manufacturer discount is not applied

Check the selected manufacturer, discount period, product eligibility, shopper group and other active pricing rules.

## Related documentation

- [Product Management overview](overview-product-management.md)
- [Working with Products](products-redshop.md)
- [Manufacturer configuration](../global-configuration/manufacturers.md)
- [Price Management](price-management.md)
