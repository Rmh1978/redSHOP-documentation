# Working with Products in redSHOP

redSHOP Product Management is used to create and maintain the items offered in your online shop. A product can be a physical item, a downloadable file or another supported product type. Product records bring together catalogue information, prices, categories, images, stock, attributes, related products, SEO settings and optional integrations.

This guide covers the product list, product editing, product-specific pricing and discounts. Some advanced features appear only when the relevant functionality is enabled.

## Open Product Management

1. Sign in to the Joomla administrator.
2. Open **Components → redSHOP**.
3. Select **Products → Product Management** or the corresponding product list entry.
4. Use the product list to find an existing product or select **New**.

![Product management list](img/rs506-product-list.png)

## Product listing

The product list is the central place for finding, publishing and organizing existing products.

The historical redSHOP product listing includes these columns or controls:

| Column | Purpose |
| --- | --- |
| **Product Name** | Name displayed on the storefront and used to open the product editor. |
| **Product Number** | Unique product identifier or SKU. |
| **Price** | Current product price in the shop's configured currency. |
| **Media** | Associated images and files; may provide a shortcut to media management. |
| **Wrapping Management** | Wrapping options associated with the product, where supported. |
| **Number of Views** | Recorded product page views. |
| **Category** | Categories assigned to the product. |
| **Manufacturer** | Manufacturer associated with the product. |
| **Customer Reviews** | Review-management shortcut where supported. |
| **Published** | Product publication status. |

The precise columns and shortcuts depend on the current administrator view and its customization.

### Product list actions

![Product list actions](img/rs506-product-list-actions.png)

- **New** — create a product.
- **Edit** — open the selected product.
- **Copy** — duplicate selected product records.
- **Delete** — remove selected products; review orders, integrations and category assignments first.
- **Publish / Unpublish** — change the publication status.
- **Check-in** — release records locked for editing.
- **Assign New Category** — assign selected products to additional categories in bulk, where available.
- **Remove Category** — remove category assignments from selected products in bulk, where available.

When copying a product, review its number, price, images, attributes, category assignments and related settings before publishing the copy.

### Bulk category assignment

1. Select the products in the product list.
2. Choose **Assign New Category**.
3. Select the target category or categories.
4. Confirm the assignment.
5. Open a few affected products and verify the new category associations.

To remove category associations, use **Remove Category** and verify that no product is unintentionally left without a suitable category.

## Product Price Management

![Product price management](img/rs506-product-price-management.png)

The original redSHOP price-management screen provides a way to review and update prices across multiple products.

| Field | Purpose |
| --- | --- |
| **Product Name** | Identifies the product being priced. |
| **Product Number** | SKU or other product identifier. |
| **Price** | Standard product price. |
| **Discount Price** | Promotional or discounted price, where configured. |
| **Shopper-group / quantity price control** | Opens additional price settings for specific shopper groups and quantity ranges, where supported. |
| **Save** | Saves edited price values. |

### Search and filter products

Use the search box to locate products by name, number or other available search criteria. Some versions offer a separate search-field selector, such as name, product number or category.

### Shopper-group and quantity pricing

Different prices can be configured for customers in particular shopper groups or for orders within a quantity range.

For example, a product can have a standard price for ordinary shoppers and a different price for a wholesale shopper group purchasing a specified quantity.

When configuring these rules, verify the quantity boundaries, shopper-group membership, tax calculation and any competing discount rules. Test at the minimum and maximum quantities as well as just outside the range.

## Create a product

![Product editor](img/rs506-product-editor.png)

1. Select **New** in Product Management.
2. Enter the **Product Name** and a unique **Product Number**.
3. Select one or more **Product Categories**.
4. Choose the appropriate **Product Type** and **Product Template**.
5. Set the standard price and relevant tax group.
6. Configure the product's publication status.
7. Add its description, main image and other information.
8. Review any product-type-specific options.
9. Save the product.
10. Open the storefront product page and check the information before taking real orders.

The current product editor validates product numbers against existing product records. Use a consistent SKU convention, especially when importing or synchronizing products.

## Product Information

![Product information](img/rs506-product-information.png)

### Product Name

The customer-facing name of the product. Choose a name that distinguishes it from similar products without relying solely on the SKU.

### Product Number

A unique product identifier. It can be a model number or stock-keeping unit. This is particularly important for stock management, imports, reporting and external systems.

### Product Category

Choose the categories in which the product belongs. A product may appear in multiple categories. Check how category restrictions, discounts and shipping rules apply when doing so.

### Product Type

Select the type that matches how the product is sold and fulfilled. Different product types can expose additional options for downloadable products, subscriptions or other features.

### Product Template

Select the storefront template used to display the product. A product-specific template can take precedence over the global default.

### Manufacturer

Assign the manufacturer where relevant. This can support manufacturer pages and manufacturer-based product discovery.

### Published

Choose whether the product should be available in published storefront views. A published product may still be affected by stock, access or other shop rules.

### Product Price

Enter the product's normal price. The field uses the configured shop currency symbol and formatting. Review the shop's tax configuration to understand whether prices are stored and displayed with or without tax.

### Product Tax Group

Choose the tax group appropriate for the product. Tax treatment can depend on the customer, destination and tax configuration; test representative orders.

### Discount Price

Set a product-level discounted price where appropriate. Confirm how this interacts with other promotions and shopper-group prices.

### Discount Start Date and End Date

The current product editor includes start and end date controls for product discounts. Use them to define a promotional period and check the result before, during and after the scheduled dates.

The date format and timezone depend on the site's configuration. For time-sensitive promotions, verify the storefront behaviour rather than relying only on the displayed dates.

### Other product information

Depending on the installed configuration, Product Information can also include descriptions, publication-related settings, stock, dimensions, product tags, availability, ordering and other catalogue fields.

When creating physical goods, ensure the dimensions, weight and stock settings are appropriate for the shipping and fulfilment workflow.

## Product Types

![Product type options](img/rs506-product-types.png)

The product-type editor includes settings for supported special product types. In the current source, downloadable-product settings are shown when the product is a file or download is enabled.

### Downloadable products

Download-related settings can include:

- Whether downloading is enabled.
- Whether the number of downloads is unlimited.
- Limits for downloading when unlimited access is not enabled.
- Other delivery and file-related options associated with the selected product type.

Before selling a digital file, test the entire purchase and delivery workflow with a test account. Verify that the buyer receives the intended download access and that direct access to protected files is not possible without authorization.

### Subscriptions

The product-type implementation also contains subscription and renewal-related functionality. Subscription behaviour depends on the configured product, renewal rules and payment support.

Test first purchase, renewal, expiry and cancellation behaviour with safe test accounts before offering a subscription commercially.

### Serial numbers and other product types

The product-type implementation contains serial-number-related data. If your product requires serial delivery or activation, verify how serial numbers are stored, allocated and communicated to customers.

## Custom Fields

Custom fields extend the information collected or displayed for products.

1. Create a custom field for the relevant product context.
2. Configure its type and available options.
3. Open the product and enter its custom-field values.
4. Ensure the active product template renders the relevant fields.
5. Check the product page and any checkout or order details that depend on the values.

Custom fields should not be confused with product attributes: attributes can represent customer-selectable product options, while custom fields may be used for additional product information or customer input.

![Product custom fields](img/rs506-product-custom-fields.png)

## Product Images and Media

![Product images](img/rs506-product-images.png)

Products can have a main image and additional images or files. The current product editor retrieves product media and identifies published additional image media.

### Main product image

Choose a clear, sufficiently high-resolution image that accurately represents the product. Check how it is cropped or resized in product listings and on the product detail page.

### Other images

Use additional images to show details, variations, packaging or examples of the product in use. The active template determines whether they appear as thumbnails, a gallery or another layout.

### Other media

redSHOP's media management can associate other media with products, depending on the media type and template support. Keep files organized and ensure that any customer-downloadable files follow the shop's download-access rules.

### Image troubleshooting

If an image does not appear, check that it is assigned to the correct product, published where necessary and supported by the active template. Thumbnail dimensions and cached image versions can also affect the result.

## Product Attributes and Properties

![Product attributes](img/rs506-product-attributes.png)

Attributes allow products to offer selectable options. Examples include size, finish, colour or material.

The current editor supports adding attributes and selecting an **Attribute Set**. It also includes a control for copying attributes from an attribute set.

### Create an attribute

1. Open the product's **Product Attributes** section.
2. Select an attribute set if one already provides the required options, or choose to add an attribute.
3. Enter an attribute name, such as *Paper Finish*.
4. Add properties, such as *Matte* and *Glossy*.
5. Configure the display type, ordering and selection requirements where available.
6. Set any price adjustments for properties.
7. Save and inspect the product page.

### Property pricing

A property can add to or subtract from the product's base price. Verify the calculated price when several options are selected and when quantity discounts apply.

### Required and multiple selections

Attributes may offer required-selection and multiple-selection controls. Use required selections when the product cannot be ordered without choosing an option.

### Subproperties

The attribute editor includes subproperty-related functionality, including optional price, image and selection settings. Use this for products whose options have another level of selection, and test combinations carefully.

### Attribute sets

Attribute sets help reuse a common group of attributes across products. After copying or linking an attribute set, check that the product has the intended properties and price adjustments.

## Accessories and Related Products

![Accessories and related products](img/rs506-product-accessories.png)

### Accessory products

Accessories are optional additional products associated with the main product.

The current accessory editor includes:

| Field | Description |
| --- | --- |
| **Product Source** | Search for and select an accessory product. |
| **Product Name** | Name of the selected accessory. |
| **Normal Price** | The accessory's reference price. |
| **Sign / Operator** | Indicates whether a price adjustment adds or subtracts. |
| **Added Value** | Amount of the price adjustment. |
| **Ordering** | Position of the accessory in the list. |
| **Delete** | Removes the accessory association. |

To configure an accessory, search for the desired product, add it to the accessory list, set the price adjustment and ordering, then save and check the storefront.

For example, a printed poster might offer an optional hanging accessory.

### Related products

Related products are recommendations rather than options necessarily added to the same order. They can help customers discover complementary or alternative products.

Choose relevant products and verify that the active template renders the related-products section.

### Category-level accessories

Some redSHOP configurations also support accessories assigned through categories. Check the interaction between category-level and product-level accessories when both apply.

## redPRODUCTFINDER Association

The original redSHOP manual describes a **redPRODUCTFINDER Association** section used to associate products with a product-finder feature.

Where this integration is installed, configure the relevant associations and test the finder results on the storefront. Product-finder functionality may depend on an additional extension and its version.

## Product SEO

![Product SEO](img/rs506-product-seo.png)

Product-specific SEO fields can control metadata and other search-related information.

Common settings documented in redSHOP include:

- **SEO Page Title** — intended browser and search-result title.
- **SEO Page Heading** — heading displayed by supported product templates.
- **SEF URL** — product-specific friendly URL value.
- **SEO Keywords** — optional metadata keywords.
- **SEO Page Description** — concise description of the product page.
- **Meta Language** — language-related metadata where supported.
- **SEO Robot Info** — instructions for search-engine crawlers where supported.

Use a distinct title and description for each important product. After saving, check the generated URL, canonical behaviour, page heading and HTML metadata.

## Discount Calculator

![Product discount calculator](img/rs506-product-discount-calculator.png)

The **Discount Calculator** allows product-specific quantity or dimension-based pricing rules, depending on the configured calculator type.

The editor contains calculator-related controls in the current code. Available inputs and calculation behaviour depend on the product configuration.

For dimension-based products, verify:

1. Which unit is expected, such as square metres or another configured unit.
2. Whether the customer enters width and height.
3. How minimum and maximum values are handled.
4. How quantity affects the result.
5. Whether discounts are applied before or after other pricing adjustments.
6. How the final price appears in the cart and order.

For example, a product priced by area may require a different pricing table from a product priced by individual units. Test boundaries and decimal values rather than checking only one example.

## Economic Settings

The product editor contains an **Economic Settings** section for accounting-related integration values. These fields are relevant only if the corresponding integration is configured.

Check how the product is mapped to the external accounting system, including any account or product identifiers, before synchronizing real transactions.

## Payment Methods

![Product payment methods](img/rs506-product-payment-methods.png)

The current product editor includes **Use Individual Payment Method** and **Select Payment Method** controls.

Enable product-specific payment selection when a product should have a restricted set of payment options. Then choose the permitted payment methods.

Test checkout with the product by itself and in a cart containing other products. The resulting available payment methods can depend on how the shop combines product-level restrictions.

## Mass Discounts

![Mass discounts](img/rs506-product-mass-discounts.png)

Mass discounts can apply promotional rules across sets of products, categories or manufacturers, depending on the discount configuration.

The historical workflow is:

1. Open redSHOP's mass-discount management.
2. Create a discount.
3. Enter its name, type, value and validity dates.
4. Select the applicable products, categories or manufacturers.
5. Save the rule.
6. Test eligible and ineligible products.

For example, a 10% promotion may apply to all products in a selected category. If a product also has a product-level discount, verify which rule takes precedence.

## Product Price Discounts

![Product price discounts](img/rs506-product-price-discounts.png)

Product price discounts provide more specific price rules, including rules based on shopper groups and quantity ranges where supported.

### Product Price Discount listing

The original documentation describes a listing with product information, price rules and controls for adding, editing and removing entries.

### Add a price discount

1. Open the product price discount management screen.
2. Create a new price rule.
3. Select the product or product group.
4. Configure the eligible shopper group, quantity range and discount price as appropriate.
5. Set dates if the rule supports a validity period.
6. Save the rule.
7. Test the product as a customer in the selected shopper group.
8. Test another customer or quantity that should not qualify.

A shopper-group price should be verified both on the product page and in the cart. Always check tax and other discounts in the final checkout calculation.

## Publish and verify a product

Before offering a new product to customers, confirm the following:

- The product has a unique number, appropriate name and category.
- The selected template displays descriptions and images correctly.
- The standard price, tax and any discounts are correct.
- Required attributes are enforced and priced correctly.
- Stock or download fulfilment is configured.
- Accessories and related products behave as intended.
- SEO fields and the storefront URL are correct.
- Payment and shipping methods are available for a representative test order.

## Troubleshooting

### The product is missing from a category

Confirm that both the product and category are published, that the category assignment is correct, and that no access or filter rules hide the product.

### The price is unexpected

Check the base price, shopper group, quantity range, active discount dates, attribute price adjustments, tax settings and discount calculator.

### An attribute is not visible

Confirm that the attribute is saved, its properties are configured and the active product template renders the attribute controls.

### Images are missing

Check the main image, additional-media publication state, thumbnail configuration and template support.

### A download is unavailable

Verify the product type, download settings, file association, order/payment state and customer authorization.

### Checkout does not offer the expected payment method

Review the product's individual payment settings, enabled payment plugins and the other products in the cart.

## Related documentation

- [Product Management overview](overview-product-management.md)
- [Categories](../categories/redshop-categories.md)
- [Products in Global Configuration](../global-configuration/products.md)
- [Price Management](price-management.md)
- [Product Media](medias-redshop.md)
