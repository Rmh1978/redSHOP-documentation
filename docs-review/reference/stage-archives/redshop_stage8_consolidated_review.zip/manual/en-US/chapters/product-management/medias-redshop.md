# Working with Media in redSHOP

redSHOP Media Management lets administrators organize images and other media associated with products, categories, manufacturers, and product attribute properties. Media records identify the type of media, its section, the related item, and publication status. The storefront template determines which associated media are displayed.

## Open Media Management

1. Sign in to the Joomla administrator.
2. Open **Components → redSHOP → Media** (or the corresponding media navigation item).
3. Use the list to find an existing media record, or choose **New** to create one.

![Media list](img/rs506-media-list.png)

## Understand the media listing

The current media list is built in `component/admin/tmpl/media/default.php`. It includes the following columns:

| Column | Meaning |
| --- | --- |
| **Media Name** | File name or thumbnail preview for supported images. |
| **Media Type** | Media classification, such as an image or document. |
| **Product** | Name of the item associated with the media, where resolvable. |
| **Media Section** | The kind of item to which the record belongs. |
| **Media Alternative Text** | Text description associated with the media. |
| **Published** | Whether the media record is published. |
| **ID** | Internal media record identifier. |

Use the **Media Type** and **Media Section** filters to narrow the listing. The available sections depend on installed functionality and can include product, category, manufacturer, property, subproperty, and stock image contexts.

![Media filters](img/rs506-media-filters.png)

### Listing actions

The historical interface provides **New**, **Edit**, **Delete**, **Publish**, and **Unpublish**. Select records before applying bulk actions. The current list also offers an edit shortcut beside individual records.

**Be careful when deleting media.** In the current model, deletion can remove the underlying product image file as well as the media record. Some manufacturer and stock-image records cannot be deleted from the generic Media view and must instead be managed in their corresponding section. Check the file's other uses before deleting it.

## Media details

![Media editor](img/rs506-media-editor.png)

The original media editor documents these fields:

| Field | Purpose |
| --- | --- |
| **Image / File** | Choose or upload the media file. |
| **Media Type** | Select the kind of media. |
| **Media Alternative Text** | Provide a meaningful description of the image or media. |
| **Media Section** | Select the context, such as product or category. |
| **Section Item** | Select the specific product, category, or other record. |
| **Published** | Control the media record's publication state. |

The historical media editor offers **Save**, **Save & Close**, **Save & New**, and **Cancel/Close** actions. The precise editor controls should be checked in the installed version.

### Alternative text

Use concise, descriptive alternative text for meaningful product images. For example, *Blue cotton T-shirt, front view* is more useful than *image1*. Avoid repeating the product title mechanically if it does not describe the image.

### Media types

The original documentation discusses images, video, documents, and YouTube media. The current media file browser also distinguishes image files from other documents. Whether a particular media type can be uploaded and rendered depends on file validation, media settings, and the active template.

Do not upload executable files or assume that a file extension alone makes an upload safe. Check the allowed media types and permissions configured for the site.

## 1. Create a media record

1. Open **Media Management** and select **New**.
2. Choose the media file using the editor's file control.
3. Select the correct **Media Type**.
4. Choose the **Media Section** and, when applicable, the **Section Item**.
5. Enter **Media Alternative Text**.
6. Set **Published** as needed.
7. Select **Save & Close**.
8. Find the new record in the media listing and verify its type, section, and associated item.

![Create media](img/rs506-media-create.png)

A media record assigned to the wrong section may not appear in the expected product or category editor. Check both the section and item selection.

## 2. Create media for an existing product

This workflow starts in Media Management and links the uploaded file to a product.

1. Open **Product Management** and create the product if it does not already exist. Enter its name, number, category, and required pricing information, then save it.
2. Open **Media Management → New**.
3. Select or upload the file.
4. Choose the appropriate media type and set **Media Section** to **Product**.
5. Choose the product in **Section Item**.
6. Save the media record.
7. Reopen the product and use its additional-media control to check the association.
8. If the product's media selector requires confirmation, select the media and save the association.
9. Preview the product on the storefront.

![Media associated with product](img/rs506-media-product-link.png)

The original interface uses an **Add additional image or Media** control and a lightbox for choosing media. The current Media list still supports a compact selection view; confirm the exact label and dialog behavior on your installation.

## 3. Create media for a category

1. Open **Categories** and create or edit the category.
2. Select the **Category Image** in the category editor.
3. Save the category.
4. Open Media Management and filter by the category media section.
5. Confirm that the category's media record appears and is associated with the correct category.
6. Open the category on the storefront and check the image.

![Category media](img/rs506-media-category.png)

The category template determines how the image is displayed. Some templates use a thumbnail, while others display a larger image. The image can also be managed through the category editor directly.

## 4. Upload a product's main image from Product Management

1. Open **Product Management** and create or edit a product.
2. Find the main product image control.
3. Choose or upload the image.
4. Save the product.
5. Open Media Management and filter to product media.
6. Confirm that the image is associated with the correct product.
7. Preview the product and check its main image and thumbnail.

![Product main image](img/rs506-media-main-image.png)

A main product image is not necessarily the same as an additional gallery image. Check which image is marked as primary before publishing.

## 5. Add another image or media file to a product

1. Open the existing product in Product Management.
2. Select **Add additional images or Media**, or the corresponding media action.
3. In the media selection dialog, choose **Add** to create a media record if needed.
4. Select or upload the file and save it.
5. Select the newly created media record for the product.
6. If the image should become the primary image, use **Default Media** or **Set default**, where offered.
7. Close the dialog and preview the product.

![Additional product media](img/rs506-media-product-gallery.png)

The current media selector specifically offers **Default Media** for product, property, and subproperty contexts. Changing the default may replace the product's primary image. Check the result before leaving the editor.

### Media ordering

In the compact media selection view, the current template can show ordering controls. Use these to arrange images when the storefront template supports ordered galleries.

## 6. Create media for a manufacturer

1. Open **Products → Manufacturers**.
2. Create or edit a manufacturer.
3. Enter the manufacturer name and other required details.
4. Choose the **Manufacturer Image**.
5. Save the manufacturer.
6. Open Media Management and filter by the manufacturer section.
7. Confirm that the image is associated with the manufacturer.
8. Check the manufacturer's storefront view.

![Manufacturer media](img/rs506-media-manufacturer.png)

The current media model restricts deletion of manufacturer media from the generic Media view. Manage manufacturer images from the manufacturer record when the Media view prevents deletion.

## 7. Reuse existing media on a product

The historical workflow also allows administrators to browse media that already exists and select it while editing a product.

1. Open Media Management and find the file to reuse.
2. Confirm its media type, section, and existing association.
3. Open the target product.
4. Select **Add additional images or Media**.
5. Browse or select the existing file using the available media controls.
6. Save the media association.
7. Preview the product and confirm the file appears in the intended location.

![Reuse media](img/rs506-media-reuse.png)

**Important:** A media record is associated with a section and item. Selecting an existing file is not always equivalent to assigning the same media record to another product. Test whether your version creates a separate association or reuses the existing record before relying on one media file across multiple products.

## Media for attribute properties and subproperties

The current media selection view also supports **Property** and **Subproperty** contexts. These can have their own primary images, allowing an attribute selection to show an appropriate image.

To use these images, configure the product's attribute and property first, then open the corresponding media control and add or select an image. Use the default-media action if required. Check the storefront with each attribute option selected.

## Media files and download security

The media file browser has separate handling for normal image media and product download files. Download files may be stored under the configured **Product Download Root**, rather than the normal image directory.

Do not treat a product image or public media record as a protected customer download. Files sold to customers require the download and authorization workflow configured for that product type. Test access while signed out and with a customer who has not purchased the product.

## Troubleshooting

### A media file does not appear in the list

Check the media type and section filters, the selected item, and whether the record was saved successfully. Clear filters and search again.

### An image is not visible on the storefront

Check its publication state, association, primary/default selection, template support, and thumbnail generation. Also check that the underlying file still exists.

### A media file appears on the wrong product

Review **Media Section** and **Section Item**. If the same file is being reused, check how the current version handles separate associations.

### The default image does not change

Confirm the new default in the media selector, save the relevant product or property, and refresh the storefront. Check for cached thumbnails.

### A manufacturer image cannot be deleted

The current media model prevents generic deletion of some manufacturer and stock-image records. Edit the manufacturer or the relevant source record instead.

### A document is listed but not displayed

The active template may not render that media type. Confirm the file format, media association, and template output.

## Related documentation

- [Product Management overview](overview-product-management.md)
- [Working with Products](products-redshop.md)
- [Working with Categories](../categories/redshop-categories.md)
- [Working with Manufacturers](redshop-manufacturers.md)
- [Global Product Configuration](../global-configuration/products.md)
