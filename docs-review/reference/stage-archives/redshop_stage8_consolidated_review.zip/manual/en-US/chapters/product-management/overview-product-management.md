# Product Management

Product Management is where you create, organize, price and maintain the products offered through redSHOP. Products can represent physical goods, downloadable files or other product types supported by the shop's configuration.

## Guides

- [Working with Products in redSHOP](products-redshop.md) — Product listing, product editor, prices, product types, images, attributes, accessories, related products, SEO and discounts.
- [Working with redSHOP Manufacturers](redshop-manufacturers.md) — Organize products by manufacturer.
- [Working with Price Management](price-management.md) — Maintain product and shopper-group pricing.
- [Working with Supplier Products](supplier-product.md) — Manage supplier-related product information.
- [Working with Product Media](medias-redshop.md) — Manage images and other product media.

## Recommended workflow

1. Create the [categories](../categories/redshop-categories.md) that organize your catalogue.
2. Add manufacturers or suppliers where relevant.
3. Create a product with a unique product number, name, category and appropriate template.
4. Configure its price, tax, product type and stock settings.
5. Upload the main product image and any additional media.
6. Add attributes, variants, accessories or related products where needed.
7. Configure metadata and any product-specific restrictions.
8. Publish the product and verify its storefront page, pricing and checkout behaviour.

For defaults that affect all products, see [Products in Global Configuration](../global-configuration/products.md).

## Working safely

When editing an existing product, check whether it is already used in active promotions, orders, stock workflows or external integrations. Test changes to pricing, variants, downloads and payment restrictions before applying them to a live shop.
