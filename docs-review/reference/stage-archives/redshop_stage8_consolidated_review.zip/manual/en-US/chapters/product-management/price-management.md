# Working with Price Management in redSHOP

redSHOP provides several ways to manage product prices. You can edit the standard price of a product, maintain prices for specific shopper groups and quantity ranges, and configure discounted prices with start and end dates.

Price Management is useful when you need to adjust pricing without editing every other product setting. It also lets you inspect the price rules associated with a product.

## Understanding the three price screens

The administration interface includes several related screens:

| Screen | Main purpose |
| --- | --- |
| **Product Price Management** | Find products and manage their prices; historically includes shortcuts to shopper-group/quantity pricing. |
| **Product price rules listing** | View the individual price records associated with a product, including shopper group, quantity range, price and discount price. |
| **Price rule editor** | Create or edit one price record, including its validity dates. |

The product-specific quick-price screen also provides an editable table of shopper groups, quantity ranges and prices. These screens serve related purposes but do not necessarily expose the same fields.

## Open Product Price Management

1. Sign in to the Joomla administrator.
2. Open **Components → redSHOP**.
3. In the product-related navigation, open **Product Price** or the corresponding price-management view.
4. Search for the product you want to update.

![Product price management](img/rs506-price-product-list.png)

The original interface includes a search box and a search-field selector. Search may support product name, product number or category. When using the older search interface, enter at least two characters to narrow the list.

### Product price listing fields

| Field | Description |
| --- | --- |
| **Product Name** | Name of the product. |
| **Product Number** | Product SKU or identifier. |
| **Price** | Product's normal price; the original interface allows prices for multiple products to be updated. |
| **Discount Price** | Discounted price associated with the product, where configured. |
| **Add / plus icon** | Historically opens a quick-price panel for shopper-group and quantity pricing. |
| **Save** | Saves changes made to editable price fields. |

The display format of prices depends on the shop's currency and decimal settings. Do not assume that a displayed rounded price is identical to the full stored precision.

### Update a standard product price

1. Find the product in Product Price Management.
2. Change its **Price** field.
3. Save using the action provided by the list.
4. Reload the listing to confirm the value was retained.
5. Check the product page and cart with a customer who has no special shopper-group pricing.

When changing multiple products, save in manageable groups and verify a sample of the updated prices.

## Shopper-group and quantity prices

A price rule can be restricted to a particular shopper group and quantity range. This is useful for wholesale pricing, bulk-order discounts and customer-specific pricing.

![Shopper group quantity pricing](img/rs506-price-quantity-popup.png)

The current quick-price template contains the following columns:

| Field | Purpose |
| --- | --- |
| **Shopper Group Name** | Customer group to which the rule applies. |
| **Quantity Start** | Lower boundary of the applicable quantity range. |
| **Quantity End** | Upper boundary of the applicable quantity range. |
| **Product Price** | Price associated with that group and quantity range. |

A save control is provided for the quick-price table.

### Example: bulk pricing

Suppose a product has a standard unit price of 100. You want wholesale customers to pay 80 per unit when purchasing between 20 and 99 units.

Create a price rule for the wholesale shopper group with **Quantity Start = 20**, **Quantity End = 99** and **Price = 80**.

For 20 units, the expected subtotal before tax, shipping and other adjustments would be 1,600. Test quantities 19, 20, 99 and 100 to confirm the rule boundaries.

### Create a quick-price rule

The historical workflow is:

1. Open **Product Price Management**.
2. Locate the product.
3. Select its **plus** icon.
4. Enter the shopper group, quantity start, quantity end and price.
5. Save the changes.
6. Open the product's detailed price management to confirm the new rule.

![Quick price save](img/rs506-price-quick-save.png)

Check that the quantity start is not greater than the quantity end. Avoid overlapping ranges for the same shopper group unless the intended priority is understood and tested.

## Open price rules from a product

The original product editor provides an **Add Price** action for navigating to the product's price records.

1. Open **Product Management**.
2. Select the product.
3. Save it first if it is a new product.
4. Choose **Add Price**, where available.
5. Review the price rules associated with the product.

![Product Add Price action](img/rs506-price-product-action.png)

The current price-rule listing template shows the following columns:

- **Product Name**
- **Shopper Group**
- **Quantity Start**
- **Quantity End**
- **Price**
- **Discount Price**

![Price rules list](img/rs506-price-rules-list.png)

Use the product name link to edit a price rule. The listing also provides record selection for available bulk actions.

## Create a detailed price rule

1. Open the product's price-rule listing.
2. Select **New**.
3. Choose the product and shopper group.
4. Enter the product price.
5. Enter the quantity start and end.
6. Enter a discount price if the rule should offer a reduced price.
7. Set the discount start and end dates if the discount is time-limited.
8. Save the record.
9. Reopen it to confirm the values.
10. Test the price on the storefront using an eligible customer.

![Price rule editor](img/rs506-price-rule-editor.png)

### Detailed price fields

The current price editor contains:

| Field | Description |
| --- | --- |
| **Product Name** | Product associated with the rule. |
| **Shopper Group Name** | Shopper group eligible for the rule. |
| **Product Price** | Price stored for this rule. |
| **Quantity Start** | Minimum quantity for this rule. |
| **Quantity End** | Maximum quantity for this rule. |
| **Discount Price** | Reduced price when a discount applies. |
| **Discount Start Date** | Start of the discount validity period. |
| **Discount End Date** | End of the discount validity period. |

The dates use the shop's configured date format. A blank discount date may be handled differently from an explicit date; verify the result in your installed version.

### Saving and editing rules

The historical price editor supports **Save**, **Save & Close** and **Cancel / Close** actions.

- **Save** keeps you in the editor after saving.
- **Save & Close** saves and returns to the listing.
- **Cancel / Close** leaves without saving new changes.

To edit an existing rule, open it from the price-rule list, make your changes and save. To delete a rule, select it in the listing and use the available delete action.

Deleting a special price rule can change the price offered to eligible customers. Check the affected products immediately afterward.

## Discount prices versus standard prices

A **Product Price** defines a price for the applicable product, group and quantity range. A **Discount Price** is a separate reduced value associated with that price rule.

For example:

| Rule | Value |
| --- | ---: |
| Product Price | 100 |
| Discount Price | 80 |
| Quantity Start | 20 |
| Quantity End | 99 |

The storefront should be tested to determine which price is applied during the configured discount period and which price applies outside it.

Do not assume that every discount stacks with other discounts. Product-level discounts, mass discounts, shopper-group prices and attribute adjustments may interact.

## Verify prices on the storefront

The original documentation demonstrates a complete customer checkout test. Repeating this test is the best way to confirm that a price rule works.

![Frontend quantity pricing](img/rs506-price-frontend-cart.png)

1. Create or select a test customer in the relevant shopper group.
2. Sign in as that customer.
3. Open the product and check the displayed unit price.
4. Add the product to the cart.
5. Change the quantity to one within the price rule's range.
6. Update the cart if required.
7. Verify the unit price and line subtotal.
8. Continue to checkout and confirm the total.
9. Complete a safe test order, if appropriate, and check the order receipt.

### Worked example

For a price of 80 per unit at a quantity of 20:

\[
20 \times 80 = 1{,}600
\]

The cart line subtotal is 1,600 before any additional tax, shipping, wrapping or other applicable adjustments. Compare this with the displayed order total rather than assuming they must always match.

### Boundary tests

Check at least these cases:

- Quantity below the minimum.
- Quantity exactly at the minimum.
- Quantity exactly at the maximum.
- Quantity above the maximum.
- Customer in the eligible shopper group.
- Customer outside that shopper group.
- Date inside and outside a time-limited promotion.

These tests catch many errors that are not visible from the administrator form alone.

## Troubleshooting

### The special price does not appear

Confirm the shopper-group assignment, product association, quantity range, publication status and active dates. Check whether another pricing rule has higher priority.

### The discount is applied at the wrong quantity

Review the quantity boundaries and any overlapping ranges. Test the first and last quantity in the expected range.

### The price changes between product page and checkout

Check shopper-group login state, tax display settings, attributes, quantity changes and other active discounts.

### A price cannot be saved

Confirm that required fields contain valid numeric values and that the quantity start is not greater than the end. Check any validation messages and retry with a simple test rule.

### A date-limited discount is not active

Verify the start/end dates, configured date format and relevant server/store timezone.

## Related documentation

- [Product Management](products-redshop.md)
- [Product Management overview](overview-product-management.md)
- [Global Price Configuration](../global-configuration/price.md)
