# Stage 8 — documentation quality review

## Coverage
- 6 Markdown articles consolidated.
- 28 internal Markdown links checked against the assembled files and repository chapter paths.
- 0 broken Markdown links against the verified repository tree; 9 links point outside this standalone package.
- 50 image references; 50 image files absent from the draft package.

## Status
This is a consolidated **review package**, not publication-ready. Screenshots are intentionally pending; source-code checks and live testing remain open. The original Product Management article still needs a field-by-field content-loss audit.

## Cross-chapter links
All nine links reported missing by the standalone package checker point to existing chapter files in the `gh-pages` repository (`categories` and `global-configuration`). No unresolved Markdown link destinations were identified.

## Additional findings
- Price editor uses `productprice` in JavaScript while its form input is `product_price`; investigate validation.
- The price editor compares standard and discount price using `if (form.productprice.value < form.discount_price.value)`; verify intended constraint.
- Product attribute-set request previously appeared to contain `task==product.ajaxDisplayAttributeSet`; verify the route.
- Media deletion may remove underlying files; test safety and authorization.
- Some list controls and historical template tags are not verified in the current UI.

## Release gate
Before publication: capture screenshots, complete original-content comparison, test all historical workflows on redshop6, verify all field labels and relative links in rendered documentation, and approve any code changes separately.
