# redSHOP documentation — Stage 8 consolidated review

Six English articles under `manual/en-US/chapters/product-management/`:
- overview-product-management.md
- products-redshop.md
- redshop-manufacturers.md
- price-management.md
- supplier-product.md
- medias-redshop.md

Includes a combined screenshot checklist, all stage-specific follow-up tasks, and a quality review. No GitHub commits made.
