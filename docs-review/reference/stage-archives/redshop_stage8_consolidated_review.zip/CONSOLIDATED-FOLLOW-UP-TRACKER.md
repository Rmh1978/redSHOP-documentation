# Stage 8 — consolidated follow-up tracker

## Product Management

# Internal follow-up — Stage 8

This is a source-reviewed documentation draft, not a live-tested certification.

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-01 | OPEN | Compare current product list columns, toolbar and bulk category actions with the historical manual. |
| DOC-8-02 | OPEN | Verify current Product Price Management workflow and shopper-group quantity rules. |
| DOC-8-03 | OPEN | Check all Product Information fields, validation, date/time handling and tax labels in the test UI. |
| DOC-8-04 | OPEN | Test downloadable-product access, limits and file storage; verify protection against direct file access. |
| DOC-8-05 | OPEN | Test subscriptions, renewals and serial-number delivery where configured. |
| DOC-8-06 | OPEN | Confirm product custom-field display and available editor tabs. |
| DOC-8-07 | OPEN | Test additional image publishing and media gallery output. |
| DOC-8-08 | OPEN | Test attribute-set copy; source contains `task==product.ajaxDisplayAttributeSet` and may require a fix. |
| DOC-8-09 | OPEN | Test attribute/subproperty price calculations and required selection. |
| DOC-8-10 | OPEN | Verify product vs category accessory precedence and related-product rendering. |
| DOC-8-11 | OPEN | Confirm redPRODUCTFINDER integration availability and UI. |
| DOC-8-12 | OPEN | Verify product SEO fieldset, SEF URLs and generated metadata. |
| DOC-8-13 | OPEN | Review Discount Calculator units, dimension handling and discount precedence. |
| DOC-8-14 | OPEN | Verify accounting integration field mapping. |
| DOC-8-15 | OPEN | Test individual payment-method restrictions, including mixed-product carts. |
| DOC-8-16 | OPEN | Verify mass discount and product price discount fields, ordering and shopper-group rules. |
| DOC-8-17 | OPEN | Capture 15 screenshots and verify relative links against actual docs tree. |
| DOC-8-18 | OPEN | Audit original 2019 product article field-by-field to ensure no still-relevant advanced fields were omitted from the rewritten draft. |


## Manufacturers

# Internal follow-up: Product Management — Manufacturers

| ID | Status | Task |
| --- | --- | --- |
| DOC-8-M01 | OPEN | Confirm current manufacturer list toolbar, filters, columns and copy/delete/check-in behaviour. |
| DOC-8-M02 | OPEN | Verify manufacturer form fields, required template selection and default products-per-page on test site. |
| DOC-8-M03 | OPEN | Confirm manufacturer image upload and alt text behaviour. |
| DOC-8-M04 | OPEN | Verify SEO values in generated frontend metadata and routing. |
| DOC-8-M05 | OPEN | Test product-to-manufacturer assignment and listing pagination. |
| DOC-8-M06 | OPEN | Test manufacturer mass discounts and priority against product discounts. |
| DOC-8-M07 | OPEN | Identify supported manufacturer template tags and verify product-page manufacturer-name tag. |
| DOC-8-M08 | OPEN | Confirm available Joomla manufacturer menu item types and labels. |
| DOC-8-M09 | OPEN | Confirm manufacturer email notification trigger and delivery. |
| DOC-8-M10 | OPEN | Capture seven screenshots. |


## Price Management

# Internal follow-up — Price Management

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-P01 | OPEN | Verify current Product Price Management screen and search controls. |
| DOC-8-P02 | OPEN | Confirm historical plus-icon modal exists and is compatible with Joomla 5. |
| DOC-8-P03 | OPEN | Test quick-price save task `saveprice` versus `productprice.saveprice`. |
| DOC-8-P04 | OPEN | Review `component/admin/tmpl/price/edit.php`: JavaScript validates `form.productprice`, but field is `product_price`; `form.discount_price` check may be reversed. |
| DOC-8-P05 | OPEN | Check price editor quantity range validation, discount price constraints and decimal input. |
| DOC-8-P06 | OPEN | Verify exact New/Edit/Delete toolbar actions on price-rule listing. |
| DOC-8-P07 | OPEN | Test overlapping shopper-group quantity ranges and rule precedence. |
| DOC-8-P08 | OPEN | Test discount date handling, timezone and empty date semantics. |
| DOC-8-P09 | OPEN | Verify storefront unit prices, subtotal, tax and checkout for quantity boundary cases. |
| DOC-8-P10 | OPEN | Capture seven screenshots and verify article links. |
| DOC-8-P11 | OPEN | Review historical tutorial video URLs for continued availability before adding links. |


## Supplier Products

# Internal follow-up — Supplier Products

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-S01 | OPEN | Verify shared admin list layout columns and toolbar actions in Joomla 5 test installation. |
| DOC-8-S02 | OPEN | Confirm Save / Save & Close / Save & New / Close in current supplier editor. |
| DOC-8-S03 | OPEN | Locate current product supplier field and verify supplier association storage. |
| DOC-8-S04 | OPEN | Verify `{supplier_name}` template tag is still processed by current product template engine. |
| DOC-8-S05 | OPEN | Test unpublished supplier behaviour on product page. |
| DOC-8-S06 | OPEN | Test copy operation and generated unique supplier name. |
| DOC-8-S07 | OPEN | Verify supplier deletion impact on product associations and database constraints. |
| DOC-8-S08 | OPEN | Confirm check-in works after abandoned editing session. |
| DOC-8-S09 | OPEN | Capture 11 screenshots and check article links. |
| DOC-8-S10 | OPEN | Review historical tutorial videos before linking publicly. |


## Media

# Internal follow-up — Media Management

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-MED01 | OPEN | Verify exact Media navigation labels and available list toolbar actions. |
| DOC-8-MED02 | OPEN | Inspect current `medium` editor fields and supported media types; verify video and YouTube support. |
| DOC-8-MED03 | OPEN | Test media type and media section filtering, including item-specific popup. |
| DOC-8-MED04 | OPEN | Test new media upload and association with a product. |
| DOC-8-MED05 | OPEN | Test category image media record creation and association. |
| DOC-8-MED06 | OPEN | Test main product image and additional image workflow, including default media. |
| DOC-8-MED07 | OPEN | Test manufacturer media association and deletion restrictions. |
| DOC-8-MED08 | OPEN | Test reusing one file across multiple product records without overwriting an existing association. |
| DOC-8-MED09 | OPEN | Verify property and subproperty image selection and storefront behaviour. |
| DOC-8-MED10 | OPEN | Review `MediaModel::delete` and `MediumTable::doDelete` for deletion side effects, shared-file safety, and transaction consistency. |
| DOC-8-MED11 | OPEN | Review upload validation, MIME/extension checks, and file access permissions. |
| DOC-8-MED12 | OPEN | Verify product download root isolation from public media paths. |
| DOC-8-MED13 | OPEN | Capture 10 screenshots and validate all relative documentation links. |
| DOC-8-MED14 | OPEN | Review original tutorial videos for relevance and availability. |
