# Stage 8 — combined screenshot checklist

# Stage 8 screenshot checklist

Save screenshots under `manual/en-US/chapters/product-management/img/`.

- [ ] `rs506-product-list.png` — Product list.
- [ ] `rs506-product-list-actions.png` — List toolbar and bulk actions.
- [ ] `rs506-product-price-management.png` — Price management screen.
- [ ] `rs506-product-editor.png` — Product editor overview.
- [ ] `rs506-product-information.png` — Product Information.
- [ ] `rs506-product-types.png` — Product Types and download options.
- [ ] `rs506-product-custom-fields.png` — Custom fields.
- [ ] `rs506-product-images.png` — Main and other images.
- [ ] `rs506-product-attributes.png` — Attributes and properties.
- [ ] `rs506-product-accessories.png` — Accessories and related products.
- [ ] `rs506-product-seo.png` — SEO fields.
- [ ] `rs506-product-discount-calculator.png` — Discount calculator.
- [ ] `rs506-product-payment-methods.png` — Product-specific payment methods.
- [ ] `rs506-product-mass-discounts.png` — Mass-discount setup.
- [ ] `rs506-product-price-discounts.png` — Price-discount rules.

Use test products and redact any private customer, supplier or payment data.


# Manufacturer screenshots

Save to `manual/en-US/chapters/product-management/img/`:
- [ ] `rs506-manufacturer-list.png` — Manufacturer listing.
- [ ] `rs506-manufacturer-toolbar.png` — Toolbar and list actions.
- [ ] `rs506-manufacturer-editor.png` — Details tab including all current fields.
- [ ] `rs506-manufacturer-seo.png` — SEO tab.
- [ ] `rs506-manufacturer-product-assignment.png` — Manufacturer selection in product editor.
- [ ] `rs506-manufacturer-discount.png` — Manufacturer-based mass discount.
- [ ] `rs506-manufacturer-frontend.png` — Published manufacturer page.


# Price Management screenshot checklist

Capture on the redSHOP 5.0.6 test installation and save in `manual/en-US/chapters/product-management/img/`.

- [ ] `rs506-price-product-list.png` — Product Price Management overview, search and price fields.
- [ ] `rs506-price-quantity-popup.png` — Shopper-group quantity price table or modal.
- [ ] `rs506-price-quick-save.png` — Quick-price editing and save control.
- [ ] `rs506-price-product-action.png` — Product editor Add Price action.
- [ ] `rs506-price-rules-list.png` — Product-specific price-rule listing.
- [ ] `rs506-price-rule-editor.png` — Detailed price editor, including dates.
- [ ] `rs506-price-frontend-cart.png` — Test customer's cart showing quantity-based pricing.

Avoid real customer details or live payment information.


# Supplier screenshots

Capture on the redSHOP 5.0.6 test site. Place files in `manual/en-US/chapters/product-management/img/`.

- [ ] `rs506-supplier-list.png` — Supplier listing and visible columns.
- [ ] `rs506-supplier-toolbar.png` — Available toolbar actions.
- [ ] `rs506-supplier-editor.png` — Supplier form with name, email, published and description.
- [ ] `rs506-supplier-product-assignment.png` — Supplier selection in product editor.
- [ ] `rs506-supplier-template.png` — Product template with `{supplier_name}`.
- [ ] `rs506-supplier-frontend.png` — Product displaying supplier name.
- [ ] `rs506-supplier-publish.png` — Supplier published.
- [ ] `rs506-supplier-unpublish.png` — Supplier unpublished.
- [ ] `rs506-supplier-copy.png` — Copied supplier record.
- [ ] `rs506-supplier-delete.png` — Supplier delete confirmation.
- [ ] `rs506-supplier-checkin.png` — Check-in action.

Use demonstration suppliers and products; redact real supplier contact details.


# Screenshot checklist — Media Management

Capture from the redSHOP 5.0.6 test site. Store under `manual/en-US/chapters/product-management/img/`.

- [ ] `rs506-media-list.png` — Media listing and columns.
- [ ] `rs506-media-filters.png` — Type and section filters.
- [ ] `rs506-media-editor.png` — Media detail editor.
- [ ] `rs506-media-create.png` — New media upload and section assignment.
- [ ] `rs506-media-product-link.png` — Media associated with a product.
- [ ] `rs506-media-category.png` — Category media association.
- [ ] `rs506-media-main-image.png` — Product main image.
- [ ] `rs506-media-product-gallery.png` — Additional media and Default Media action.
- [ ] `rs506-media-manufacturer.png` — Manufacturer image.
- [ ] `rs506-media-reuse.png` — Selecting existing media for a product.

Use demonstration data and avoid displaying private customer information.
