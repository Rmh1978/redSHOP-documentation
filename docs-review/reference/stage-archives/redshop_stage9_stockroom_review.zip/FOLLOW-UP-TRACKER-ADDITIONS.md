# Stage 9 follow-up

- [ ] Verify stockroom list toolbar and actions on redshop6.
- [ ] Verify minimum-stock threshold behaviour.
- [ ] Verify stockroom delivery-time output on frontend.
- [ ] Test product, property and subproperty inventory save.
- [ ] Test preorder quantities and reset without affecting real orders.
- [ ] Confirm print action and whether export is supported.
- [ ] Confirm custom Stock Option choices and comparison semantics.
- [ ] Verify stock image template tags and frontend output.
- [ ] Confirm deletion behaviour for stockroom and stock image records.
- [ ] Capture eight screenshots.
- [ ] Perform field-by-field original-content audit and verify rendered links.
- [ ] Review Joomla 6 compatibility of stockroom admin JavaScript.
