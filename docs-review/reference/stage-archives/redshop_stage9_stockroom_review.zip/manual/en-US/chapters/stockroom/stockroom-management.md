# Stockroom Management

A stockroom represents a stock location or inventory pool in redSHOP. Create stockrooms before assigning stock quantities to products.

## Open Stockroom Management

Sign in to the Joomla administrator, open **Components → redSHOP**, then choose the **Stockroom** management area.

![Stockroom list](img/rs506-stockrooms-list.png)

The list shows configured stockrooms and provides management actions. The exact toolbar layout is version-dependent.

## Create a stockroom

1. Open **Stockroom Management** and select **New**.
2. Enter a **Name**.
3. Set the **Minimum Stock Amount** if you use a stock threshold.
4. Choose whether delivery times are measured in **Days** or **Weeks**.
5. Enter **Minimum Delivery Time** and **Maximum Delivery Time**.
6. Set **Show on Stocklist** as required.
7. Set **Published**.
8. Add a **Description** if helpful.
9. Save and verify the new stockroom.

![Stockroom editor](img/rs506-stockrooms-editor.png)

## Current stockroom fields

The fields below are defined in the current `stockroom.xml` form.

| Field | Purpose |
| --- | --- |
| **Name** | Required stockroom name. |
| **Minimum Stock Amount** | Stock threshold for the stockroom. |
| **Delivery Time In** | Choose Days or Weeks; the current form defaults to Days. |
| **Minimum Delivery Time** | Lower estimated delivery time; defaults to 0. |
| **Maximum Delivery Time** | Upper estimated delivery time; defaults to 0. |
| **Show on Stocklist** | Whether the stockroom is shown in supported stock listings; defaults to Yes. |
| **Published** | Publication status; defaults to Yes. |
| **Description** | Optional rich-text description. |

For example, create **Main Warehouse** with delivery times of 1–3 days and **External Warehouse** with 1–2 weeks. Test the displayed estimate: the chosen unit and the delivery-time values are separate fields.

## Edit or manage existing stockrooms

Select an existing stockroom to change its details. The original manual also covers list actions and creating stockrooms. Confirm the exact current toolbar controls on the test installation before relying on bulk operations.

Avoid deleting a stockroom that holds quantities or preorder records until those relationships have been reviewed.

## Connect a stockroom to product inventory

After creating a stockroom, open a product in Product Management. The product's stockroom section displays stockrooms, quantities, delivery times and preorder values.

See [Inventory for All Stockrooms](inventory-stockroom.md) for editing inventory across many products.

## Troubleshooting

**A stockroom does not appear in the product editor:** confirm it exists, is published and is included in the stockroom list used by the product form.

**Delivery times are wrong:** check whether Days or Weeks is selected and verify both minimum and maximum values.

**The stockroom is missing from a frontend stock list:** check **Show on Stocklist**, publication state and the active frontend template.

## Related documentation

- [Inventory for All Stockrooms](inventory-stockroom.md)
- [Stockroom Image Management](stockroom-image-management.md)
