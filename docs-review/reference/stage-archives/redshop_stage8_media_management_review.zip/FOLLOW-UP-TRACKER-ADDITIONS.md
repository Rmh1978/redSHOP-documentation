# Internal follow-up — Media Management

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-MED01 | OPEN | Verify exact Media navigation labels and available list toolbar actions. |
| DOC-8-MED02 | OPEN | Inspect current `medium` editor fields and supported media types; verify video and YouTube support. |
| DOC-8-MED03 | OPEN | Test media type and media section filtering, including item-specific popup. |
| DOC-8-MED04 | OPEN | Test new media upload and association with a product. |
| DOC-8-MED05 | OPEN | Test category image media record creation and association. |
| DOC-8-MED06 | OPEN | Test main product image and additional image workflow, including default media. |
| DOC-8-MED07 | OPEN | Test manufacturer media association and deletion restrictions. |
| DOC-8-MED08 | OPEN | Test reusing one file across multiple product records without overwriting an existing association. |
| DOC-8-MED09 | OPEN | Verify property and subproperty image selection and storefront behaviour. |
| DOC-8-MED10 | OPEN | Review `MediaModel::delete` and `MediumTable::doDelete` for deletion side effects, shared-file safety, and transaction consistency. |
| DOC-8-MED11 | OPEN | Review upload validation, MIME/extension checks, and file access permissions. |
| DOC-8-MED12 | OPEN | Verify product download root isolation from public media paths. |
| DOC-8-MED13 | OPEN | Capture 10 screenshots and validate all relative documentation links. |
| DOC-8-MED14 | OPEN | Review original tutorial videos for relevance and availability. |
