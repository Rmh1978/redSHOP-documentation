# Stage 8 — Media Management

Replaces `manual/en-US/chapters/product-management/medias-redshop.md`.

Preserves all seven practical workflows from the original 2019 manual, including creating media, product associations, category images, uploading product main images, additional product media, manufacturer media, and reusing existing media.

Current source checked:
- `component/admin/tmpl/media/default.php`
- `component/admin/src/Model/MediaModel.php`

The exact `medium` editor UI, video/YouTube handling, and frontend workflows require test-site verification. Source review identifies deletion restrictions for manufacturer/stockimage records and potential underlying file deletion for product media. No GitHub changes were made.
