# Screenshot checklist — Media Management

Capture from the redSHOP 5.0.6 test site. Store under `manual/en-US/chapters/product-management/img/`.

- [ ] `rs506-media-list.png` — Media listing and columns.
- [ ] `rs506-media-filters.png` — Type and section filters.
- [ ] `rs506-media-editor.png` — Media detail editor.
- [ ] `rs506-media-create.png` — New media upload and section assignment.
- [ ] `rs506-media-product-link.png` — Media associated with a product.
- [ ] `rs506-media-category.png` — Category media association.
- [ ] `rs506-media-main-image.png` — Product main image.
- [ ] `rs506-media-product-gallery.png` — Additional media and Default Media action.
- [ ] `rs506-media-manufacturer.png` — Manufacturer image.
- [ ] `rs506-media-reuse.png` — Selecting existing media for a product.

Use demonstration data and avoid displaying private customer information.
