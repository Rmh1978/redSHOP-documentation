# redSHOP documentation — Phase 6: Newsletter

Replace `manual/en-US/chapters/global-configuration/newsletter.md` in the documentation repository with the included file.

Compared against the original public article and `component/admin/tmpl/configuration/default_newslettertab.php` on `develop`.

The article preserves all original setting topics, updates the language and adds setup and troubleshooting guidance. The test email's actual backend behaviour requires separate functional verification and is recorded in the internal follow-up tracker. Screenshot image references are placeholders until screenshots are supplied.

No GitHub files or running site settings were changed.
