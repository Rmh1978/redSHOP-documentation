# Internal follow-up — Newsletter

| ID | Status | Task |
| --- | --- | --- |
| DOC-6-N01 | OPEN | Trace newsletter test button submission (`task=apply`) through controller/model to verify whether and when a test message is actually sent. |
| DOC-6-N02 | OPEN | Test confirmation workflow, email content, subscription state and confirmation links on redSHOP 5.0.6. |
| DOC-6-N03 | OPEN | Verify batch size and pause settings are used by the actual newsletter sending process, including error and timeout handling. |
| DOC-6-N04 | OPEN | Check default newsletter selection, template output, sender and reply-to headers. |
| DOC-6-N05 | OPEN | Confirm visibility of dependent settings when newsletter is disabled and enabled. |
| DOC-6-N06 | OPEN | Capture three screenshots from `/tests/redshop6` and check labels. |
| DOC-6-N07 | OPEN | Confirm data protection and unsubscribe behaviour in subscriber management; document separately in communication chapter. |
