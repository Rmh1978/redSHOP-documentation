# Screenshot checklist — Newsletter configuration

Capture screenshots from the Joomla administrator running redSHOP 5.0.6. Store images under `manual/en-US/chapters/global-configuration/img/`.

- [ ] `rs506-newsletter-overview.png` — Entire Newsletter tab, showing newsletter and test-mail panels.
- [ ] `rs506-newsletter-settings.png` — Newsletter settings with enabled state, confirmation, sender fields, default newsletter, batch size and pause.
- [ ] `rs506-newsletter-test-mail.png` — Test Mail field and Send button, without exposing personal email addresses.

Confirm the actual UI labels and that the screenshots match the article. Use a test email address and avoid sending to real subscribers.
