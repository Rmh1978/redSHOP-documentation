# Data Import

> Review draft. Original manual fields and data families are retained below. Current processing and data schema require testing.

## Original fields

- **Select import** — confirm current function and options
- **Configuration** — confirm current function and options
- **Upload file** — confirm current function and options

## Data families documented in the original manual

### Attributes, properties and sub-properties

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

### Categories

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

### Custom Fields

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

### Manufacturers

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

### Newsletter Subscriber

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

### Products

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

### Product stockroom data

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

### Related Products

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

### Shipping addresses

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

### Shopper group specific attribute price

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

### Shopper group specific product price

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

### Users

Verify column mapping, IDs, data types, relationships, encoding, errors and record counts. Export and re-import compatibility is not assumed.

## Safe test procedure

1. Back up the independent test database and media.
2. Select the data family and inspect the current configuration.
3. Use a small dataset containing a new record, existing record and invalid record.
4. Process in redshop6 only, checking warnings and errors.
5. Verify record counts, associations, storefront effects and rollback strategy.
6. Repeat with a larger file to evaluate timeouts and memory limits.

## Security and compatibility

Validate permissions, CSRF, file types and content, path handling, temporary-file cleanup and sensitive-data exposure. Test UTF-8, dates, decimal separators, CSV formula injection and duplicate IDs.

**Source finding:** `component/admin/tmpl/import/default.php` references file MIME, file size and file extension checks and calls `RedshopJquery::ui()`. This requires server-side validation and Joomla 6 compatibility review; template code alone does not prove either.

## Screenshots needed

- Selection and configuration
- Progress, completion and errors
- Output or imported result

## Source

Original: `manual/en-US/chapters/import-export/data-import.md` (`gh-pages`); current: `component/admin/tmpl/import/default.php` (`develop`).
