# Import/Export

Use [Data Import](data-import.md) and [Data Export](data-export.md) for the twelve documented data families. Test schemas and data integrity on an independent staging installation.

**Status:** Review draft; no transfer has been executed.
