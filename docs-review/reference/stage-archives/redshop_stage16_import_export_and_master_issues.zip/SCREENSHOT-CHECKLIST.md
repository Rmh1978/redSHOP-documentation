# Import/Export screenshots

- [ ] Import selection, settings, upload, errors and result
- [ ] Export selection, settings, progress and download
- [ ] Representative result for each of twelve data families
