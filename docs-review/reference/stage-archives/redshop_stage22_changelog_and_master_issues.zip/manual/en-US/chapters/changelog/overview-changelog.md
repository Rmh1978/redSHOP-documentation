# Changelog — historical and current releases

The historical release notes are preserved in the existing documentation repository. **Do not overwrite the original release notes with a summary.** This revised index separates legacy documentation from the current release process.

## Historical release notes

These releases are archival and do not establish compatibility with Joomla 5 or 6:

- [redSHOP 1.5.0.6](redshop-1.5.0.6.md) — historical release notes (existing file retained)
- [redSHOP 2](redshop-2.md) — historical release notes (existing file retained)
- [redSHOP 2.0.2](redshop-2.0.2.md) — historical release notes (existing file retained)
- [redSHOP 2.0.3](redshop-2.0.3.md) — historical release notes (existing file retained)
- [redSHOP 2.0.4](redshop-2.0.4.md) — historical release notes (existing file retained)
- [redSHOP 2.0.5](redshop-2.0.5.md) — historical release notes (existing file retained)
- [redSHOP 2.0.6](redshop-2.0.6.md) — historical release notes (existing file retained)
- [redSHOP 2.0.7](redshop-2.0.7.md) — historical release notes (existing file retained)
- [redSHOP 2.1.2.2](redshop-2.1.2.2.md) — historical release notes (existing file retained)
- [redSHOP 2.1.3](redshop-2.1.3.md) — historical release notes (existing file retained)
- [redSHOP 2.1.4](redshop-2.1.4.md) — historical release notes (existing file retained)
- [redSHOP 2.1.5](redshop-2.1.5.md) — historical release notes (existing file retained)
- [redSHOP 3.0](redshop-3.0.md) — historical release notes (existing file retained)
- [redSHOP 3.0.1](redshop-3.0.1.md) — historical release notes (existing file retained)
- [redSHOP 3.0.2](redshop-3.0.2.md) — historical release notes (existing file retained)

## Current release history

The current `develop` manifest (`redshop.xml`) declares **5.0.6**. The current `CHANGELOG.md` records **5.0.5** (2026-11-08) and **5.0.6** (2026-11-09). These are verified repository facts, not live-site version checks.

For current releases, use the repository's `CHANGELOG.md` and the verified artifacts produced by the release pipeline. See `docs/release-system.md` for the publication workflow. Do not fabricate missing notes for versions between 3.0.2 and 5.0.5.

## Publication and validation

- Keep archival release notes intact, including their original dates, change descriptions and references.
- Link current releases only after the corresponding package, tag and changelog are verified.
- Confirm that navigation paths work from the actual published documentation location.
- Mark old installation and API instructions as historical rather than current recommendations.
- Never imply that documentation has been deployed without a successful publication check.
