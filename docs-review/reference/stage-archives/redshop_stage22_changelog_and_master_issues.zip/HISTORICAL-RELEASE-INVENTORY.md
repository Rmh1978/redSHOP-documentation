# Historical release notes — preservation inventory

The following 15 original Markdown articles remain in GitHub and have **not** been copied into or replaced by this ZIP. They must be preserved verbatim during migration.

- `manual/en-US/chapters/changelog/redshop-1.5.0.6.md`
- `manual/en-US/chapters/changelog/redshop-2.md`
- `manual/en-US/chapters/changelog/redshop-2.0.2.md`
- `manual/en-US/chapters/changelog/redshop-2.0.3.md`
- `manual/en-US/chapters/changelog/redshop-2.0.4.md`
- `manual/en-US/chapters/changelog/redshop-2.0.5.md`
- `manual/en-US/chapters/changelog/redshop-2.0.6.md`
- `manual/en-US/chapters/changelog/redshop-2.0.7.md`
- `manual/en-US/chapters/changelog/redshop-2.1.2.2.md`
- `manual/en-US/chapters/changelog/redshop-2.1.3.md`
- `manual/en-US/chapters/changelog/redshop-2.1.4.md`
- `manual/en-US/chapters/changelog/redshop-2.1.5.md`
- `manual/en-US/chapters/changelog/redshop-3.0.md`
- `manual/en-US/chapters/changelog/redshop-3.0.1.md`
- `manual/en-US/chapters/changelog/redshop-3.0.2.md`
