# Release documentation validation

- [ ] Verify relative links on the deployed documentation site
- [ ] Check 15 historical release files and preserve their contents
- [ ] Verify 5.0.5 and 5.0.6 changelog against corresponding Git tags and packages
- [ ] Confirm current package metadata and update-server manifest
- [ ] Test release-document generation and publication in staging only
- [ ] Check permissions and sensitive data in release artifacts
- [ ] Verify Joomla 6 compatibility claims separately
