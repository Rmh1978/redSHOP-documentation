# Order List

Open **Components → redSHOP → Orders → Orders** in the Joomla administrator. This is the central list for finding, reviewing and updating orders.

![Orders list](img/rs506-orders-list.png)

## Columns

The original manual documents **Order ID**, **Order Number**, **Customer**, **Full Name**, **Email**, **Customer Type** (shopper group), **Customer Note**, **Order Status**, **Payment Status**, **Order Total**, **Order Date** and status-update controls. The current screen may arrange these differently.

Order ID is an internal identifier; Order Number is the order reference. Payment states such as paid, unpaid and partially paid are distinct from fulfilment states.

## Search and filters

The current `filter_orders.xml` provides a search box and **Filter By** options **All, Order ID, Order Number, Full Name, Email and Phone**, plus **From Date**, **To Date**, **Order Status** and **Payment Status**.

![Order filters](img/rs506-orders-filters.png)

To locate a customer inquiry, choose Order Number and search for their reference. For reconciliation, filter a date range and payment status. Clear filters before concluding an order is missing.

## Open and update an order

1. Search by order number or customer.
2. Open the order.
3. Check customer and billing/shipping details.
4. Review product lines, VAT, discounts, delivery charge and final total.
5. Review order and payment statuses separately.
6. Change only the intended fields and save.
7. Check the status history and any notification sent.

![Order details](img/rs506-order-details.png)

## Bulk status changes

The original toolbar documents **Save Status Changes**. The current orders template contains bulk order/payment status controls and a customer-email flag. Select the exact orders, set the intended status, review notification settings and submit. Verify a sample of changed records. Manually setting **Paid** does not capture a payment.

![Bulk status](img/rs506-orders-bulk.png)

## Print and export

The original manual lists **Print Multiple Orders** (printable PDF) and these export options: **Export Data** (basic CSV), **Export Full Order CSV**, **Export GLS** and **Export GLS Business**. Availability and formats must be verified in the current toolbar and with installed shipping integrations. Popup blocking may affect printing. Exported files contain customer data.

![Export actions](img/rs506-orders-export.png)

## New and Delete

**New** opens manual order creation. **Delete** is described as permanent in the original manual. Before deleting an order, review payment, invoicing, accounting, fulfilment and legal record-retention requirements. Prefer a cancellation status when history must be preserved.

## Troubleshooting

If a status change is missing, check the selected order, status history and permissions. If an email was sent unexpectedly, review the notification option and any status-triggered plugin. If exports look incomplete, distinguish selected orders from filtered results.

See [Add Order](add-order.md) and [Order Status List](order-status-list.md).
