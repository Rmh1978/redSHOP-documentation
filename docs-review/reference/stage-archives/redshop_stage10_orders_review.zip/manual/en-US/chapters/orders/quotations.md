# Quotations

Quotations let a customer request pricing before an order is placed. Open **Components → redSHOP → Orders → Quotations**.

![Quotation list](img/rs506-quotes-list.png)

## Quotation list and filters

The current `quotations/default.php` displays **ID, Number, Full Name, Quotation Status, Total and Date**, with a search field and quotation-status filter. The historical statuses are **Requested, Replied, Accepted, Rejected and Ordered**. In the current listing, the ordered state (`quotation_status == 5`) includes the related order ID.

The original toolbar documents **New, Export Data, Edit and Delete**; verify availability in the current UI.

## Create a quotation in the backend

1. Select **New**.
2. Choose the customer.
3. Add a product and any applicable options.
4. Enter quantity and verify tax-exclusive and displayed price.
5. Review discounts, tax and quotation total.
6. Save and reopen to verify the details.
7. Update the quotation status as the negotiation progresses.

![Quotation editor](img/rs506-quotes-editor.png)

## Quotation information

The original editor includes **Date, Number, Quotation IP Address, Quotation Note, Customer Note and Quotation Status**.

**Account Information** includes first/last name, address, postal code, city, country, state, phone and email.

**Quotation Details** include product name/note, price without VAT, price, quantity, line total, subtotal, discount without VAT, discount with VAT, special discount, subtotal after discount, tax and quotation total. The **Add Product** area provides product selection, quantity, price and Add action.

![Quotation totals](img/rs506-quotes-totals.png)

## Save, send and delete

The original manual lists **Save, Save & Close, Send, Cancel and Close**. Its description of **Send** is contradictory about whether an email is sent. Test with a controlled mailbox before relying on it. Deleting quotations may remove sales history.

## Request a quotation on the storefront

Historically, create a Joomla menu item of redSHOP **Quote** type. Log in, add products to the cart, open the quote page and choose **Request a Quote**. Check the backend quotation, status, pricing and notification result.

![Frontend quotation](img/rs506-quotes-frontend.png)

## Convert to an order

The current list can show an order ID associated with a quotation in the ordered state. Verify the actual conversion workflow and that customer, product, discount and VAT details are preserved. Merely changing a status must not be assumed to create an order.

See [Add Order](add-order.md).
