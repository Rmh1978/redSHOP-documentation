# Orders

The redSHOP Orders area covers processing orders, creating manual orders, configuring statuses, quotations, and searching for orders containing a particular product.

- [Order List](order-list.md)
- [Add Order](add-order.md)
- [Order Status List](order-status-list.md)
- [Quotations](quotations.md)
- [Product Order Search](product-order-search.md)

Use a test customer and non-live payment method when testing order creation, emails, status changes, stock adjustments or shipping integrations. **Order status** and **payment status** are separate.
