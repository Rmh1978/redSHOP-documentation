# Product Order Search

The historical **Product Order Search** report helps locate orders containing a particular product. Open **Components → redSHOP → Orders → Product Order Search**, if the current administrator menu includes it.

![Product order search](img/rs506-product-order-search.png)

## Fields

The original report shows **Product Name**, **SKU**, **Order ID**, **Date**, **Order Status**, **Quantity** and **Customer Name**. This is a product-to-order lookup, not an inventory report.

## Filters

The historical view provides **Search Name** (partial product-name matching), **Reset**, **Select Status** and **Select User**.

![Product order filters](img/rs506-product-order-filters.png)

## Workflow

1. Search for the product name.
2. Confirm the SKU.
3. Narrow by order status or customer if needed.
4. Inspect matching order IDs, quantities and dates.
5. Open the order to check payment and fulfilment details.

The current repository also has a `statisticorder` view with a sales chart. This is **not evidence** that the historical Product Order Search screen is still implemented; its current route and filters require verification.

See [Order List](order-list.md).
