# Order Status List

Open **Components → redSHOP → Orders → Order Statuses**.

## Current fields

The current `component/admin/forms/orderstatus.xml` defines **Name** (`order_status_name`), **Code** (`order_status_code`) and **Published**. All three are required; Published defaults to Yes. The original list also displays a unique ID.

![Status list](img/rs506-status-list.png)

The original manual refers to 17 default statuses. This is historical, not a guaranteed count in the current release.

## Create a status

1. Select **New**.
2. Enter a meaningful name, such as *Awaiting artwork approval*.
3. Enter a distinct code; integrations may depend on it.
4. Set Published and save.
5. Verify the status appears in the list and relevant selectors.

![Status editor](img/rs506-status-editor.png)

The historical list provides **New, Delete, Publish, Unpublish, Check-in** and search. Editor actions include **Save, Save & Close, Save & New, Cancel**. Check the current toolbar before applying bulk actions.

## Change an order status in three places

**Order Management:** find an order, use **Update Order Status**, choose a status, add a note if supported, review customer notification and save.

**Order Details:** open the order, locate status controls, select the new status, update and inspect the **Order Status Log**.

**Dashboard:** open an order from **Newest Orders** and then change its status in Order Details.

![Order status update](img/rs506-status-update.png)

## Automations and side effects

The original manual describes status-triggered emails and shipping/payment workflows. These require actual plugin/configuration support; a status change alone does not guarantee payment capture, refunds or shipment booking. Test transitions such as Pending → Confirmed, Confirmed → Shipped and Confirmed → Cancelled with test data.

Changing an existing status code can break integration rules. Before deleting or unpublishing a status, inspect orders and automation rules that refer to it.

See [Order List](order-list.md).
