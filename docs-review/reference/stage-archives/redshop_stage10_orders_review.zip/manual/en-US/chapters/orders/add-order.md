# Add Order

Administrators can create orders for existing or new customers. The original manual also describes storefront checkout, order history, order tracking and one-step checkout.

Open **Components → redSHOP → Orders → Orders → New**.

![Manual order](img/rs506-addorder.png)

## Create an order for an existing customer

1. Search for and select **Existing Customer**.
2. Verify their contact information and billing address.
3. Set **Shipping Same as Billing** or select another shipping address.
4. Add the required products and variants.
5. Check quantity, price excluding VAT, tax, price including VAT and line total.
6. Apply discounts and shipping, then review the order total.
7. Select the appropriate payment and save action.
8. Reopen the order and verify its details and email behaviour.

## Create an order for a new customer

1. Leave Existing Customer unselected.
2. Choose **Create Account** where needed.
3. Enter first name, last name, address, postal code, city, country, state/region, phone and email.
4. Choose customer type/shopper group and shipping address.
5. If account creation requires it, provide username and the required password fields using the secure current workflow.
6. Add products, review VAT, discount, shipping and total.
7. Save and verify that the expected order and customer account were created.

![Customer fields](img/rs506-addorder-customer.png)

## Order detail fields

The historical editor includes customer fields **Existing Customer, Create Account, Registered, First Name, Last Name, Address, Postal Code, City, Country, State, Phone, Shipping Same as Billing, Select Shipping Address, Email, Username, New Password and Confirm Password**.

Product rows include **Name, Note, Price without VAT/Tax, VAT/Tax, Price, Quantity and Total**. The totals section includes **Subtotal, VAT/Tax, Discount, Special Discounts, Shipping and Total**.

The current `addorder/default.php` dynamically creates product rows with price, quantity, tax, attribute and accessory inputs. Test recalculation after changing product options, quantity or manual prices.

![Order lines](img/rs506-addorder-lines.png)

## Save actions

The original manual documents **Apply User**, **Cancel**, **Save + Pay** (manual payment entry), **Save without Email**, and **Save & Close** (historically sends an invoice email). Verify the exact behaviour of these buttons on the current test installation before use; button labels alone do not prove whether email or payment occurs.

![Save actions](img/rs506-addorder-save.png)

## Create an order on the storefront

Choose a product and any required options, add to cart, review quantities, shipping and tax, proceed to checkout, enter billing/shipping information, choose payment, accept terms and complete the purchase. Verify order confirmation, email and payment state.

![Checkout](img/rs506-checkout.png)

## Show order history on the storefront

The historical manual creates a Joomla menu item of redSHOP **Orders** type, selecting the `order_list` template. Publish the menu item, log in as a test customer and verify the list, **Details** and **Reorder** actions. The historical Reorder action warns it may empty the current cart; test this before documenting it as current behaviour.

![Order history](img/rs506-order-history.png)

## Show Order Tracker on the storefront

The original manual describes a redSHOP **Order Tracker** menu item, an order-ID search and a details page. Confirm that the menu type still exists. Test authorization: knowledge of an order ID must not allow access to another customer's personal information.

![Order tracker](img/rs506-order-tracker.png)

## Configure one-step checkout

Historically: **Configuration → Cart/Checkout → One Step Checkout = Yes**. Enable on a test site, then check address editing, delivery selection, payment method, terms and final confirmation for registered and guest customers where supported.

![One-step checkout](img/rs506-one-step.png)

## Troubleshooting

For incorrect totals check shopper group, tax mode, product options and discounts. For missing account creation check Create Account and required fields. For unexpected emails review the save action and status automation. For empty frontend history verify the logged-in customer owns the orders.

See [Order List](order-list.md) and [Quotations](quotations.md).
