# Stage 10 screenshot checklist

Capture only with test customers, redact personal information. Store in `manual/en-US/chapters/orders/img/`.

- [ ] rs506-addorder-customer.png
- [ ] rs506-addorder-lines.png
- [ ] rs506-addorder-save.png
- [ ] rs506-addorder.png
- [ ] rs506-checkout.png
- [ ] rs506-one-step.png
- [ ] rs506-order-details.png
- [ ] rs506-order-history.png
- [ ] rs506-order-tracker.png
- [ ] rs506-orders-bulk.png
- [ ] rs506-orders-export.png
- [ ] rs506-orders-filters.png
- [ ] rs506-orders-list.png
- [ ] rs506-product-order-filters.png
- [ ] rs506-product-order-search.png
- [ ] rs506-quotes-editor.png
- [ ] rs506-quotes-frontend.png
- [ ] rs506-quotes-list.png
- [ ] rs506-quotes-totals.png
- [ ] rs506-status-editor.png
- [ ] rs506-status-list.png
- [ ] rs506-status-update.png
