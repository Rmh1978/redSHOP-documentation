# Internal follow-up — Phase 6, About and Start Here

| ID | Status | Verification task |
| --- | --- | --- |
| DOC-6-A01 | OPEN | Verify About tab's four panels and visible labels on `/tests/redshop6`. |
| DOC-6-A02 | OPEN | Confirm installed/published indicators accurately reflect Joomla extension state, including disabled plugins. |
| DOC-6-A03 | OPEN | Verify server-information values on the running site; redact sensitive details in screenshots. |
| DOC-6-A04 | OPEN | Check whether empty module/plugin lists hide their entire tables and whether docs need a note. |
| DOC-6-S01 | OPEN | Verify exact Configuration entry point, tab names and ordering on redSHOP 5.0.6. |
| DOC-6-S02 | OPEN | Verify relative Markdown links render correctly in the published documentation site. |
| DOC-6-S03 | OPEN | Capture seven screenshots and check mobile readability. |
| DOC-6-S04 | OPEN | Confirm global-vs-record-specific override examples for each related section during later article reviews. |
