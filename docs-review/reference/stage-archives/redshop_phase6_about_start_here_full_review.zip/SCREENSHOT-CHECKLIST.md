# Screenshot checklist — Phase 6 final articles

Capture on the redSHOP 5.0.6 test site, and place files in `manual/en-US/chapters/global-configuration/img/`.

## About
- [ ] `rs506-about-overview.png` — Full About tab with four information panels.
- [ ] `rs506-about-system-information.png` — System Information table with Check and Result headings.
- [ ] `rs506-about-modules.png` — redSHOP Modules table with Check, Result and Published headings.
- [ ] `rs506-about-shipping.png` — redSHOP Shipping Plugins table.
- [ ] `rs506-about-payment.png` — redSHOP Payment Plugins table.

## Start Here
- [ ] `rs506-configuration-overview.png` — Configuration screen with the active section visible.
- [ ] `rs506-configuration-navigation.png` — Configuration tabs or navigation, showing section names.

Mask sensitive infrastructure details before publishing screenshots.
