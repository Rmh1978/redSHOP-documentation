# redSHOP Configuration — About

The **About** tab provides a read-only overview of the server environment and the redSHOP modules, shipping plugins and payment plugins detected by the shop. Use it when checking an installation, investigating an extension that is not enabled or collecting basic environment information for support.

Open **Components → redSHOP → Configuration → About** in the Joomla administrator.

![About tab overview](img/rs506-about-overview.png)

## System Information

![System information](img/rs506-about-system-information.png)

The **System Information** panel has two columns: **Check**, which identifies the property being inspected, and **Result**, which shows the value detected on the server. The following entries are displayed.

| Check | What the result means |
| --- | --- |
| **Web Server** | The web server identification reported to PHP. The exact content depends on the hosting environment. |
| **PHP Version** | The PHP version used by the running website. This is the version that executes redSHOP, which may differ from the PHP version used by other sites on the server. |
| **MySQL Version** | The version of the database server connected to Joomla. The label may say MySQL even when a compatible database engine is used. |
| **GD Image Library** | The detected GD library version, or **Disabled** when GD support is unavailable. GD is relevant to image processing and thumbnail generation. |
| **Multibyte String Support** | Indicates whether the PHP multibyte-string extension is available. This is particularly relevant for processing text with non-ASCII characters. |
| **Upload Limit** | The PHP `upload_max_filesize` setting. This is one limit affecting uploaded files; other PHP and web-server limits may also apply. |
| **Memory Limit** | The PHP `memory_limit` setting, which controls the amount of memory a PHP request may allocate. |
| **Open Remote Files** | Whether PHP's `allow_url_fopen` setting is enabled. This controls access to URL-based file streams and should be configured according to the site's security and integration requirements. |
| **Execution Time** | The PHP `max_execution_time` value, usually in seconds. It limits script execution time, although web-server and hosting timeouts can impose additional limits. |

### Understanding upload and processing limits

A file may fail to upload even when its size is below **Upload Limit**. For example, PHP's `post_max_size` may be lower than the total submitted request size, or the web server may impose its own request limit.

Likewise, increasing **Execution Time** does not guarantee that a long-running import or image operation will complete: memory limits and upstream timeouts still apply.

The About tab reports these values; it does not change PHP configuration. Adjust server settings through your hosting control panel or with your server administrator.

### Multibyte strings and special characters

If product names or descriptions containing accented or non-Latin characters behave unexpectedly, check **Multibyte String Support**. An enabled result indicates that the required PHP extension is available; it does not by itself confirm that every database or template encoding setting is correct.

## redSHOP Modules

![Installed modules](img/rs506-about-modules.png)

The **redSHOP Modules** panel lists detected redSHOP-related Joomla modules. Each row includes:

- **Check:** the module's name.
- **Result:** the installation status, commonly **Installed** or **Not Installed**.
- **Published:** a status indicator showing whether the module is enabled.

An installed module is not necessarily displayed on the storefront. Joomla modules also depend on their module assignment, menu assignment, access level and template position.

### A module is installed but not visible

1. Check its **Published** indicator in the About tab.
2. Open the module in Joomla's module manager.
3. Confirm that it is enabled, assigned to the intended menu items and uses a position rendered by your template.
4. Check its access level and any module-specific options.
5. Reload the relevant storefront page.

## redSHOP Shipping Plugins

![Shipping plugins](img/rs506-about-shipping.png)

This panel lists detected redSHOP shipping plugins. The columns are:

- **Check:** shipping plugin name.
- **Result:** installation status.
- **Published:** whether the plugin is enabled.

A shipping plugin being installed and enabled does not guarantee that its method will be offered at checkout. Shipping methods can depend on configuration, customer address, country, order contents and other eligibility rules.

### A shipping method is missing at checkout

1. Confirm that its plugin appears in the About tab.
2. Check the **Published** indicator.
3. Review the plugin's configuration and the associated shipping method.
4. Test checkout using an address and cart that meet the method's restrictions.
5. Review any errors recorded by Joomla or the shipping integration.

See [Shipping methods](../shipping/shipping-methods.md) for further guidance.

## redSHOP Payment Plugins

![Payment plugins](img/rs506-about-payment.png)

The **redSHOP Payment Plugins** panel shows detected payment plugins using the same three columns:

- **Check:** payment plugin name.
- **Result:** installation status.
- **Published:** whether the plugin is enabled.

An enabled payment plugin may still require credentials, supported currencies, configured countries or other conditions before customers can use it.

### A payment method is missing at checkout

1. Confirm that the plugin is listed.
2. Check its **Published** status.
3. Review the payment plugin settings, including test/live credentials where applicable.
4. Confirm that the checkout order meets the method's availability rules.
5. Test with a non-production payment method or sandbox account when supported.

## When to use the About tab

The About tab is useful before an upgrade, after moving a website to another server, when investigating failed uploads or missing images, and when checking whether a shipping or payment extension is installed and enabled.

When sharing a screenshot for support, review it first for hostnames, server details or other information you do not wish to disclose.

## Related documentation

- [Global Configuration overview](overview-global-configuration.md)
- [Installing redSHOP](../getting-started-general/installing-redshop.md)
- [Updating redSHOP](../getting-started-general/updating-redshop.md)
- [Shipping methods](../shipping/shipping-methods.md)
