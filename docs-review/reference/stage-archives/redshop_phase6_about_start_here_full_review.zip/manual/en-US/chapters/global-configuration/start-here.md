# redSHOP Configuration — Start Here

redSHOP provides global settings for the store, customer accounts, product presentation, checkout, order handling and integrations. The configuration is divided into sections so that administrators can adjust each area independently.

This guide explains how to open the configuration, what each section covers and how to approach changes safely.

## Open Global Configuration

1. Sign in to the **Joomla administrator** using an account with permission to manage redSHOP.
2. Open **Components → redSHOP**.
3. Select **Configuration** from the redSHOP administration interface.
4. Choose the section you want to review.
5. Make the required changes and use the available **Save** action.

![Global Configuration overview](img/rs506-configuration-overview.png)

The available sections depend on the installed redSHOP version and any customization. Some settings are shown only when a related feature is enabled.

## Configuration sections

![Configuration navigation](img/rs506-configuration-navigation.png)

| Section | Purpose |
| --- | --- |
| [General](general.md) | Shop-wide defaults such as store information and general presentation settings. |
| [User](user.md) | Customer registration, account behaviour and shopper-group options. |
| [Categories](categories.md) | Category ordering, descriptions, navigation, templates and images. |
| [Manufacturers](manufacturers.md) | Manufacturer display templates, ordering, notifications and image sizes. |
| [Products](products.md) | Product display and management defaults, including product-related options. |
| [Feature Settings](feature-settings.md) | Optional storefront features such as reviews, comparisons and stock-related behaviour. |
| [Price](price.md) | Currencies, tax-related settings and discount behaviour. |
| [Cart / Checkout](cart.md) | Shopping cart, checkout and stock-related settings. |
| [Orders](orders.md) | Order handling and order-related notification settings. |
| [Newsletter](newsletter.md) | Newsletter opt-in, sender identity, mailing batches and test messages. |
| [Integration](integration.md) | Settings for supported external services and integrations. |
| [SEO](seo.md) | Search-engine-friendly URLs and metadata defaults. |
| [Dashboard](dashboard.md) | Dashboard information, statistics and shortcut settings. |
| [About](about.md) | Server information and detected redSHOP modules, shipping plugins and payment plugins. |

## Recommended setup order

For a new shop, a practical approach is to start with the **General** and **User** sections, then configure **Categories**, **Manufacturers** and **Products**. Review **Price** and **Cart / Checkout** before accepting orders, followed by **Orders** and the relevant payment and shipping integrations.

**SEO**, **Newsletter**, **Feature Settings** and **Dashboard** can then be tailored to the shop's requirements. Use **About** to inspect the environment and installed extensions.

This is a suggested workflow rather than a required sequence. For an existing store, change only the settings relevant to the task at hand.

## Before changing a setting

- Record the current value of any setting you intend to change.
- Back up the site and database before making significant configuration changes.
- Use a staging or test site when changing checkout, prices, tax, stock or payment settings.
- Check whether a category, manufacturer, product, template or menu item has its own setting that overrides the global default.
- After saving, test the affected storefront page or checkout flow.

## How global defaults interact with individual records

Many global configuration settings define the default behaviour of the shop. A more specific setting on an individual category, manufacturer, product or menu item may override that default.

For example, changing the default manufacturer template does not necessarily change the appearance of a manufacturer that has its own template selection.

## Saving and checking changes

1. Select the configuration section.
2. Change one or a small number of related settings.
3. Save the configuration.
4. Reload the configuration screen to confirm the values were retained.
5. Open the relevant storefront page and verify the result.
6. If the result is unexpected, check for a more specific override, caching or a template-specific setting.

For changes that affect email, checkout, shipping or payment, verify the actual workflow using safe test data rather than relying only on the configuration screen.

## Where to find more help

Each section in the table above links to its dedicated article. The **About** section is particularly useful when troubleshooting server configuration or installed extensions.

