# Phase 6 — final two articles

Included:
- `manual/en-US/chapters/global-configuration/about.md`
- `manual/en-US/chapters/global-configuration/start-here.md`

Both replace existing documentation. The About article preserves all four original panels and every System Information field. The Start Here article preserves links to all 14 original configuration topics and corrects their relative paths.

Reviewed against the original public documentation and the redSHOP `develop` templates:
- `component/admin/tmpl/configuration/default_redshopabout.php`
- `component/admin/tmpl/configuration/default_system_information.php`
- `component/admin/tmpl/configuration/default_redshop_modules.php`
- `component/admin/tmpl/configuration/default_redshop_shipping.php`
- `component/admin/tmpl/configuration/default_redshop_plugins.php`
- `component/admin/tmpl/configuration/default.php`

Live UI and end-to-end checks remain in the internal tracker. Screenshots are not included. No repository changes were made.
