# e-conomic screenshot and test checklist

- [ ] Integration settings without credentials
- [ ] Account group list and edit view
- [ ] Test product synchronization
- [ ] Test invoice draft and booked invoice
- [ ] Error and retry logs (redacted)
