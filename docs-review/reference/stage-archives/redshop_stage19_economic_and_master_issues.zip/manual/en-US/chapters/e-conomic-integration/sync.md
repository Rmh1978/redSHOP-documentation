# Synchronize products from redSHOP to e-conomic

The original manual describes synchronization of products from redSHOP to e-conomic. The repository contains a legacy `Economic` helper, but the actual synchronization endpoint, direction, scheduling and API compatibility need a full code review.

## Test plan

1. Back up product and accounting data in both test systems.
2. Create a uniquely identifiable test product.
3. Trigger synchronization only in the test environment.
4. Compare product numbers, names, prices, tax mappings and account-group assignment.
5. Repeat with an updated product to check update-versus-create behaviour.
6. Test failures, retries, duplicate prevention and logging.
7. Verify whether synchronization is one-way or bidirectional before documenting that claim.

**Not verified:** sync endpoint, plugin installation, credentials, product mapping, batch size, retry and conflict handling.

Sources: original `sync.md` (`gh-pages`), `libraries/redshop/src/Helper/Economic.php` (`develop`).
