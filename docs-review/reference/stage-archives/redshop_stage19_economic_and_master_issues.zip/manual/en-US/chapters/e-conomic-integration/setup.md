# Set up e-conomic integration

The original manual refers to configuration in redSHOP and an e-conomic plugin. The current repository includes `component/admin/tmpl/configuration/default_economic.php`.

## Configuration fields identified in current template

- `economic_integration` — integration enablement setting
- `economic_invoice_draft` — invoice draft setting
- `economic_book_invoice_number` — invoice-number booking setting
- `economic_account_group` — account-group mapping setting

## Safe verification procedure

1. Confirm that the required integration plugin is present and compatible with the installed Joomla version.
2. Review current e-conomic API authentication and permissions; never paste credentials into documentation.
3. Use a dedicated test account and non-production order.
4. Confirm invoice draft versus booking behaviour and numbering.
5. Verify VAT, shipping, discounts, payment and refund mappings.
6. Check error handling, duplicate submission protection and retries before enabling automated posting.

**Not verified:** plugin availability, authentication, network calls, current API support and production settings.

Sources: original `setup.md` (`gh-pages`), current `default_economic.php` (`develop`).
