# Account Group

The redSHOP administrator contains Account Group controllers, models, a table and an edit view. The current `component/admin/tmpl/accountgroup/edit.php` references these accounting mappings:

| Mapping | Setting |
|---|---|
| Taxable sales | `economic_vat_account` |
| Non-taxable sales | `economic_nonvat_account` |
| Discount product | `economic_discount_product_number` |
| Taxable discounts | `economic_discount_vat_account` |
| Non-taxable discounts | `economic_discount_nonvat_account` |
| Taxable shipping | `economic_shipping_vat_account` |
| Non-taxable shipping | `economic_shipping_nonvat_account` |

## Verification workflow

1. Create or inspect a test account group.
2. Compare all mapping numbers with the test accounting chart of accounts.
3. Test taxable and non-taxable products, shipping and discounts.
4. Verify invoice lines, VAT totals, balancing and correct credit-note behaviour.
5. Confirm the administrator form validates required mappings and respects user permissions.

**Not verified:** whether these mappings are all mandatory or which runtime events use each mapping.

Sources: original `account-group.md` (`gh-pages`), `component/admin/tmpl/accountgroup/edit.php` (`develop`).
