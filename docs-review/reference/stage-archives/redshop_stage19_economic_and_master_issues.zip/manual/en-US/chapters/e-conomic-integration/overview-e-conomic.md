# e-conomic Integration

redSHOP includes legacy e-conomic integration configuration and account-group mappings. The `develop` branch contains `libraries/redshop/src/Helper/Economic.php`, administrator settings, and account-group views.

**Review status:** Source presence is confirmed, but the actual integration's API compatibility, supported authentication and current operability have not been verified. Do not enable production invoice posting on the strength of this guide.

See [Setup](setup.md), [Account Group](account-group.md) and [Product Synchronization](sync.md).
