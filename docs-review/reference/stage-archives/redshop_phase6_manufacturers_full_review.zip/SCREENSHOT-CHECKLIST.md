# Screenshot checklist — Manufacturers configuration

Take screenshots in the redSHOP 5.0.6 Joomla administrator. Save the files in `manual/en-US/chapters/global-configuration/img/`.

- [ ] `rs506-manufacturers-overview.png` — Full Manufacturers configuration tab, showing both settings groups.
- [ ] `rs506-manufacturers-settings.png` — Manufacturer Settings panel, including template, both sorting fields, title length/suffix and email toggles.
- [ ] `rs506-manufacturers-images.png` — Manufacturer Image Settings panel, showing both watermark toggles and all four width/height pairs.

Before taking screenshots, avoid exposing real customer data, email addresses or credentials. Check field labels and option names against the running test site.
