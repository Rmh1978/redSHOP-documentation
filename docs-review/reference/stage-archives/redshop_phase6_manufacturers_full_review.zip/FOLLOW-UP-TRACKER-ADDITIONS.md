# Internal follow-up — Manufacturers

| ID | Status | Task |
| --- | --- | --- |
| DOC-6-M01 | OPEN | Verify actual dropdown choices for manufacturer ordering and manufacturer product ordering on redSHOP 5.0.6. |
| DOC-6-M02 | OPEN | Test manufacturer-specific template override precedence. |
| DOC-6-M03 | OPEN | Test manufacturer and supplier email delivery using safe test accounts; confirm event/trigger and templates. |
| DOC-6-M04 | OPEN | Verify title truncation and suffix behaviour in active frontend templates. |
| DOC-6-M05 | OPEN | Confirm mapping of all three manufacturer product thumbnail dimension pairs to frontend layouts and image cache behaviour. |
| DOC-6-M06 | OPEN | Verify watermark application and required watermark image configuration. |
| DOC-6-M07 | OPEN | Capture and review three screenshots from `/tests/redshop6`. |
