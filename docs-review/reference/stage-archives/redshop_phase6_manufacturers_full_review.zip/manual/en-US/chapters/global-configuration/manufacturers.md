# redSHOP Configuration — Manufacturers

The **Manufacturers** section of redSHOP's global configuration controls the default presentation of manufacturer pages, sorting, notification settings and manufacturer image sizes. These defaults apply across the shop; individual manufacturer records and templates may provide more specific settings.

Open **Components → redSHOP → Configuration → Manufacturers** in the Joomla administrator. Review the settings described below and select **Save** or **Save & Close** to apply changes.

![Manufacturers configuration overview](img/rs506-manufacturers-overview.png)

## Manufacturer settings

![Manufacturer settings](img/rs506-manufacturers-settings.png)

### Default Manufacturer Template

Choose the default template used to display products associated with a manufacturer. The available choices depend on the manufacturer-related templates configured in your shop.

A manufacturer-specific template can take precedence where the manufacturer record provides an override. To check the appearance, open a manufacturer page on the storefront after saving your changes.

### Default Sorting of Manufacturers

Controls the initial ordering of manufacturers in a manufacturer listing. Depending on the choices available in your installation, ordering may be based on:

- **Alphabetical order:** manufacturers appear by name.
- **Newest:** recently created manufacturers appear first.
- **Manual order:** follows the ordering maintained by the administrator.

The configured default is the starting order; a storefront template may offer visitors a separate sorting control.

### Default Sorting of Products in Manufacturer View

Controls the initial order of products displayed for a manufacturer. Common choices documented for redSHOP include:

- **Product name:** alphabetical order.
- **Price ascending:** lowest price first.
- **Price descending:** highest price first.
- **Product number:** order by the product's SKU or number.
- **Newest:** recently created products first.
- **Manual order:** administrator-defined order.

Select the option that best suits your catalogue. For example, a price-based default can be useful when customers compare several similar products. The exact choices presented depend on the installed version and configuration.

### Max. Characters for Manufacturer Title

Limits the length of a manufacturer title when displayed in a layout that uses this setting.

For example, a value of `40` is intended to limit the displayed title to 40 characters. A shortened title may end in the middle of a word, so choose a limit that works with the available space in your design.

### Manufacturer Title Suffix

Enter the text appended when a manufacturer title is shortened. For example, enter `...` to indicate that the full title continues.

Use this setting together with **Max. Characters for Manufacturer Title**. If titles are already short enough, the suffix may not appear.

### Enable Manufacturer Email

Enable this option if manufacturers should receive notifications relating to orders for their products.

For the notification to be useful, the product must be associated with the appropriate manufacturer and the manufacturer record must contain a valid email address. Configure the shop's outgoing email settings in Joomla as well.

**Available options:** Yes / No.

### Enable Supplier Email

Enable this option if suppliers should receive notifications relating to orders for products associated with them.

Make sure the relevant products are assigned to suppliers and that the supplier contact details are complete. Supplier notifications are distinct from manufacturer notifications; enable only the recipients you need.

**Available options:** Yes / No.

## Manufacturer image settings

![Manufacturer image settings](img/rs506-manufacturers-images.png)

These settings control watermark preferences and the dimensions used for manufacturer-related thumbnails. Image sizes are entered as separate width and height values.

### Watermark Manufacturer Image

Choose whether watermarking is enabled for manufacturer images. This setting is useful if you want to brand images shown in manufacturer views.

**Available options:** Yes / No.

### Watermark Manufacturer Thumb Image

Choose whether watermarking is enabled for manufacturer thumbnail images. This is separate from the full manufacturer-image setting, allowing different treatment of thumbnails.

**Available options:** Yes / No.

Watermarking also depends on the watermark image and image-processing configuration used by the shop. After enabling either option, inspect an actual storefront image to confirm the expected result.

### Manufacturer Thumbnail Width / Height

Enter the target **width** and **height** for manufacturer thumbnails. These values control the dimensions requested for the thumbnail output.

For example, a square design may use matching width and height values. Choose dimensions appropriate for your storefront layout and image quality.

### Manufacturer Product Thumbnail #1 Width / Height

Set the first pair of dimensions for product thumbnails shown in manufacturer-related layouts. Both width and height are configurable.

### Manufacturer Product Thumbnail #2 Width / Height

Set the second pair of product thumbnail dimensions. This allows another manufacturer-related layout or image placement to use a different size.

### Manufacturer Product Thumbnail #3 Width / Height

Set the third pair of product thumbnail dimensions. Use it where the corresponding layout requires a separate image size.

The three product-thumbnail size pairs are independent settings. The actual size used on a page depends on the template and the image variant requested by that page.

## Example: configure a manufacturer listing

1. Open **Components → redSHOP → Configuration → Manufacturers**.
2. Select the **Default Manufacturer Template** that matches your storefront design.
3. Choose how manufacturers and their products should be sorted by default.
4. Set a manufacturer-title character limit and suffix if your layout needs shortened names.
5. Decide whether manufacturer or supplier emails should be enabled.
6. Enter manufacturer and product thumbnail dimensions that fit your layout.
7. Enable watermarking only if you have configured the watermark image and want it applied.
8. Save the configuration.
9. Open a manufacturer listing and a manufacturer product page on the storefront. Check ordering, titles and images at desktop and mobile widths.

## Troubleshooting

### The manufacturer page uses a different layout

Check whether the individual manufacturer has a template override. Also verify that the Joomla menu item points to the intended manufacturer view.

### Product ordering does not match the default

Check whether the storefront provides its own sorting selection or the active template applies another ordering rule.

### Notification emails are not received

Check the manufacturer or supplier association, the recipient email address, Joomla's outgoing mail configuration and the relevant notification option. A successful configuration save alone does not confirm delivery.

### Thumbnails look stretched, blurry or inconsistent

Review the configured width and height, the quality and aspect ratio of the original image, and the dimensions used by the active storefront template. Test the result with a newly uploaded image if an existing thumbnail appears unchanged.

## Related documentation

- [Global Configuration overview](overview-global-configuration.md)
- [Products configuration](products.md)
- [Working with manufacturers](../product-management/redshop-manufacturers.md)

More examples and screenshots will be added in a future update.
