# redSHOP documentation — Phase 6, Manufacturers

Replaces `manual/en-US/chapters/global-configuration/manufacturers.md`.

Reviewed against the original public documentation and the `develop` branch files:
- `component/admin/tmpl/configuration/default_manufacturertab.php`
- `component/admin/tmpl/configuration/default_manufacturer_setting.php`
- `component/admin/tmpl/configuration/default_manufacturer_image_setting.php`

The article preserves the original topics and provides additional guidance. UI-only and behavioural details that require a running-site test are tracked separately. No live test or GitHub modification was performed.

The three screenshot references are placeholders until screenshots are captured.
