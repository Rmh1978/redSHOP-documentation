# Integration Configuration

> **Documentation version:** redSHOP 5.0.6 · **Applies to:** Joomla 5.4 · **UI verification:** Pending.

The **Integration** configuration tab contains legacy integration sections. Additional integrations may be delivered as separate Joomla plugins and therefore **will not necessarily appear in this tab**.

![Integration overview](img/rs506-integration-overview.png)

## Settings shown in the Integration tab

The current PHP template loads sections for **GLS**, **Clickatell**, **Post Danmark**, and **e-conomic**. The presence of a settings section does not guarantee that an external provider's current API is supported. Verify credentials, connectivity and successful transactions before enabling any legacy integration.

![Integration settings](img/rs506-integration-legacy.png)

## Integrations delivered as plugins

The redSHOP 5.0.6 component manifest lists separate integration-related plugins, including **Billy** accounting and **PostNord Shipment**, plus payment plugins such as **Bambora** and **Flatpay**, and the **PostNord Pickup Point** shipping plugin. The manifest also includes a **Relatel** system plugin. These should be documented in dedicated plugin articles, with their own prerequisites and screenshots, after verifying each plugin's actual configuration and behavior.

To locate an installed plugin, open **System → Manage → Plugins** in Joomla and search for the provider or redSHOP plugin group. Plugin availability and enabled status may vary by installation.

![Installed redSHOP plugins](img/rs506-integration-plugins.png)

## Security and maintenance

Keep API credentials out of screenshots and public documentation. Use separate test accounts where available, and verify order/payment callbacks and external error handling before using an integration on a live store.

**Code references:** `component/admin/tmpl/configuration/default_integration.php`, `redshop.xml`, `plugins/redshop_integrations/`, `plugins/redshop_payment/`, `plugins/redshop_shipping/`.
