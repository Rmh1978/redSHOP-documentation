# Phase 4–5 source audit notes

Source branch: `Rmh1978/redSHOP-rmh` / `develop`; manifest version 5.0.6. Legacy articles: `Rmh1978/redSHOP-documentation` / `gh-pages`.

Verified directly: configuration PHP templates and section names, visible field labels, integration plugin manifest entries.

Not yet verified: actual frontend behavior, dynamic option values, live admin screenshots, external provider APIs, full data flow through models and controllers, Joomla 6 compatibility.

The old manuals contained many outdated screenshots and assertions about behavior. New articles avoid promising behavior not demonstrated by the inspected templates.

No GitHub files have been changed. The release process is intentionally not documented in the public manual.
