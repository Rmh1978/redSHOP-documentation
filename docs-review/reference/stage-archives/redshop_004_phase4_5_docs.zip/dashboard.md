# Dashboard Configuration

> **Documentation version:** redSHOP 5.0.6 · **Applies to:** Joomla 5.4 · **UI verification:** Pending.

The **Dashboard** configuration tab contains settings for showing or hiding administrative menu entries. It should not be confused with the dashboard's reporting widgets or the Joomla administrator's own dashboard.

![Dashboard configuration](img/rs506-dashboard-configuration.png)

## Configuring menu visibility

Open **Components → redSHOP → Configuration → Dashboard**. The current configuration template loads a dedicated **Menu Hide** section. Select the entries you want to hide or display and save the configuration.

![Menu visibility settings](img/rs506-dashboard-menu-visibility.png)

The available entries depend on the installed redSHOP build and extensions. Avoid relying on the legacy guide's fixed list of sections: take the current list from your running administrator interface.

## Important distinction: visibility versus permissions

Hiding a menu entry is a presentation choice, **not an access-control mechanism**. Use Joomla permissions and redSHOP's supported authorization controls to restrict administrative actions. Verify access with a test user who has limited permissions.

## Verification

After saving, reload the redSHOP dashboard and check that the intended entries are shown or hidden. Verify that navigation still works for administrators who need the affected functions.

**Code references:** `component/admin/tmpl/configuration/default_dashboard.php`, `default_menuhide.php`, `component/admin/tmpl/redshop/default.php`.
