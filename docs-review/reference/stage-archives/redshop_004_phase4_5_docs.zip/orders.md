# Order and Invoice Configuration

> **Documentation version:** redSHOP 5.0.6 · **Applies to:** Joomla 5.4 · **UI verification:** Pending.

Open **Components → redSHOP → Configuration → Orders** to manage order email and invoice settings.

![Order configuration overview](img/rs506-orders-overview.png)

## Order settings

![Order settings](img/rs506-orders-settings.png)

- **Order ID Reset** — a maintenance action relating to order numbering. Do not use on a live store without first checking existing order records and taking a database backup.
- **Send Order Email** — selects when order notifications are dispatched relative to payment. Confirm the behavior with the active payment plugin, including failed or delayed payment callbacks.
- **Enable Invoice Email** — controls invoice email sending.
- **Send Invoice Mail To** — selects the invoice email recipients.
- **Send Mail to Customer** — controls customer-facing order communication.
- **Exclude Products from Reorder** — selects products that should not be offered through the reorder workflow. This setting is present in redSHOP 5.0.6 and was missing from the old guide.

## Invoice settings

![Invoice settings](img/rs506-orders-invoices.png)

- **First Invoice Number** — starting value used by invoice numbering logic.
- **Order Number Template** — controls the configured order-number format.
- **Invoice Number Template** — controls the configured invoice-number format.
- **Invoice Number for Free Orders** — configures numbering behavior for orders without a payable total.

**Important:** Invoice numbering and accounting obligations vary by jurisdiction. Verify the resulting sequence, uniqueness and formatting before enabling the store for real orders.

## Recommended test

Create test orders with successful payment, failed payment and zero-value totals. Check the order status, invoice number, recipient addresses and the number of messages sent. Repeat the test after changing payment providers.

**Code reference:** `component/admin/tmpl/configuration/default_ordertab.php`.
