# Feature Settings

> **Documentation version:** redSHOP 5.0.6 · **Applies to:** Joomla 5.4 · **UI verification:** Pending.

The **Features** configuration tab contains independent sections for product ratings, import/export, inline editing, product comparisons, stockrooms and wishlists.

![Features overview](img/rs506-features-overview.png)

## Ratings and reviews

![Rating settings](img/rs506-features-ratings.png)

The configuration includes a **review completion message**, **number of favoured reviews**, **rating thumbnail dimensions**, and a **login required for reviews** option. Review display and submission must also be checked against the active frontend template.

## Import and export

![Import settings](img/rs506-features-import.png)

Import configuration includes file-size constraints, accepted MIME types and extensions, and a maximum-line setting. Treat these as configuration controls, not proof that every file type is safe or supported. Always test imports with a small sample and take a backup before bulk updates.

## Inline editing

The **Inline Editing** switch is present in the configuration template. Verify the specific admin screens on which editing is available before documenting a workflow.

## Product comparison

![Comparison settings](img/rs506-features-comparison.png)

Settings include enabling comparisons, a product comparison limit, a comparison type, a comparison template and image dimensions. Availability on the storefront depends on the selected template.

## Stockrooms

![Stockroom settings](img/rs506-features-stockrooms.png)

Settings include **Use Stockroom**, **Treat Blank as Infinite**, **Default Stockroom**, stock image dimensions, an out-of-stock image option, stock notifications and a low-stock threshold. Test stock deductions, reservations and notifications together before relying on stock availability.

## Wishlists

![Wishlist settings](img/rs506-features-wishlist.png)

The template provides **Enable Wishlist**, **Login Required** and a wishlist list setting. Check both guest and logged-in behavior.

**Code references:** `component/admin/tmpl/configuration/default_featuretab.php`, `default_rating_settings.php`, `default_feature_import_export.php`, `default_feature_inline_edit.php`, `default_comparison_settings.php`, `default_stockroom_settings.php`, `default_wishlist_settings.php`.
