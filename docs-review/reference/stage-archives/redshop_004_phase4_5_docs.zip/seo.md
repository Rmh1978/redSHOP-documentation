# SEO Configuration

> **Documentation version:** redSHOP 5.0.6 · **Applies to:** Joomla 5.4 · **UI verification:** Pending.

redSHOP provides configuration for search-engine-friendly URLs and automatically generated metadata. Open **Components → redSHOP → Configuration → SEO**.

![SEO configuration overview](img/rs506-seo-overview.png)

## General SEO settings

![General SEO settings](img/rs506-seo-general.png)

The current template exposes the following options:

- **Include Product Number in SEF URL**.
- **SEF Number/Name option**.
- **Include Category in SEF URL**.
- **Include Category Tree in SEF URL**.
- **Automatically Generated SEO**.
- **SEO Page Language**.

It also provides menu-item mappings for account, billing and shipping addresses, cart, checkout, gift cards, manufacturers, order details, orders, quotations, registration and wishlists. These mappings can affect routing and menu context.

**Changing SEF settings can change existing URLs.** On an established store, plan redirects and verify canonical URLs, multilingual routes and sitemap links before deploying changes.

## Category, product and manufacturer SEO

![Product SEO settings](img/rs506-seo-products.png)

Separate sections configure category, product and manufacturer metadata. Use them to define fallback metadata where item-specific values are absent. Review the generated HTML on representative frontend pages.

## Available SEO placeholders

The current SEO configuration template includes placeholder descriptions for product, manufacturer and category names; category hierarchy; sale price and savings; shop name; product SKU; and short descriptions. The available set varies by metadata field (title, heading, description or keywords). **Use the placeholder syntax shown in your running admin interface** rather than assuming a token is supported everywhere.

## Validation

Check product and category URLs, multilingual variants, page title, meta description, canonical link and redirects. Verify that changing a product's name does not unexpectedly break inbound links.

**Code references:** `component/admin/tmpl/configuration/default_seo.php`, `default_seo_general.php`, `default_seo_category.php`, `default_seo_product.php`, `default_seo_manufacturer.php`.
