# Screenshot checklist — Etape 004, del 4 og 5

**Image directory:** `manual/en-US/chapters/global-configuration/img/`

Take screenshots from the actual Joomla 5.4/redSHOP 5.0.6 test installation. Do not include customer data, license keys or API secrets.

| Article | Filename | Screen to capture |
|---|---|---|
| `cart.md` | `rs506-cart-overview.png` | Cart configuration overview; locate the corresponding redSHOP configuration section |
| `cart.md` | `rs506-cart-add-to-cart.png` | Add to Cart settings; locate the corresponding redSHOP configuration section |
| `cart.md` | `rs506-cart-settings.png` | Cart settings; locate the corresponding redSHOP configuration section |
| `cart.md` | `rs506-cart-payment-shipping.png` | Payment and shipping settings; locate the corresponding redSHOP configuration section |
| `cart.md` | `rs506-cart-images.png` | Cart image settings; locate the corresponding redSHOP configuration section |
| `orders.md` | `rs506-orders-overview.png` | Order configuration overview; locate the corresponding redSHOP configuration section |
| `orders.md` | `rs506-orders-settings.png` | Order settings; locate the corresponding redSHOP configuration section |
| `orders.md` | `rs506-orders-invoices.png` | Invoice settings; locate the corresponding redSHOP configuration section |
| `feature-settings.md` | `rs506-features-overview.png` | Features overview; locate the corresponding redSHOP configuration section |
| `feature-settings.md` | `rs506-features-ratings.png` | Rating settings; locate the corresponding redSHOP configuration section |
| `feature-settings.md` | `rs506-features-import.png` | Import settings; locate the corresponding redSHOP configuration section |
| `feature-settings.md` | `rs506-features-comparison.png` | Comparison settings; locate the corresponding redSHOP configuration section |
| `feature-settings.md` | `rs506-features-stockrooms.png` | Stockroom settings; locate the corresponding redSHOP configuration section |
| `feature-settings.md` | `rs506-features-wishlist.png` | Wishlist settings; locate the corresponding redSHOP configuration section |
| `seo.md` | `rs506-seo-overview.png` | SEO configuration overview; locate the corresponding redSHOP configuration section |
| `seo.md` | `rs506-seo-general.png` | General SEO settings; locate the corresponding redSHOP configuration section |
| `seo.md` | `rs506-seo-products.png` | Product SEO settings; locate the corresponding redSHOP configuration section |
| `integration.md` | `rs506-integration-overview.png` | Integration overview; locate the corresponding redSHOP configuration section |
| `integration.md` | `rs506-integration-legacy.png` | Integration settings; locate the corresponding redSHOP configuration section |
| `integration.md` | `rs506-integration-plugins.png` | Installed redSHOP plugins; locate the corresponding redSHOP configuration section |
| `dashboard.md` | `rs506-dashboard-configuration.png` | Dashboard configuration; locate the corresponding redSHOP configuration section |
| `dashboard.md` | `rs506-dashboard-menu-visibility.png` | Menu visibility settings; locate the corresponding redSHOP configuration section |

## Important

For screens that cannot be reached in the current test site, leave the image missing and note the reason; do not fabricate screenshots. The Markdown uses relative `img/` links.

## Copy paths

Copy each `.md` to `manual/en-US/chapters/global-configuration/` and all images to `manual/en-US/chapters/global-configuration/img/`.
