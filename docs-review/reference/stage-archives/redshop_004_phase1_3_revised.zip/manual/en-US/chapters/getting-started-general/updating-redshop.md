# Updating redSHOP

Keep redSHOP updated to receive compatible improvements and fixes. Always test an update on a staging copy of your website before updating a production store.

## Before updating

1. Make a complete backup of the website **and database**.
2. Record the installed Joomla, PHP, and redSHOP versions.
3. Review the changelog and compatibility notes for the target release.
4. Check that installed payment, shipping, and other redSHOP plugins are compatible.
5. Verify checkout, payment, shipping, and order emails on a staging copy.

## Method A: Joomla Updates

The redSHOP 5.0.6 manifest declares a Joomla update server and a download-key parameter (`dlid`). Availability of a specific update depends on the configured update service, release publication, and any required subscription or download-key authorization.

1. Open **System → Update → Extensions** in Joomla administration.
2. Check whether a redSHOP update is listed.
3. If Joomla requests a download key, use the key provided for your redSHOP subscription. Never publish a download key in a screenshot or support request.
4. Review the proposed version and any compatibility information.
5. Run the update and wait for Joomla to report the result.
6. Follow any additional redSHOP update steps displayed after the Joomla update, if applicable.

![Joomla extension updates showing redSHOP](./manual/en-US/chapters/getting-started-general/img/rs506-update-available.png)

![Joomla download-key configuration if requested](./manual/en-US/chapters/getting-started-general/img/rs506-update-download-key.png)

If no update is listed, check the release information supplied with your redSHOP package.

## Method B: Install the newer release ZIP

If you have been supplied with an appropriate redSHOP update ZIP:

1. Confirm that the package is intended to upgrade your currently installed redSHOP version.
2. Open **System → Install → Extensions**.
3. Upload the supplied ZIP using **Upload Package File**.
4. Review the result and complete any additional redSHOP update steps that appear.
5. Confirm that the installed version matches the intended release.

![Joomla extension installer used for a redSHOP upgrade](./manual/en-US/chapters/getting-started-general/img/rs506-update-package.png)

## After updating

- Open redSHOP administration and check for installation/update warnings.
- Verify products, categories, prices, taxes, stock, and media.
- Test customer login, cart, checkout, payment, shipping, and order notifications.
- Review integration plugins and scheduled tasks that your store uses.
- Check Joomla logs for new errors.

![Installed redSHOP version in Joomla Extensions](./manual/en-US/chapters/getting-started-general/img/rs506-update-version.png)

## If the update fails

Do not repeatedly retry a failed production update without understanding the error. Save the exact message, inspect the Joomla/PHP logs, and compare the installed and target versions. Restore the full backup if necessary.

After an update, check the installed version and confirm that the shop works correctly before accepting live orders.

## Older versions

Instructions for upgrading redSHOP 1.x on Joomla 2.5 or Joomla 3 are **historical** and are not valid upgrade instructions for redSHOP 5.0.6. Upgrading from such an old installation requires a separately tested migration path.

## Related articles

- [System requirements](./manual/en-US/chapters/getting-started-general/redshop-minimum-requirements.md)
- [Installing redSHOP](./manual/en-US/chapters/getting-started-general/installing-redshop.md)
