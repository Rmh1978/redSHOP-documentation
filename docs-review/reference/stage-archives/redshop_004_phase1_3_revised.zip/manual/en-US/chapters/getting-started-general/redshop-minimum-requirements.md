# redSHOP system requirements

redSHOP is a Joomla e-commerce component. Your server must meet the requirements of both Joomla and the installed redSHOP release.

## Supported environment

| Software | Status for redSHOP 5.0.6 |
| --- | --- |
| Joomla 5.4 | Documented compatibility target |
| PHP 8.2 | Current documented minimum PHP target |
| Joomla 6 | Compatibility information coming soon |
| Database | Use a database server supported by the selected Joomla version; redSHOP's installation includes MySQL SQL scripts. Check the database requirements for your Joomla version. |
| Web server | Use a server configuration supported by Joomla.  |

**Important:** Check the compatibility information for your specific redSHOP release and any additional payment or shipping extensions before upgrading PHP or Joomla.

## Before installation

1. Confirm the Joomla and PHP versions in **System → System Information**.
2. Verify that your database server is supported by the installed Joomla version.
3. Confirm that Joomla can write to its required temporary and log directories.
4. Ensure the web server can install a Joomla extension ZIP package.
5. Take a full backup before installing redSHOP on an existing production website.
6. Check any required payment, shipping, or accounting integrations separately. They may have additional prerequisites.

![Joomla System Information showing PHP and database versions](./manual/en-US/chapters/getting-started-general/img/rs506-system-information.png)

## Installation package

The redSHOP installation package includes the main component and supporting extensions. The exact selection of modules and plugins depends on the release package.

Older redSHOP releases have different system requirements.

## Related articles

- [Installing redSHOP](./manual/en-US/chapters/getting-started-general/installing-redshop.md)
- [Updating redSHOP](./manual/en-US/chapters/getting-started-general/updating-redshop.md)
