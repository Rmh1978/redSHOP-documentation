# redSHOP Configuration Wizard

The Configuration Wizard guides you through the initial store settings, including general information, terms and conditions, customer registration, prices, VAT and discounts.

![Configuration Wizard welcome screen](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-welcome.png)

## Before you begin

Sign in to the Joomla administrator with permission to manage redSHOP. Make sure the store's contact details, shipping countries, currency, tax policy, and terms-and-conditions article are ready. On an existing shop, review the settings carefully: completing the wizard saves configuration values and can change checkout behaviour.

## Open the wizard

Open redSHOP in the Joomla administrator and select **Configuration Wizard** if available. Alternatively, configure the store from **Configuration**.

## Welcome

The introductory screen explains the setup process. Continue to the general settings when ready.

## General settings

![Wizard general settings](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-general.png)

The general settings include **Shop Country**, **Default Shipping Country**, **Countries you will sell to**, and **Date Format**. It also provides invoice-email settings. Complete the shop's general information, and verify that the countries selected match the markets you actually serve.

The available country choices come from redSHOP's country database. Invoice-email settings include whether invoices are emailed and whether the recipient is the administrator, customer, or both.

## Terms and conditions

![Wizard terms and conditions](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-terms.png)

Use the terms step to configure the store's terms and conditions. Prepare and publish the relevant Joomla article first, then select it in the wizard if the interface provides an article selector. Check the terms link in a test checkout after saving.

## User settings

![Wizard user settings](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-users.png)

The registration methods include:

| Option | Purpose |
| --- | --- |
| Account creation | Customer creates an account during registration. |
| Without account creation | Registration without requiring a customer account. |
| Optional account creation | Customer may choose whether to create an account. |
| Silent account creation | Account creation is handled without a conventional registration prompt. |

Choose the registration method that matches your store and place a test order before opening checkout to customers.

## Price, VAT and discounts

![Wizard price and tax settings](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-price.png)

Choose the shop currency and review number formatting, VAT settings, and available discounts. You can configure discounts, coupons and vouchers, including how they may be combined. Make sure the chosen VAT calculation reflects the store's legal and accounting requirements; the wizard does not replace tax advice.

## Finish and verify

![Wizard finish screen](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-finish.png)

Complete the wizard and save the settings. If an option to add sample data is offered, use it only on a suitable test installation.

After finishing, open the regular redSHOP configuration screen, check the saved settings, and perform a test checkout (including shipping, tax, registration, and order email).
