# redSHOP Configuration — Overview

redSHOP's configuration screen controls store behaviour across the catalogue, customers, checkout, pricing, shipping, integrations, and administration. It is distinct from Joomla's global configuration and from Joomla's component permissions screen.

![redSHOP configuration overview](./manual/en-US/chapters/global-configuration/img/rs506-config-overview.png)

## Open configuration

In the Joomla administrator, open **Components → redSHOP** and navigate to redSHOP's **Configuration** area. The exact navigation location depends on the installed administrator layout.

Configuration is organised into tabs covering the different parts of the store.

## Configuration topics

| Topic | What to configure |
| --- | --- |
| General | Store information, display options, image processing, and selected features. |
| User | Registration and customer-related behaviour. |
| Categories and manufacturers | Catalogue presentation and related settings. |
| Products | Product presentation and behaviour. |
| Feature settings | Additional shop features. |
| Price | Currency, VAT, and discount-related settings. |
| Cart and orders | Basket, checkout, and order behaviour. |
| Newsletter | Newsletter-related settings where enabled. |
| Integration | Integration-specific options; confirm which integrations are installed and supported. |
| SEO | Search-engine-related settings. |
| Dashboard | Administrator dashboard configuration. |

Available integration settings depend on the extensions installed on your website.

## Save changes safely

1. Record the current setting before changing it, especially on an existing store.
2. Change one related group of options at a time.
3. Use **Save** or **Apply**, as available in the administrator interface.
4. Confirm the saved value remains after reopening the screen.
5. Test the affected storefront behaviour. For checkout-related settings, place a test order.

## Component permissions

Joomla's component options contain a permissions fieldset. These permissions govern administrator access and are separate from redSHOP's operational store configuration.

## Related articles

- [General configuration](./manual/en-US/chapters/global-configuration/general.md)
- [User configuration](./manual/en-US/chapters/global-configuration/user.md)
- [Product configuration](./manual/en-US/chapters/global-configuration/products.md)
- [Price configuration](./manual/en-US/chapters/global-configuration/price.md)
- [Cart configuration](./manual/en-US/chapters/global-configuration/cart.md)
- [Order configuration](./manual/en-US/chapters/global-configuration/orders.md)
- [SEO configuration](./manual/en-US/chapters/global-configuration/seo.md)
