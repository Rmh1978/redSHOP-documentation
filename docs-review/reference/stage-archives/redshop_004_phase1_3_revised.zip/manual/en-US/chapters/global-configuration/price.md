# Price configuration

Open **redSHOP → Configuration → Price**. The current page groups settings into **Main Price**, **Gift Card Image Settings**, **VAT/Tax**, **Discount** and **Discount Mail**.

![Price configuration overview](img/rs506-config-price-overview.png)

## Main price settings

![Main price settings](img/rs506-config-price-main.png)

- **Show price:** Controls price visibility in supported storefront views.
- **Currency / currency symbol / symbol position:** Configure the store's display currency and formatting.
- **Decimal separator / thousand separator:** Configure numeric display punctuation.
- **Price decimals / calculation price decimals:** Configure display precision and calculation precision. These are separate settings.
- **Zero-price replacement:** Configure the text or representation for zero-price products where supported.
- **Use tax exempt / show tax exempt in front / tax exempt apply VAT:** Options related to tax-exempt customer pricing.
- **Use as catalog:** Catalog-mode option. Confirm add-to-cart behavior on the active storefront template.

## VAT / tax

![VAT and tax settings](img/rs506-config-price-vat.png)

Configure the **default VAT country**, **state** and **VAT group**, together with **VAT calculation basis** and whether VAT is applied to discounts. Additional controls include VAT rate after discount, address basis for VAT calculation, required VAT number and VAT-related introduction texts.

Tax behavior depends on configured tax groups, customer addresses, shopper groups and applicable law. Validate real orders and invoices with your accountant or tax adviser before enabling the store.

## Discounts and coupons

![Discount settings](img/rs506-config-price-discounts.png)

The configuration exposes **Enable discounts**, **Discount type**, **Enable coupons**, **Coupon information**, **Enable vouchers**, **Special discount mail**, **Apply voucher/coupon to already discounted items**, **Shipping calculation basis**, and discount-coupon value controls.

If you enable discounts, coupons or vouchers, choose an appropriate **Discount type**: the configuration form checks that a discount type has been selected when those features are enabled.

Test combinations with product-specific discounts, tax, shipping and shopper-group prices before using them in production.

## Discount mail

![Discount mail settings](img/rs506-config-price-discount-mail.png)

The **Discount Mail** section exposes an enable setting, three delays after an order, and a coupon validity duration. Confirm that your mail templates and scheduled processing actually send the intended messages before relying on automated campaigns.

## Gift card images

![Gift card image settings](img/rs506-config-price-giftcards.png)

Use **Gift Card Image Settings** to configure image dimensions and watermark options for gift cards.
