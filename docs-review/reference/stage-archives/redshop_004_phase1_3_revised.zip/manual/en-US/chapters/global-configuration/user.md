# User configuration

Configure customer registration and shopper-group defaults in **redSHOP → Configuration → User**. The current configuration view loads two sections: **Registration** and **Shopper Groups**.

![User configuration overview](img/rs506-config-user-overview.png)

## Registration

![Registration settings](img/rs506-config-user-registration.png)

- **Registration method:** Choose how customers register during checkout. The configuration supports account creation, checkout without account creation, optional account creation, and silent account creation. Test your selected flow in the storefront before going live.
- **Create account checkbox:** Controls the account-creation checkbox presented in supported registration flows.
- **Email verification:** Controls the email-verification option. Confirm that Joomla mail delivery and activation work in your environment.
- **New customer selection:** Controls the initial new-customer selection in supported checkout layouts.
- **Terms and conditions:** Select the Joomla article containing your terms; the configuration also exposes a separate option to show terms and conditions.
- **Allowed customer registration type:** Restrict registration to the supported customer types.
- **Default customer registration type:** Select the initially offered type where multiple types are allowed.
- **Welcome-page intro text:** Content displayed in the supported customer welcome view.
- **Registration intro text / company intro text:** Text used in registration interfaces where the selected layout displays it.

The appearance of the registration forms depends on your store templates and checkout settings.

## Shopper groups

![Shopper-group settings](img/rs506-config-user-shopper-groups.png)

- **Portal shop:** Enable portal-shop behavior where required by your store design. Verify actual access restrictions with a non-administrator account.
- **URL after portal login / logout:** Configure navigation targets for portal users.
- **Default portal name / logo:** Set the portal identity where supported by the active template.
- **Default private shopper group / company shopper group:** Assign default groups for newly registered customers.
- **Default unregistered shopper group:** Set the group used for visitors who have not registered.
- **New shopper group inherits from:** Choose a source group for initial settings when creating another group.

## Before publishing the store

1. Test private, company and guest checkout as applicable.
2. Check that new users receive the intended shopper group.
3. Verify terms acceptance and email verification, if enabled.
4. Test portal login/logout and access restrictions with a test account.
