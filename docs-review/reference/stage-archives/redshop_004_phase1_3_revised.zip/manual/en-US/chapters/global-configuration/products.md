# Product configuration

Open **redSHOP → Configuration → Products** to configure global product behavior. These settings are defaults and may be overridden by individual products or templates where supported.

![Product configuration overview](img/rs506-config-products-overview.png)

## General and units

![General product settings](img/rs506-config-products-general.png)

The **General** section includes **Default category** and **Show discontinued products**. Check your category and storefront behavior after changing either option.

![Product unit settings](img/rs506-config-products-units.png)

The **Unit Settings** section includes **Default volume unit**, **Default weight unit**, and **Unit decimals**. Choose units consistently with product dimensions, shipping rates and imported product data.

## Downloadable products

![Product download settings](img/rs506-config-products-download.png)

The **Download** section includes:

- **Product download limit:** Default maximum download count.
- **Product download days:** Default duration of download access.
- **Product download root:** Filesystem location for downloadable-product files.

Choose a storage path carefully. If the deployment supports storage outside the public web root, prefer that for protected downloadable content. Do not change an existing path without checking how stored file references are resolved and migrating files where needed. 

## Additional product configuration sections

The current product configuration template also includes these areas:

| Section | What to configure |
|---|---|
| Wrapping management | Product wrapping options and presentation |
| Catalog management | Catalog-related settings |
| Color sample management | Color sample presentation and settings |
| Product templates and image settings | Default product display and image dimensions |
| Accessory products | Accessory-product behavior and presentation |
| Related products | Related-product behavior and presentation |

![Product templates and images](img/rs506-config-products-templates.png)
![Accessory and related products](img/rs506-config-products-related.png)

More detailed examples of product templates, image options and catalogue features will be added in a future update.
