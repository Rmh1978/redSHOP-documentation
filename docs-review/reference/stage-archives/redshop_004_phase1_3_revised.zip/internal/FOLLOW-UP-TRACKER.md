# redSHOP documentation – follow-up tracker

This is an **internal working list**, not part of the published documentation. Keep it updated as code review, UI testing and screenshots are completed.

**Scope:** redSHOP 5.0.6, documentation phases 1–5. **Status:** Open.  
**Conventions:** `OPEN` = needs work; `IN PROGRESS` = being reviewed; `DONE` = checked and completed.  

| ID | Article | Follow-up | Status |
|---|---|---|---|
| D045-01 | cart.md | Confirm cart timeout unit and actual expiration behavior | OPEN |
| D045-02 | cart.md | Verify minimum order total calculation with VAT, discounts and shipping | OPEN |
| D045-03 | cart.md | Document checkout variants, AJAX cart and payment/shipping interaction with examples | OPEN |
| D045-04 | orders.md | Verify order email timing for successful, failed and delayed payments | OPEN |
| D045-05 | orders.md | Confirm order/invoice numbering and free-order invoice behavior | OPEN |
| D045-06 | feature-settings.md | Verify where inline editing works in administrator UI | OPEN |
| D045-07 | feature-settings.md | Test review submission and wishlist behavior for guests and registered customers | OPEN |
| D045-08 | feature-settings.md | Verify stock deduction, reservation and notification scenarios | OPEN |
| D045-09 | seo.md | Verify placeholder syntax and available tokens in each metadata field | OPEN |
| D045-10 | seo.md | Test Joomla SEF, category paths, multilingual routes and redirects | OPEN |
| D045-11 | integration.md | Separate supported integrations from legacy UI sections; verify provider API compatibility | OPEN |
| D045-12 | integration.md | Write dedicated setup guides for Billy, Flatpay, Bambora, PostNord and Relatel where applicable | OPEN |
| D045-13 | dashboard.md | Confirm current menu visibility list and behavior under restricted Joomla ACL | OPEN |
| D045-14 | all six | Capture screenshots from redSHOP 5.0.6 test site; replace image placeholders | OPEN |
| D045-15 | all six | Verify menu labels and frontend behavior on Joomla 5.4 | OPEN |
| D045-16 | all six | Joomla 6 compatibility testing before claiming support | OPEN |

## Phases 1–3

| ID | Article | Follow-up | Status |
|---|---|---|---|
| D013-01 | requirements | Confirm supported Joomla/PHP/database matrix and Joomla 6 upgrade test | OPEN |
| D013-02 | installation | Verify clean installation, bundled extensions and installer result screens | OPEN |
| D013-03 | updating | Verify update server, download-key UI, manual ZIP update and migration from legacy releases | OPEN |
| D013-04 | wizard | Confirm wizard entry point, step navigation, field labels and save behavior | OPEN |
| D013-05 | wizard | Test all registration methods, terms and invoice-email settings | OPEN |
| D013-06 | general | Verify all configuration tabs, general settings, upload-size units and image resizing | OPEN |
| D013-07 | general | Test statistics, product reservation and shipping-address settings | OPEN |
| D013-08 | user | Test registration methods, verification emails, portal restrictions and shopper group assignments | OPEN |
| D013-09 | products | Verify download storage access, limits, product templates and catalogue features | OPEN |
| D013-10 | price | Verify VAT calculations, tax-exempt pricing, coupon stacking and discount emails | OPEN |
| D013-11 | all phases 1–3 | Capture and review screenshots; verify labels on Joomla 5.4 | OPEN |
| D013-12 | all phases 1–3 | Check rendered documentation links and image paths in site generator | OPEN |

## How to maintain

Update the status and add a short note/date as items are addressed. When a feature is verified, expand the public article and replace any “will be added in a future update” text with the final instructions. Do not publish this tracker under the manual chapters directory.
