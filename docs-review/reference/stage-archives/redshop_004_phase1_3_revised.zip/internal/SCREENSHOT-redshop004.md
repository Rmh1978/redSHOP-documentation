# Screenshot checklist — redSHOP 5.0.6 — Phase 1

Save images in the **documentation repository** at:

`manual/en-US/chapters/getting-started-general/img/`

The Markdown references below follow the existing manual's root-relative image convention (`./manual/en-US/chapters/...`). If the documentation renderer resolves links differently, adjust paths before publishing.

| Filename | Joomla location / navigation | What to capture | Used by |
|---|---|---|---|
| `rs506-system-information.png` | **System → System Information** | PHP, database and Joomla versions; redact host details | Minimum requirements |
| `rs506-install-upload.png` | **System → Install → Extensions** | Upload Package File interface, before upload | Installing |
| `rs506-install-result.png` | **System → Install → Extensions**, immediately after a **successful test installation** | Joomla success result (do not repeat installation on production for a screenshot) | Installing |
| `rs506-install-redshop-dashboard.png` | **Components → redSHOP**, initial screen | Actual redSHOP landing screen and navigation | Installing |
| `rs506-install-extensions.png` | **System → Manage → Extensions**, search `redshop` | Installed component/modules/plugins | Installing |
| `rs506-update-available.png` | **System → Update → Extensions** | redSHOP update entry **only if an update is genuinely available** | Updating |
| `rs506-update-download-key.png` | Joomla redSHOP update-site/download-key settings, **only if shown** | Download-key field with value hidden | Updating |
| `rs506-update-package.png` | **System → Install → Extensions** | Upload area for manual update ZIP; can reuse install screenshot if identical | Updating |
| `rs506-update-version.png` | **System → Manage → Extensions**, filter `redshop` | redSHOP version after a test update | Updating |

## Capture instructions

- Use `print.dk/tests/redshop6` rather than the live shop when feasible.
- Capture at 1440–1600 px browser width and 100% zoom; crop irrelevant desktop/browser chrome.
- Use PNG; keep full field labels and relevant Joomla menu context visible.
- Remove customer information, emails, addresses, tokens, license keys, and order data.
- Do not manufacture a successful install/update or an available update just to take a screenshot. Mark unavailable images as pending.
- Confirm the actual menu names in the Joomla instance; the navigation above uses standard Joomla 5 labels.

## Screenshot verification

After screenshots are supplied, compare every image with its related article and revise labels, field names and UI steps to match the tested redSHOP version.
