# redSHOP documentation — revised phases 1–3

Replace the nine corresponding Markdown articles in `manual/en-US/chapters/getting-started-general/` and `manual/en-US/chapters/global-configuration/`. Keep `FOLLOW-UP-TRACKER.md` private, outside the public manual. Screenshot checklists are internal working files. This archive does not include or overwrite phases 4–5.

Public pages no longer contain source-review status, screenshot-pending markers or developer-facing follow-up notes. Where full guidance is unavailable, pages use short future-update wording.
