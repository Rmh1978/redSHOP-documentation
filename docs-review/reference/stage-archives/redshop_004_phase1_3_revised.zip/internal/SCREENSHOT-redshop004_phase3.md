# Screenshot checklist — Etape 004, del 3

**Joomla testsite:** `print.dk/tests/redshop6/administrator/`
**Gem alle billeder i:** `redSHOP-documentation/manual/en-US/chapters/global-configuration/img/`

Use PNG, capture the actual admin UI, avoid personal/customer data, API keys and real server paths.

| Filename | Where to capture |
|---|---|
| `rs506-config-user-overview.png` | redSHOP → Configuration → User → User tab, entire page |
| `rs506-config-user-registration.png` | redSHOP → Configuration → User → Registration section |
| `rs506-config-user-shopper-groups.png` | redSHOP → Configuration → User → Shopper Groups section |
| `rs506-config-products-overview.png` | redSHOP → Configuration → Products → Products tab, entire page |
| `rs506-config-products-general.png` | redSHOP → Configuration → Products → General section |
| `rs506-config-products-units.png` | redSHOP → Configuration → Products → Unit Settings section |
| `rs506-config-products-download.png` | redSHOP → Configuration → Products → Download section; hide sensitive server paths |
| `rs506-config-products-templates.png` | redSHOP → Configuration → Products → Product templates and image settings |
| `rs506-config-products-related.png` | redSHOP → Configuration → Products → Accessory/related products |
| `rs506-config-price-overview.png` | redSHOP → Configuration → Price → Price tab, entire page |
| `rs506-config-price-main.png` | redSHOP → Configuration → Price → Main Price section |
| `rs506-config-price-vat.png` | redSHOP → Configuration → Price → VAT/Tax section |
| `rs506-config-price-discounts.png` | redSHOP → Configuration → Price → Discount section |
| `rs506-config-price-discount-mail.png` | redSHOP → Configuration → Price → Discount Mail section |
| `rs506-config-price-giftcards.png` | redSHOP → Configuration → Price → Gift Card Image Settings |

Keep screenshots at a consistent browser width (e.g. 1440 px). Do not crop away field labels. If a setting is not present in the actual UI, do not fabricate it; report the discrepancy so the documentation can be corrected.
