# redSHOP 5.0.6 — Screenshot checklist, phase 2

Take real screenshots from a Joomla 5.4 test installation with redSHOP 5.0.6. Do not capture customer details, API tokens, personal addresses, or live credentials. Keep the interface language English and use the same browser width for every screenshot.

## Configuration Wizard

Save under `manual/en-US/chapters/getting-started-general/img/`:

| Filename | Screen / area | Notes |
| --- | --- | --- |
| `rs506-wizard-welcome.png` | redSHOP → Configuration Wizard → Welcome | Only if wizard is accessible. |
| `rs506-wizard-general.png` | Wizard → General | Show store and country fields; hide private email addresses. |
| `rs506-wizard-terms.png` | Wizard → Terms and Conditions | Show Joomla article selection. |
| `rs506-wizard-users.png` | Wizard → User | Include registration method options. |
| `rs506-wizard-price.png` | Wizard → Price / VAT / Discounts | Capture overview; add cropped variants later if needed. |
| `rs506-wizard-finish.png` | Wizard → Finish | Prefer a test installation. |

## Global Configuration

Save under `manual/en-US/chapters/global-configuration/img/`:

| Filename | Screen / area | Notes |
| --- | --- | --- |
| `rs506-config-overview.png` | redSHOP → Configuration | Show tabs and the full configuration context. |
| `rs506-config-general.png` | Configuration → General | Overall General tab. |
| `rs506-config-store-settings.png` | General → Store Settings | Crop to field group. |
| `rs506-config-general-layout.png` | General → General Layout Settings | Include media and image fields. |
| `rs506-config-modules-features.png` | General → Modules & Features | Include reservation controls. |

## If the screen is missing

Do not create a simulated screenshot. Note the missing view and the exact Joomla/redSHOP versions, then send the observation back for a documentation correction. Screenshot paths in Markdown are placeholders until you add the actual PNG files.
