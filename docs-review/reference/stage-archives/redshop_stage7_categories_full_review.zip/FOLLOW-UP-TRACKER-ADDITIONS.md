# Internal follow-up — Stage 7

Status: Source-reviewed draft; UI and end-to-end testing pending.

| ID | Status | Action |
| --- | --- | --- |
| DOC-7-01 | OPEN | Compare all category listing columns, toolbar actions and check-in behaviour with redSHOP 5.0.6. |
| DOC-7-02 | OPEN | Verify parent/unpublished-child behaviour and category deletion/copy handling. |
| DOC-7-03 | OPEN | Test category editor fields, per-category template overrides and allowed-template selector tag. |
| DOC-7-04 | OPEN | Inspect actual category SEO XML fieldset and generated frontend metadata. |
| DOC-7-05 | OPEN | Test new Product Filters tab, supported fields, frontend template integration and attribute selection. |
| DOC-7-06 | OPEN | Confirm whether historical Custom Fields and Accessories tabs remain, have moved or were removed. Do not describe them as confirmed current UI. |
| DOC-7-07 | OPEN | Confirm category-level accessory pricing precedence against product-specific accessory rules. |
| DOC-7-08 | OPEN | Test shopper-group category visibility and administrative access controls. |
| DOC-7-09 | OPEN | Verify mass discounts, product-price discounts and shopper-group precedence on test orders. |
| DOC-7-10 | OPEN | Test category wrapping and shipping-rate restrictions, including mixed-category carts. |
| DOC-7-11 | OPEN | Verify current CSV/XML import/export workflow, formats and category parent mapping. |
| DOC-7-12 | OPEN | Confirm available Joomla category menu item types and labels. |
| DOC-7-13 | OPEN | Verify historic category template tags and frontpage/product-category layouts. |
| DOC-7-14 | OPEN | Verify media manager category assignments and image cache behaviour. |
| DOC-7-15 | OPEN | Verify current text-library integration and custom-field output. |
| DOC-7-16 | OPEN | Capture 16 current screenshots and check docs relative paths. |
| DOC-7-17 | OPEN | Review original tutorial video links for accessibility and version relevance before considering reuse. |
