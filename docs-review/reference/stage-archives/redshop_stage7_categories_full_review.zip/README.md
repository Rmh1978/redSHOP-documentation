# Stage 7 — Categories

Two English Markdown articles:
- `manual/en-US/chapters/categories/overview-category.md`
- `manual/en-US/chapters/categories/redshop-categories.md`

The main article was rebuilt from the 40,378-character original, preserving its major subject areas: list, editor, images, SEO, custom fields, accessories, creation, products, discounts, access, wrapping, shipping, import/export, templates and storefront menus. It also adds the current Product Filters editor section.

Verified directly in the `develop` source templates:
- `component/admin/tmpl/category/edit.php`
- `component/admin/tmpl/category/edit_information.php`
- `component/admin/tmpl/category/edit_seo.php`
- `component/admin/tmpl/category/edit_product_filter.php`

Other workflows remain sourced from the historical documentation and require test-site verification. This is a comprehensive draft, not a claim that all historical functionality has been tested. No screenshots are bundled and no GitHub commits were made.
