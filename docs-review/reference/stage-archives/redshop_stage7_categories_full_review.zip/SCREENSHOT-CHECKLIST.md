# Screenshot checklist — Stage 7 Categories

Save screenshots under `manual/en-US/chapters/categories/img/`. The Markdown already refers to these filenames.

- [ ] `rs506-category-list.png` — Category list, with columns and hierarchy.
- [ ] `rs506-category-toolbar.png` — List toolbar and available actions.
- [ ] `rs506-category-editor.png` — Full category editor.
- [ ] `rs506-category-information.png` — Category Information fields.
- [ ] `rs506-category-images.png` — Main image and back image controls.
- [ ] `rs506-category-seo.png` — SEO fields.
- [ ] `rs506-category-product-filters.png` — Product Filters fields and notice.
- [ ] `rs506-category-product-assignment.png` — Category selector on a product.
- [ ] `rs506-category-mass-discount.png` — Category selection in a mass discount.
- [ ] `rs506-category-wrapping.png` — Wrapping configuration with categories.
- [ ] `rs506-category-shipping-rate.png` — Shipping rate and category restrictions.
- [ ] `rs506-category-export.png` — Category export configuration.
- [ ] `rs506-category-import.png` — Category import configuration.
- [ ] `rs506-category-layouts.png` — Frontend list/grid comparison.
- [ ] `rs506-category-menu-item.png` — Joomla category-detail menu item.
- [ ] `rs506-category-frontpage.png` — Frontpage category display.

Use test data, remove customer information, and capture actual current UI rather than the 2019 screenshots.
