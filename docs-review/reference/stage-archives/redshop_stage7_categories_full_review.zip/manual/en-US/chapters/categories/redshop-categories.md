# Working with redSHOP Categories

Categories are the foundation of a redSHOP product catalogue. They group related products, allow you to build a hierarchy of parent categories and subcategories, and help customers find the products they need. A category can have its own presentation, images, search-engine metadata and, depending on the shop's configuration, restrictions and promotions.

This guide explains category administration, the category editor and the other shop features that can use categories.

## Open Category Management

1. Sign in to the Joomla administrator.
2. Open **Components → redSHOP**.
3. Choose **Categories** from the redSHOP administration navigation.
4. The category listing displays the existing categories and their status.

![Category management list](img/rs506-category-list.png)

If you have just installed redSHOP, the list may be empty. Create the main categories before assigning products.

## Understand the category listing

The category list provides a quick view of your catalogue structure.

| Column | Description |
| --- | --- |
| **Category** | Category name. Subcategories may be indented beneath their parent to show the hierarchy. |
| **Category Description** | A short description associated with the category, where included in the list layout. |
| **Products** | Number of products associated with the category. |
| **Order** | Administrator-defined ordering value used by layouts that support manual ordering. |
| **Published** | Indicates whether the category is published. |

The exact visible columns can vary with the installed version and administration layout.

### Category list actions

![Category list toolbar](img/rs506-category-toolbar.png)

- **New** creates a category.
- **Copy** duplicates the selected category records, where available.
- **Delete** removes selected categories. Review product assignments and subcategories before deleting.
- **Publish** makes selected categories available to published storefront views.
- **Unpublish** hides selected categories from normal published storefront views.
- **Check-in** releases a record that remains locked for editing.

Unpublishing a parent category can also make its child categories inaccessible through the normal storefront hierarchy. Check nested categories when changing parent publication status.

### Organize parent and child categories

A category can belong to another category. For example:

- Clothing
  - T-shirts
  - Jackets
- Accessories
  - Bags
  - Hats

Keep category names clear and avoid unnecessary nesting. Customers should be able to reach products without navigating an excessive number of levels.

## Create a category

![Category editor](img/rs506-category-editor.png)

1. In Category Management, select **New**.
2. Enter a descriptive **Category** name.
3. Select a **Category parent**. Choose the top-level option for a main category, or select an existing parent to create a subcategory.
4. Set **Published** according to whether the category should be visible.
5. Choose the number of products per page and any category template settings you need.
6. Add a short description and a full description.
7. Add a category image and, optionally, a back image.
8. Review the category's SEO settings.
9. Save the category, then check that it appears in the correct position in the category list.

For a new shop, create the main categories first, then create subcategories under them. Assign products after the structure is in place.

### Saving and leaving the editor

The category editor can provide the following toolbar actions:

- **Save:** save the record and continue editing.
- **Save & Close:** save and return to the listing.
- **Save & New:** save and begin another category.
- **Cancel:** leave without saving the current unsaved changes.

Always confirm the category was saved before navigating away.

## Category Information

The current category editor displays the main information fields together with category images and record information.

![Category information fields](img/rs506-category-information.png)

### Category

The name shown to administrators and, in most layouts, to customers. Use a short, recognizable name such as *Business Cards* rather than an internal identifier.

### Category parent

Determines the category's place in the hierarchy. Select the top-level option for a main category or another category for a subcategory.

When moving a category to a different parent, check menu links, breadcrumbs, category URLs and the visibility of its descendants.

### Published

Controls whether the category is published. A published category may still be inaccessible if a parent is unpublished, access rules restrict it or the storefront has no link to it.

### No. of products per page

Controls how many products are displayed per page in supported category layouts. For example, a value of `12` can produce pagination when a category contains more than 12 products.

A menu item or template may provide its own pagination setting. Test the actual category page after saving.

### Template

Select the template used to render the category. The available choices depend on the templates configured in redSHOP.

This setting may override the shop's default category template. Check the page after changing it because templates can differ in their support for images, descriptions, sorting and product display.

### Allowed templates

Allows additional category templates to be selected for use with a template-switching feature. The historical redSHOP template tag `{template_selector_category}` is intended to render a customer-facing template selector when the active category template supports it.

Choose the layouts that make sense for the products in the category, and verify the selector on the storefront.

### Product Comparison Template

Selects a comparison template associated with products in this category. It is relevant when product comparison is enabled and the active storefront design provides comparison controls.

A comparison template can be tailored to the attributes of a particular product group, such as comparing dimensions for print products or technical specifications for electronics.

### Short Description

Enter a concise introduction to the category. A short description is useful in category cards, category listings and other layouts with limited space.

### Description

Enter the main category description. It can explain what the category contains, product options and important buying information.

The editor may support formatted text, links and other content depending on the configured Joomla editor. Keep important information readable and accessible.

## Category images

![Category images](img/rs506-category-images.png)

### Category Image

The main image represents the category in supported layouts. The current editor includes a media control for the category's full image.

The historical template tags `{category_main_thumb_image}` and `{category_thumb_image}` are used in redSHOP category templates to display category image variants.

Choose an image with an appropriate aspect ratio and sufficient resolution for the storefront. After saving, verify both thumbnail and larger image displays.

### Back Image

An optional secondary image. The current editor provides a separate back-image media control.

Whether and where the back image appears depends on the category template. If the template does not render it, assigning the image will not automatically display it.

### Image sizes and defaults

Global category image settings can control thumbnails, watermarking and fallback images. See [Categories in Global Configuration](../global-configuration/categories.md).

## Category SEO settings

![Category SEO fields](img/rs506-category-seo.png)

The current category editor includes a dedicated SEO fieldset. Individual category values can be used to provide metadata specific to that category.

The original redSHOP category editor documents these settings:

| Setting | Purpose |
| --- | --- |
| **SEO Page Title** | Page title intended for the browser and search results. |
| **SEO Page Heading** | Main heading for the category page, where supported by the template. |
| **SEF URL** | Search-engine-friendly URL value for the category. |
| **SEO Keywords** | Optional metadata keywords. Major search engines generally do not use meta keywords as a ranking signal. |
| **SEO Page Description** | Description intended for the page's metadata and potentially search snippets. |
| **Meta Language Setting** | Language metadata setting, where supported. |
| **SEO Robot Info** | Robots instructions for the category page, where supported. |

For example, a category named *Business Cards* might use a descriptive page title such as *Business Cards – Custom Printing* and a concise description that explains the available options.

Do not assume that entering a value guarantees its appearance in search results. Search engines can generate their own titles and snippets, and routing or template behaviour can affect the final HTML.

After saving, open the category page and inspect its visible heading, URL and page metadata.

## Category Product Filters

![Category product filters](img/rs506-category-product-filters.png)

The current category editor includes a **Product Filters** section. It is designed to configure filtering options associated with products in the category.

The filter controls are rendered from the category form's filter fields, and available product attributes can be based on the products currently assigned to the category.

To configure filters:

1. Create or open the category.
2. Assign the products that should belong to it.
3. Open **Product Filters** in the category editor.
4. Review the available controls and select the filters appropriate for those products.
5. Save the category.
6. Open the category on the storefront and verify the filter controls and resulting product list.

The active category template must support the intended filter presentation. Test combinations of filters and categories containing products without the relevant attributes.

## Custom Fields

The historical redSHOP category editor includes a **Custom Fields** section for category-specific fields. Custom fields can be used to store additional category information that is not covered by the standard category name and descriptions.

To use category custom fields, create fields for the appropriate category context, populate their values and ensure the active category template renders them.

See [Custom Fields](../customization/custom.md). The exact editor location and template tags depend on the configured field type and redSHOP version.

## Category Accessories

The original redSHOP documentation describes category-level accessories that can apply to products belonging to a category.

When available, accessory assignment includes:

| Field | Description |
| --- | --- |
| **Product Source** | Search for the product to use as an accessory. |
| **Product Name** | Selected accessory product. |
| **Normal Price** | The product's standard price. |
| **Sign (+/-)** | Whether the adjustment adds to or subtracts from the price. |
| **Amount added** | Value of the accessory price adjustment. |
| **Default Order** | Display order of accessories. |
| **Delete** | Remove the accessory assignment. |

Historically, a product-specific accessory rule could take precedence over a category-level rule when the same accessory was assigned in both places.

If your shop uses accessories, check their availability and pricing on the product page before relying on category-level assignments.

## Assign products to categories

A category can contain multiple products, and a product can be associated with more than one category.

1. Open **Products** in the redSHOP administrator.
2. Create a new product or edit an existing one.
3. Enter the required product details, including its name, product number and price.
4. Find the product's category selection.
5. Select the relevant category or categories.
6. Save the product.
7. Open the category page on the storefront and confirm that the product appears.

![Product category assignment](img/rs506-category-product-assignment.png)

Assign products to multiple categories when this improves discoverability, but check how category-based discounts, shipping conditions and shopper-group access interact.

## Category-based discounts

Categories can be used as a scope for promotional pricing. Different discount features have different eligibility and priority rules.

### Mass discounts

The original redSHOP workflow allows mass discounts to target one or more categories.

1. Open the mass-discount management area.
2. Create a discount and enter its name, type, amount and validity period.
3. Select the categories to which the discount should apply.
4. Save the discount.
5. Test a product in an eligible category and one outside the selected categories.

![Category mass discount](img/rs506-category-mass-discount.png)

For example, a category-wide discount may reduce a product priced at 100 to 80 when a 20% discount applies. The actual final price depends on discount type, eligibility, tax and other active pricing rules.

### Product price discounts and shopper groups

Product price discounts may be restricted by category and shopper group.

1. Create or choose the shopper group.
2. Configure a product price discount with the intended category and shopper group.
3. Sign in on the storefront with a test customer belonging to that shopper group.
4. Confirm the eligible price.
5. Repeat with a customer who should not qualify.

Do not assume a discount applies to every visitor simply because the product is in the selected category.

See [Discounts](../discounts/overview-discounts.md) for other discount types and precedence.

## Category access and shopper groups

The original documentation describes category restrictions through shopper groups, and administrative restrictions through redSHOP's backend access management.

Customer-facing category access can depend on the shopper groups assigned to a customer. This can be useful for business-only catalogues or products intended for particular customer groups.

When using restrictions:

1. Define the shopper group and its category access.
2. Assign a test customer to that group.
3. Check the category while signed in as that customer.
4. Check the same page while signed out or using a different group.
5. Verify direct links to products as well as navigation links.

For administrator permissions, use the access controls supported by your Joomla and redSHOP installation. Do not rely on hiding a menu item as a security restriction.

## Category-based wrapping

The original redSHOP workflow allows wrapping options to be assigned to selected categories.

1. Open **Shipping → Wrappings** in redSHOP.
2. Create a wrapping option.
3. Enter its name and price.
4. Select the categories where it should be offered, or the option for all products if appropriate.
5. Save.
6. Add an eligible product to the cart and verify the wrapping choice and price.

![Category wrapping](img/rs506-category-wrapping.png)

See [Wrappings](../shipping/wrappings.md) for additional details.

## Category-based shipping rates

Some shipping methods can use category restrictions when determining which rates are eligible.

The original standard-shipping workflow is:

1. Open **Shipping → Shipping Methods**.
2. Open the relevant shipping method.
3. Open its shipping-rate management area.
4. Create or edit a rate.
5. Enter the rate name, amount and eligible categories.
6. Save the rate.
7. Add an eligible product to the cart.
8. Continue through checkout with a test shipping address.
9. Verify the shipping method, rate and any tax on the checkout and order summary.

![Category shipping rate](img/rs506-category-shipping-rate.png)

Shipping plugins can implement their own eligibility rules. Test carts containing products from several categories, as well as carts with only eligible products.

See [Shipping Methods](../shipping/shipping-methods.md).

## Import and export category data

redSHOP includes import/export functionality that can be useful for creating or maintaining larger category structures.

### Export categories

1. Open redSHOP's **Import / Export** area.
2. Choose the export function.
3. Select the category data type, if offered.
4. Select the desired format and start the export.
5. Inspect the downloaded file before editing or using it as an import template.

![Category export](img/rs506-category-export.png)

The historical documentation describes CSV and XML export options. The available formats and controls should be checked in the installed version.

### Import categories

1. Export existing category data first to obtain an example of the required structure.
2. Back up the database.
3. Prepare a small import file using the supported field names and format.
4. Open the import function and select category data.
5. Upload and process the file.
6. Check the reported result and inspect the imported categories.
7. Only then proceed with a larger import.

![Category import](img/rs506-category-import.png)

Pay particular attention to category identifiers, parent relationships, published state and character encoding. A malformed hierarchy can be difficult to correct after a large import.

The older documentation also mentions migration from VirtueMart. Treat migration as a separate project and verify the availability and compatibility of the migration tool before using it.

## Templates, tags and media

Category pages can be presented in different layouts, including product lists, grids, subcategory groupings and a top-level category overview.

### Category templates

The **Category** template displays the products and subcategories belonging to a particular category. Depending on the installed templates, it may offer list or grid presentation.

![Category grid and list](img/rs506-category-layouts.png)

### Product category templates

A product-category layout can group products according to their subcategories. Use it when customers benefit from seeing products organized under subcategory headings.

### Frontpage category templates

A frontpage category layout presents the top-level category structure, allowing customers to choose which area of the catalogue to browse.

### Template tags

redSHOP templates can use tags to render category content. The historical documentation includes:

- `{category_main_thumb_image}` — category image variant.
- `{category_thumb_image}` — category thumbnail variant.
- `{template_selector_category}` — selection between allowed category templates.

When editing a template, confirm that the tags are supported by that template type and test the result on the storefront.

### Media management

Category images can also be managed through redSHOP's media-management tools. The original workflow allows filtering media by section and associating media with a specific category.

Check the media type and selected category before saving, and verify that the correct image appears on the category page.

### Custom fields and text-library content

Custom fields and reusable text-library items can provide additional category content. Their output depends on the corresponding template tags being present in the active category template.

## Show categories on the storefront

Creating a category does not necessarily add a navigation link to it. Joomla menu items can be used to expose category views.

### Category Detailed menu item

![Category menu item](img/rs506-category-menu-item.png)

1. Open **Menus** in the Joomla administrator.
2. Select the menu where the link should appear.
3. Create a new menu item.
4. Enter a menu title.
5. Choose the redSHOP category-detail menu item type.
6. Select the category.
7. Save and publish the menu item.
8. Open the frontend menu and check the resulting category page.

The exact menu item type label may vary between installations.

### Frontpage Category menu item

1. Create a new Joomla menu item.
2. Enter a title such as *Shop* or *All Categories*.
3. Choose the redSHOP frontpage-category menu item type.
4. Save and publish the menu item.
5. Check that the page displays the expected top-level categories.

![Frontpage category](img/rs506-category-frontpage.png)

Some category modules can also display category navigation. Module output depends on its configuration, menu assignment and template position.

## Troubleshooting

### A category does not appear

Check its **Published** status, its parent category, any shopper-group restrictions, the menu link and the active template.

### A product is missing from a category

Confirm the product is published and assigned to the category. Check product availability, shopper-group rules and any active category filters.

### A category uses an unexpected template

Check the category's own template selection, the global default and the Joomla menu item's settings.

### Images do not appear or look incorrect

Confirm that the correct category image is selected, inspect the image dimensions and check whether the active template renders the relevant image tag.

### A category discount is not applied

Check the discount period, selected categories, shopper-group eligibility, discount precedence and whether the product qualifies.

### Shipping rates differ from expectations

Test the configured shipping method with a known address and cart. Shipping rates may depend on multiple conditions beyond the category.

## Related documentation

- [Category overview](overview-category.md)
- [Global category configuration](../global-configuration/categories.md)
- [Products](../product-management/products-redshop.md)
- [Discounts](../discounts/overview-discounts.md)
- [Shipping methods](../shipping/shipping-methods.md)
- [Import and Export](../import-export/overview-import-export.md)
