# Category Management

Categories organize products into a catalogue that customers can browse. A category can contain products and nested subcategories, and can have its own description, images, storefront template and search-engine metadata.

## Category documentation

- [Working with redSHOP Categories](redshop-categories.md) — Create and organize categories, configure their details, assign products, and display them on the storefront.

## A typical workflow

1. Plan the main category structure and any subcategories.
2. Create and publish the categories in redSHOP.
3. Add category descriptions and images.
4. Assign products to the relevant categories.
5. Configure the category's layout, SEO information and optional filters.
6. Create Joomla menu items so customers can browse the categories.
7. Check the storefront on desktop and mobile, including product ordering and pagination.

For settings that apply across the shop, see [Categories in Global Configuration](../global-configuration/categories.md). Individual category settings can override some global defaults.

## Related topics

- [Products](../product-management/products-redshop.md)
- [Discounts](../discounts/overview-discounts.md)
- [Shipping](../shipping/overview-shipping.md)
- [Import and Export](../import-export/overview-import-export.md)
- [Custom Fields](../customization/custom.md)
