# Frequently Asked Questions

These FAQs contain legacy instructions and must be verified before use:

- [AJAX add-to-cart customization](how-do-1.md) — old template paths unverified
- [Removing VAT references](how-do-2.md) — avoid destructive tax configuration changes
- [Cash on Delivery](payment.md) — legacy payment workaround
- [PayPal certificate changes](paypal.md) — historical notice

**Editorial status:** Review supplements, not approved production instructions.
