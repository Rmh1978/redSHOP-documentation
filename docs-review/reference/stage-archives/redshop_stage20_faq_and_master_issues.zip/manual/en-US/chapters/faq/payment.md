# Cash on Delivery (COD)

> **Modernization review — not a verified production procedure.** This supplement documents why the original FAQ requires revision. Preserve the original article until the complete migration is reviewed.

## What the historical FAQ says

The historical answer (dated January 4, 2016) proposes relabeling the Credit Card in Shop offline payment plugin as COD.

## Current recommendation

Treat this as a legacy workaround, not a verified supported COD integration. Audit installed payment plugins and confirm that the chosen method does not solicit, store or mislabel card data. Test order status, payment status, invoicing and shipping.

## Verification checklist

- [ ] Identify exact current code paths and feature ownership
- [ ] Confirm behaviour in Joomla 5 and Joomla 6
- [ ] Test on the independent redshop6 site without notifying customers
- [ ] Update screenshots, navigation and links
- [ ] Preserve any still-correct examples from the original article

## Sources

- Original: `manual/en-US/chapters/faq/payment.md` (`gh-pages`)
- Code tree: `Rmh1978/redSHOP-rmh` (`develop`)
