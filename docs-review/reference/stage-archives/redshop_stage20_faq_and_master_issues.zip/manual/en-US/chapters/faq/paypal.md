# PayPal SSL certificate change

> **Modernization review — not a verified production procedure.** This supplement documents why the original FAQ requires revision. Preserve the original article until the complete migration is reviewed.

## What the historical FAQ says

The original FAQ describes a historical PayPal certificate transition and PayPal Pro hosting requirements. The current code tree contains `plugins/redshop_payment/rs_payment_paypal/rs_payment_paypal.php`.

## Current recommendation

Archive the certificate-transition explanation as historical. Audit the current PayPal plugin implementation, credentials, API endpoints, signature verification, webhook/IPN handling, refunds and sandbox compatibility before publishing contemporary setup instructions.

## Verification checklist

- [ ] Identify exact current code paths and feature ownership
- [ ] Confirm behaviour in Joomla 5 and Joomla 6
- [ ] Test on the independent redshop6 site without notifying customers
- [ ] Update screenshots, navigation and links
- [ ] Preserve any still-correct examples from the original article

## Sources

- Original: `manual/en-US/chapters/faq/paypal.md` (`gh-pages`)
- Code tree: `Rmh1978/redSHOP-rmh` (`develop`)
