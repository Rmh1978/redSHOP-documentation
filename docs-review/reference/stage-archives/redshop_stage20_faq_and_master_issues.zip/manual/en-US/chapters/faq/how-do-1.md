# AJAX add-to-cart box customization

> **Modernization review — not a verified production procedure.** This supplement documents why the original FAQ requires revision. Preserve the original article until the complete migration is reviewed.

## What the historical FAQ says

The historical guide names `components/com_redshop/templates/rsdefaulttemplates/ajax_cart_box.php` and `ajax_cart_detail_box.php`. Neither exact basename was found in the current `develop` repository tree.

## Current recommendation

Do not copy or edit the legacy PHP template paths without first identifying the currently rendered cart implementation. Use Joomla template overrides and asset management where supported; test cart events, accessibility and responsive layouts.

## Verification checklist

- [ ] Identify exact current code paths and feature ownership
- [ ] Confirm behaviour in Joomla 5 and Joomla 6
- [ ] Test on the independent redshop6 site without notifying customers
- [ ] Update screenshots, navigation and links
- [ ] Preserve any still-correct examples from the original article

## Sources

- Original: `manual/en-US/chapters/faq/how-do-1.md` (`gh-pages`)
- Code tree: `Rmh1978/redSHOP-rmh` (`develop`)
