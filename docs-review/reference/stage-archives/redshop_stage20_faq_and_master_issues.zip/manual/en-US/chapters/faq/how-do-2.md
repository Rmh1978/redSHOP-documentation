# VAT removal for non-VAT countries

> **Modernization review — not a verified production procedure.** This supplement documents why the original FAQ requires revision. Preserve the original article until the complete migration is reviewed.

## What the historical FAQ says

The historical guide advises changing tax-exemption settings, deleting all tax rates in the Default group and removing VAT placeholders from cart templates.

## Current recommendation

Do not delete production tax rates as a first step. Verify applicable legal requirements, the current global configuration, tax-group selection, shopper groups, customer address rules and cart display independently on the test site.

## Verification checklist

- [ ] Identify exact current code paths and feature ownership
- [ ] Confirm behaviour in Joomla 5 and Joomla 6
- [ ] Test on the independent redshop6 site without notifying customers
- [ ] Update screenshots, navigation and links
- [ ] Preserve any still-correct examples from the original article

## Sources

- Original: `manual/en-US/chapters/faq/how-do-2.md` (`gh-pages`)
- Code tree: `Rmh1978/redSHOP-rmh` (`develop`)
