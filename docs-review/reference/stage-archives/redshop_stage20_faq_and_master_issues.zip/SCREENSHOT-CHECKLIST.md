# FAQ verification

- [ ] Current AJAX cart modal and template override
- [ ] Current tax settings and tax-free test checkout
- [ ] Current offline/COD payment setup and order result
- [ ] PayPal plugin configuration and sandbox checkout
- [ ] FAQ navigation links and mobile screenshots
