# Media screenshots

- [ ] Media list, filters and toolbar
- [ ] Media edit and upload form
- [ ] Product association and frontend result
- [ ] Category and manufacturer associations
- [ ] Invalid upload and thumbnail output
