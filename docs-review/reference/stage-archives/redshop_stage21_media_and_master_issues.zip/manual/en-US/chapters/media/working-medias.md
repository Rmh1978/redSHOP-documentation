# Working With Media in redSHOP — review notes

> **Not publication-ready.** The original 15,458-character guide must be preserved in full during final editing. These notes identify source-verified areas and tests to add, not a complete rewrite.

## Historical guide sections

- Media listing, including media name/thumbnail, type, alternative text, section, published state and ID
- Media details, including image, media type, alternative text, section and section item
- Administrator actions: New, Edit, Delete, Publish, Unpublish, Save, Save & Close, Save & New, Cancel and Close
- Creating media items
- Associating media with products, categories and manufacturers
- Uploading media for products and checking its storefront use

## Verified source structure

The `develop` branch contains:

- `component/admin/tmpl/media/default.php` — administrator media screen, including `media_section`, `media_type`, `media_name`, `media_alternate_text` and `media_id` references
- `component/admin/src/Model/MediaModel.php` — media model with media identifiers and MIME-related references
- `component/admin/forms/filter_media.xml` — media filters

These findings confirm the presence of implementation code, **not** that the old UI workflows or security protections still function.

## Validation plan

1. Create a test media record and associate it with a test product.
2. Repeat for category and manufacturer associations.
3. Upload allowed and disallowed formats; verify extension, MIME and actual content validation.
4. Test oversized uploads, SVG/HTML-like content, filename collisions and unusual Unicode names.
5. Verify safe paths, file permissions, access control, deletion and orphan cleanup.
6. Check thumbnail generation, image dimensions, alternative text and storefront rendering.
7. Test Joomla 5/6 administrator functionality and accessibility.

## Outstanding editorial work

Preserve original field explanations, procedures, image links and screenshots. Compare them line by line against the current administrator before publication.

Sources: `manual/en-US/chapters/media/working-medias.md` (`gh-pages`) and the current code paths listed above (`develop`).
