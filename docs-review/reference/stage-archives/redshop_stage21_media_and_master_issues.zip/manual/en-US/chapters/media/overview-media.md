# Media

redSHOP provides a media management area for images and other supported media. See [Working with Media](working-medias.md).

**Review status:** The original article contains detailed screenshots and procedures. This stage adds a verified audit and does not replace the original guide in GitHub.
