# Stockroom Image Management

Stockroom images provide a visual way to communicate stock availability. For example, a storefront may use different images for available, limited or unavailable stock. The actual image shown depends on the stock configuration and the active product template.

## Open Stockroom Image Management

Sign in to the Joomla administrator and open **Components → redSHOP → Stockroom Images** or the corresponding stock-image management view.

![Stock image listing](img/rs506-stockimage-list.png)

## Create a stockroom image rule

1. Open the stock-image listing and select **New**.
2. Enter a **Stock Amount Image Tooltip**.
3. Select a **Stockroom**.
4. Select the **Stock Option**.
5. Enter a **Stock Quantity**.
6. Select or upload a **Stock Amount Image**.
7. Save the record.
8. Verify that the rule appears in the listing.

![Stock image editor](img/rs506-stockimage-editor.png)

## Current editor fields

The current `stockimage.xml` form defines:

| Field | Purpose |
| --- | --- |
| **Stock Amount Image Tooltip** | Required text describing the stock image. |
| **Stockroom** | Required stockroom selection, loaded from the stockroom database table. |
| **Stock Option** | Required stock condition or comparison option. |
| **Stock Quantity** | Required positive integer threshold, minimum 1. |
| **Stock Amount Image** | Media control for selecting or uploading an image. |

The exact choices available under **Stock Option** come from a custom field type and must be confirmed in the running administrator.

### Example

A shop might want a stock image that indicates low availability when only a few items remain. Configure a suitable stock option and quantity threshold, select the corresponding stockroom and choose an image. Verify the comparison logic before relying on the image to communicate availability.

Do not assume that every image is shown automatically after saving: the product template must support the relevant stock image output.

## Display stockroom images on product details

The original redSHOP manual includes a workflow for displaying stock images on product detail pages.

1. Create the stock image rule.
2. Confirm that the product has stock quantities in the selected stockroom.
3. Open the product detail template or relevant stockroom display settings.
4. Open **Customization → Templates**, select the product-detail template, and add the historical tag `{product_stock_amount_image}` where the stock image should appear.
5. Save the template and confirm that the tag is processed by the current redSHOP version.
6. View the product on the storefront.
7. Test quantities above, at and below the configured threshold.

![Stock image frontend](img/rs506-stockimage-frontend.png)

Check the tooltip and alternative text for accessibility. Images should not be the only indication of stock availability.

## Edit or remove a stock image

Open an existing stock image record to change its tooltip, stockroom, threshold or image. Save and test the frontend again.

Before deleting a stock image, check whether the image is reused by another rule or elsewhere in the catalogue. The image record and the underlying media file may have different lifecycles.

## Troubleshooting

**Image does not appear:** verify the stockroom, rule threshold, product quantity and template support.

**Wrong image appears:** check whether several rules overlap for the same stockroom and quantity.

**Tooltip is missing:** verify the tooltip field and the frontend template's rendering.

**No stockrooms are selectable:** create and save a stockroom first.

## Related documentation

- [Stockroom Management](stockroom-management.md)
- [Inventory for All Stockrooms](inventory-stockroom.md)
