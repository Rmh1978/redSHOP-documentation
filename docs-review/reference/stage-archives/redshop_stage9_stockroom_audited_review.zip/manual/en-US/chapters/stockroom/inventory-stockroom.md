# Inventory for All Stockrooms

The inventory listing lets administrators review and edit stock quantities across stockrooms. The current listing supports product-level inventory and stock for attribute properties and subproperties.

## Open the inventory listing

In the Joomla administrator, open **Components → redSHOP → Stockroom**, then choose the inventory or stockroom listing view.

![Stockroom inventory](img/rs506-stockroom-inventory.png)

## Search and filter inventory

The current inventory listing has:

- A keyword search field.
- A search selector for **Product Name** or **Product Number**.
- A category filter.
- A stockroom-type filter for **Product**, **Property** or **Subproperty**.
- A reset control.

For a product with multiple sizes or colours, switch from Product to Property or Subproperty to inspect the relevant attribute stock records.

## Understand the columns

The listing displays product SKU and product name. When viewing properties or subproperties, it also shows the corresponding attribute identifier and name.

For each stockroom, the table displays two editable quantities:

| Column | Meaning |
| --- | --- |
| **Stockroom quantity** | Quantity available in that stockroom for the selected product or attribute record. |
| **Preorder stockroom quantity** | Quantity configured for preorder handling. |

The current template also tracks **ordered preorder** values separately. Do not confuse available preorder capacity with units already ordered.

![Inventory quantities](img/rs506-stockroom-quantities.png)

## Update inventory

1. Search for the product or variant.
2. Confirm that the correct stockroom and inventory type are selected.
3. Change the stockroom quantity.
4. Update preorder quantity only if preorders are supported for that item.
5. Use the inventory save action.
6. Reload the page and confirm the stored values.
7. Test the product page and cart to confirm the intended purchasing behaviour.

For example, if **Main Warehouse** has 15 units and **External Warehouse** has 8, the listing should show those values separately. Do not assume the frontend will always display the simple sum; stockroom-selection and availability rules may affect it.

## Product editor stockroom panel

The current product editor includes a stockroom table showing:

- Stockroom name.
- Available quantity.
- Minimum delivery time.
- Preorder stockroom quantity.
- Already ordered preorder quantity.

It also includes a **Reset** action for preorder-related values. Use this carefully and verify its effect on test data before applying it to a product with actual outstanding preorders.

![Product stockroom panel](img/rs506-stockroom-product-panel.png)

## Totals and stockroom columns

The historical inventory screen documents a **Total** column aggregating stock quantities. The current template calculates quantity and preorder totals across stockrooms; check the exact totals and labels in the rendered table. Historical screenshots call the default stockroom columns **Default** and **Preorder Stock default**, but actual names depend on configured stockrooms.

## Print and export

The historical manual mentions print and export workflows. The current inventory listing explicitly implements a **Print** action that opens a printable listing. Confirm whether a separate export control is available in your installed version.

## Troubleshooting

**Inventory edits do not persist:** verify the save action, permissions and input values, then reload.

**A variant is missing:** switch to the correct Property or Subproperty inventory type and check the product's attribute setup.

**Preorder counts look inconsistent:** distinguish configured preorder capacity from already ordered preorder quantity. Do not reset outstanding counts without investigating.

**The storefront shows a different stock status:** check global stock configuration, stockroom visibility, product-level stock rules and caching.

## Related documentation

- [Stockroom Management](stockroom-management.md)
- [Stockroom Image Management](stockroom-image-management.md)
