# Stockroom

redSHOP stockrooms let you track quantities and preorders across one or more stock locations. You can manage stockrooms, update inventory for products and attribute variants, and configure images that represent stock availability.

## Stockroom guides

- [Stockroom Management](stockroom-management.md) — create locations, configure delivery times and publication.
- [Inventory for All Stockrooms](inventory-stockroom.md) — review and update quantities, preorders and variant stock.
- [Stockroom Image Management](stockroom-image-management.md) — associate availability images with stockroom thresholds.

## Recommended workflow

1. Create and publish the required stockrooms.
2. Set minimum stock and delivery-time information.
3. Add stock quantities for products and relevant attribute properties.
4. Test the effect of stock and preorder quantities on the storefront.
5. Optionally configure stockroom images and test their display.

Use a test product before updating stock in bulk. Stock and preorder settings may affect purchasing availability.
