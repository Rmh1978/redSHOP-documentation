# Stage 9 — original-content audit and code checks

All four original stockroom articles were read in full and compared against the drafts.

## Recovered details
- Stockroom Management: historical Inventory, Copy, Publish/Unpublish and search actions; stock minimum email notifications require a separate named plugin.
- Inventory: historical totals and default-stockroom columns; CSV export described in 2019 but not yet confirmed in current UI.
- Stockroom Images: historical product-template tag `{product_stock_amount_image}` explicitly restored.
- Overview: all three links preserved.

## Source verification
- `component/admin/forms/stockroom.xml`: name, min_stock_amount, delivery_time, min_del_time, max_del_time, show_in_front, published, desc.
- `component/admin/forms/stockimage.xml`: tooltip, stockroom, option, positive stock quantity and media field.
- `component/admin/tmpl/stockroomlisting/default.php`: search by name/SKU, category, stock type, stockroom and preorder quantities, print action.
- `component/admin/tmpl/product/edit_productstockroom.php`: product-level quantity, delivery time, preorder and reset action.

## Not yet verified
Live Joomla admin toolbar actions, notification plugin, CSV export, stock image tag rendering, stock option semantics, screenshots and end-to-end checkout behaviour.

No GitHub changes made.
