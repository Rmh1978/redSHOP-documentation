# Stage 9 — Stockroom screenshots

- [ ] rs506-stockrooms-list.png — list
- [ ] rs506-stockrooms-editor.png — form
- [ ] rs506-stockroom-inventory.png — inventory listing
- [ ] rs506-stockroom-quantities.png — stockroom columns
- [ ] rs506-stockroom-product-panel.png — product stock panel
- [ ] rs506-stockimage-list.png — stock image list
- [ ] rs506-stockimage-editor.png — stock image editor
- [ ] rs506-stockimage-frontend.png — storefront
