# Stage 9 follow-up

- [ ] Verify stockroom list toolbar and actions on redshop6.
- [ ] Verify minimum-stock threshold behaviour.
- [ ] Verify stockroom delivery-time output on frontend.
- [ ] Test product, property and subproperty inventory save.
- [ ] Test preorder quantities and reset without affecting real orders.
- [ ] Confirm print action and whether export is supported.
- [ ] Confirm custom Stock Option choices and comparison semantics.
- [ ] Verify stock image template tags and frontend output.
- [ ] Confirm deletion behaviour for stockroom and stock image records.
- [ ] Capture eight screenshots.
- [ ] Perform field-by-field original-content audit and verify rendered links.
- [ ] Review Joomla 6 compatibility of stockroom admin JavaScript.

## Additional original-content checks

- [ ] Verify the historical `redSHOP Stockroom Status notice for admin` plugin and whether minimum-stock notifications are still supported.
- [ ] Verify Stockroom List Inventory, Copy, Publish, Unpublish and search controls.
- [ ] Verify historical Inventory **Export Data** CSV action and its columns; current listing explicitly shows print.
- [ ] Verify stockroom totals shown in the inventory listing.
- [ ] Confirm `{product_stock_amount_image}` is supported by current template parser and test with in-stock/out-of-stock rules.
- [ ] Check stock-image listing search and filtering against current UI.
- [ ] Review original Fleeq tutorial links before reuse.
