# Dashboard Configuration

> **Updated for:** redSHOP 5.0.6 · **Joomla:** 5.4

The **Dashboard** configuration tab contains settings for showing or hiding administrative menu entries. It should not be confused with the dashboard's reporting widgets or the Joomla administrator's own dashboard.

![Dashboard configuration](img/rs506-dashboard-configuration.png)

## Configuring menu visibility

Open **Components → redSHOP → Configuration → Dashboard**. The current configuration template loads a dedicated **Menu Hide** section. Select the entries you want to hide or display and save the configuration.

![Menu visibility settings](img/rs506-dashboard-menu-visibility.png)

The available entries depend on the installed redSHOP build and extensions. The available menu entries are listed in the configuration screen.

## Important distinction: visibility versus permissions

Hiding a menu entry is a presentation choice, **not an access-control mechanism**. Use Joomla permissions and redSHOP's supported authorization controls to restrict administrative actions. Permissions should be configured independently of menu visibility.

## Further information

More examples of menu visibility and administrator permissions will be added in a future update.
