# Feature Settings

> **Updated for:** redSHOP 5.0.6 · **Joomla:** 5.4

The **Features** configuration tab contains independent sections for product ratings, import/export, inline editing, product comparisons, stockrooms and wishlists.

![Features overview](img/rs506-features-overview.png)

## Ratings and reviews

![Rating settings](img/rs506-features-ratings.png)

The configuration includes a **review completion message**, **number of favoured reviews**, **rating thumbnail dimensions**, and a **login required for reviews** option. The active frontend template determines how reviews are presented.

## Import and export

![Import settings](img/rs506-features-import.png)

Import configuration includes file-size constraints, accepted MIME types and extensions, and a maximum-line setting. Treat these as configuration controls, not proof that every file type is safe or supported. Always test imports with a small sample and take a backup before bulk updates.

## Inline editing

The **Inline Editing** switch is present in the configuration template. Detailed usage instructions will be added in a future update.

## Product comparison

![Comparison settings](img/rs506-features-comparison.png)

Settings include enabling comparisons, a product comparison limit, a comparison type, a comparison template and image dimensions. Availability on the storefront depends on the selected template.

## Stockrooms

![Stockroom settings](img/rs506-features-stockrooms.png)

Settings include **Use Stockroom**, **Treat Blank as Infinite**, **Default Stockroom**, stock image dimensions, an out-of-stock image option, stock notifications and a low-stock threshold. Stockrooms work together with product availability and stock notifications.

## Wishlists

![Wishlist settings](img/rs506-features-wishlist.png)

The template provides **Enable Wishlist**, **Login Required** and a wishlist list setting. Access may differ between guests and logged-in customers.
