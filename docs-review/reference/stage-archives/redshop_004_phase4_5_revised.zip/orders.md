# Order and Invoice Configuration

> **Updated for:** redSHOP 5.0.6 · **Joomla:** 5.4

Open **Components → redSHOP → Configuration → Orders** to manage order email and invoice settings.

![Order configuration overview](img/rs506-orders-overview.png)

## Order settings

![Order settings](img/rs506-orders-settings.png)

- **Order ID Reset** — a maintenance action relating to order numbering. Do not use on a live store without first checking existing order records and taking a database backup.
- **Send Order Email** — selects when order notifications are dispatched relative to payment. The timing also depends on the payment method.
- **Enable Invoice Email** — controls invoice email sending.
- **Send Invoice Mail To** — selects the invoice email recipients.
- **Send Mail to Customer** — controls customer-facing order communication.
- **Exclude Products from Reorder** — selects products that should not be offered through the reorder workflow. This setting is present in redSHOP 5.0.6 and was missing from the old guide.

## Invoice settings

![Invoice settings](img/rs506-orders-invoices.png)

- **First Invoice Number** — starting value used by invoice numbering logic.
- **Order Number Template** — controls the configured order-number format.
- **Invoice Number Template** — controls the configured invoice-number format.
- **Invoice Number for Free Orders** — configures numbering behavior for orders without a payable total.

**Important:** Invoice numbering and accounting obligations vary by jurisdiction. Verify the resulting sequence, uniqueness and formatting before enabling the store for real orders.

## Further information

Step-by-step examples for payment statuses, invoice sequences and email delivery will be added in a future update.
