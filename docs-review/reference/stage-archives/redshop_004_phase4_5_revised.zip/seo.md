# SEO Configuration

> **Updated for:** redSHOP 5.0.6 · **Joomla:** 5.4

redSHOP provides configuration for search-engine-friendly URLs and automatically generated metadata. Open **Components → redSHOP → Configuration → SEO**.

![SEO configuration overview](img/rs506-seo-overview.png)

## General SEO settings

![General SEO settings](img/rs506-seo-general.png)

The current template exposes the following options:

- **Include Product Number in SEF URL**.
- **SEF Number/Name option**.
- **Include Category in SEF URL**.
- **Include Category Tree in SEF URL**.
- **Automatically Generated SEO**.
- **SEO Page Language**.

It also provides menu-item mappings for account, billing and shipping addresses, cart, checkout, gift cards, manufacturers, order details, orders, quotations, registration and wishlists. These mappings can affect routing and menu context.

**Changing SEF settings can change existing URLs.** On an established store, plan redirects and verify canonical URLs, multilingual routes and sitemap links before deploying changes.

## Category, product and manufacturer SEO

![Product SEO settings](img/rs506-seo-products.png)

Separate sections configure category, product and manufacturer metadata. Use them to define fallback metadata where item-specific values are absent. These settings provide defaults for generated metadata.

## Available SEO placeholders

The current SEO configuration template includes placeholder descriptions for product, manufacturer and category names; category hierarchy; sale price and savings; shop name; product SKU; and short descriptions. The available set varies by metadata field (title, heading, description or keywords). Use the placeholders listed for each field in the administrator interface.

## Further information

Examples of SEO templates, multilingual URLs and redirect handling will be added in a future update.
