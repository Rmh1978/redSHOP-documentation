# Shopping Cart and Checkout Configuration

> **Updated for:** redSHOP 5.0.6 · **Joomla:** 5.4

The **Cart** configuration tab controls add-to-cart behavior, the shopping cart, payment and shipping options, and cart images. Open **Components → redSHOP → Configuration → Cart**. 

![Cart configuration overview](img/rs506-cart-overview.png)

## Add to Cart settings

![Add to Cart settings](img/rs506-cart-add-to-cart.png)

The current configuration template exposes:

- **Individual Add to Cart** — controls the add-to-cart interface for products with selectable options.
- **Allow Pre-order** and **Pre-order Message** — configure whether pre-ordering is offered and the accompanying message.
- **Quotation Mode** and **Show Quotation Price** — control quotation-related behavior and price presentation.
- **Cart Timeout** — configures cart lifetime; the exact expiry behavior may depend on the checkout implementation.
- **AJAX Cart Box**, its template, display duration and dimensions — configure the cart feedback displayed after adding an item.
- **Add-to-cart button behavior** — controls the configured button action.
- **Clear User Information** — enables the corresponding customer-information clearing option.

## Cart settings

![Cart settings](img/rs506-cart-settings.png)

- **One-step Checkout** — enables the corresponding checkout presentation option.
- **Show Shipping in Cart** — controls shipping information in the cart.
- **Show Attribute Image in Cart** — displays product-option imagery where supported by the selected template.
- **Quantity Text**, **Default Quantity**, and **Quantity Select Box Values** — configure quantity input presentation.
- **Continue Shopping Redirect** — controls where the customer is sent when continuing shopping.
- **Minimum Order Total** — sets the minimum total permitted by the cart configuration. The applicable total is calculated during checkout.

## Payment, shipping and security

![Payment and shipping settings](img/rs506-cart-payment-shipping.png)

The current template includes **Payment Calculation On**, **Optional Shipping Address**, **Enable Shipping Methods**, **Split Delivery Cost**, **Split Calculation Time Difference**, and **Delivery Rule**. Shipping availability and costs also depend on enabled shipping plugins and their configuration. Payment choices depend on the enabled payment plugins.

The **SSL in Checkout** and **SSL in Backend** settings remain present. Configure HTTPS at the Joomla/server level as well; these settings are not a replacement for a valid TLS certificate and secure site configuration.

## Cart image settings

![Cart image settings](img/rs506-cart-images.png)

Cart image dimensions and templates are configured separately from the cart's behavioral settings. Preview both desktop and mobile checkout after changing them.

## Further information

Detailed examples for cart totals, checkout flows and payment methods will be added in a future update.
