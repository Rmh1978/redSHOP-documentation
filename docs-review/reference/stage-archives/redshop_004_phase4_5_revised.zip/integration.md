# Integration Configuration

> **Updated for:** redSHOP 5.0.6 · **Joomla:** 5.4

The **Integration** configuration tab contains legacy integration sections. Additional integrations may be delivered as separate Joomla plugins and therefore **will not necessarily appear in this tab**.

![Integration overview](img/rs506-integration-overview.png)

## Settings shown in the Integration tab

The current PHP template loads sections for **GLS**, **Clickatell**, **Post Danmark**, and **e-conomic**. The availability of each integration depends on the external provider and the installed software. Provider compatibility depends on the installed plugin version and external service.

![Integration settings](img/rs506-integration-legacy.png)

## Integrations delivered as plugins

The redSHOP 5.0.6 component manifest lists separate integration-related plugins, including **Billy** accounting and **PostNord Shipment**, plus payment plugins such as **Bambora** and **Flatpay**, and the **PostNord Pickup Point** shipping plugin. The manifest also includes a **Relatel** system plugin. Detailed setup guides for individual plugins will be added in a future update.

To locate an installed plugin, open **System → Manage → Plugins** in Joomla and search for the provider or redSHOP plugin group. Plugin availability and enabled status may vary by installation.

![Installed redSHOP plugins](img/rs506-integration-plugins.png)

## Security and maintenance

Keep API credentials out of screenshots and public documentation. Use separate test accounts when configuring integrations.
