# Revised documentation package – phases 4 and 5

Copy the six article files to `manual/en-US/chapters/global-configuration/` in the documentation repository.

- `SCREENSHOT-CHECKLIST.md`: internal screenshot locations and filenames.
- `FOLLOW-UP-TRACKER.md`: internal outstanding work list, maintained across future phases.

**Do not publish** the tracker, screenshot checklist or this README as manual articles. The six public articles have had internal verification notes and source-file references removed or rewritten for readers. Screenshots are not included.
