# redSHOP Configuration Wizard

> **Documentation target:** redSHOP 5.0.6 · **Verification:** Source-code reviewed; confirm the screens and entry point in a running Joomla installation before marking this page UI-verified.

The Configuration Wizard provides a guided way to enter initial store settings. The current redSHOP source still includes a Wizard controller, view, and templates for the welcome, general, terms, user, price, and finish screens. This does **not** establish that every older shortcut to the wizard is still visible in the administrator interface.

![Configuration Wizard welcome screen](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-welcome.png)

## Before you begin

Sign in to the Joomla administrator with permission to manage redSHOP. Make sure the store's contact details, shipping countries, currency, tax policy, and terms-and-conditions article are ready. On an existing shop, review the settings carefully: completing the wizard saves configuration values and can change checkout behaviour.

## Open the wizard

Open redSHOP in the Joomla administrator and look for **Configuration Wizard**. Its precise menu or dashboard position must be confirmed on your installation. If no entry point is visible, do not assume the wizard is available simply because its code exists; use the regular redSHOP configuration screen instead.

## Welcome

The introductory screen explains the setup process. Continue to the general settings when ready.

## General settings

![Wizard general settings](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-general.png)

The wizard's source defines selections for **Shop Country**, **Default Shipping Country**, **Countries you will sell to**, and **Date Format**. It also provides invoice-email settings. Complete the shop's general information, and verify that the countries selected match the markets you actually serve.

The available country choices come from redSHOP's country database. Invoice-email settings include whether invoices are emailed and whether the recipient is the administrator, customer, or both.

## Terms and conditions

![Wizard terms and conditions](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-terms.png)

Use the terms step to configure the store's terms and conditions. Prepare and publish the relevant Joomla article first, then select it in the wizard if the interface provides an article selector. Check the terms link in a test checkout after saving.

## User settings

![Wizard user settings](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-users.png)

The current wizard view contains four registration-method choices:

| Option | Purpose |
| --- | --- |
| Account creation | Customer creates an account during registration. |
| Without account creation | Registration without requiring a customer account. |
| Optional account creation | Customer may choose whether to create an account. |
| Silent account creation | Account creation is handled without a conventional registration prompt. |

The precise checkout behaviour of each choice should be tested on your store before enabling it in production. The wizard also prepares shopper-related settings.

## Price, VAT and discounts

![Wizard price and tax settings](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-price.png)

Choose the shop currency and review number formatting, VAT settings, and available discounts. The current source includes options to enable discounts, coupons, and vouchers and to choose how they may be combined. Make sure the chosen VAT calculation reflects the store's legal and accounting requirements; the wizard does not replace tax advice.

## Finish and verify

![Wizard finish screen](./manual/en-US/chapters/getting-started-general/img/rs506-wizard-finish.png)

The **Finish** action saves the wizard's configuration using redSHOP's configuration helper. The current controller also supports an optional sample-data action. Do not add sample data to an existing production catalogue without reviewing the consequences.

After finishing, open the regular redSHOP configuration screen, check the saved settings, and perform a test checkout (including shipping, tax, registration, and order email).

## Verification notes

- **Confirmed in code:** `component/admin/src/Controller/WizardController.php`, `component/admin/src/View/Wizard/HtmlView.php`, and `component/admin/tmpl/wizard/`.
- **Requires live UI confirmation:** navigation entry point, precise button captions, step numbering, and whether all fields render and save successfully on Joomla 5.4.
- **Do not reuse:** old Joomla 3 screenshots or historical claims about wizard buttons appearing automatically after installation.
