# redSHOP Configuration — General

> **Documentation target:** redSHOP 5.0.6 · **Verification:** Fields checked against the current configuration templates; live behaviour still requires testing.

The **General** section contains store settings, image and layout settings, and a selection of shop features.

![General configuration tab](./manual/en-US/chapters/global-configuration/img/rs506-config-general.png)

## Store settings

![Store settings panel](./manual/en-US/chapters/global-configuration/img/rs506-config-store-settings.png)

Use the store settings to maintain the shop's identity, location, supported sales countries, and related general options. Check the actual field labels in your installation before changing values; some fields are supplied through the separate `default_settings.php` template.

In particular, review **Shop Country**, **Default Shipping Country**, **Retail Countries**, and the store's contact details. Country restrictions can affect which customers are able to complete checkout.

## General layout and media settings

![General layout and media settings](./manual/en-US/chapters/global-configuration/img/rs506-config-general-layout.png)

The current General layout template includes the following settings:

| Setting | What it controls |
| --- | --- |
| Load redSHOP style | Whether redSHOP's own styling is loaded. Check the result against your Joomla template. |
| Allowed media MIME types | A text area listing allowed media types. Use only types your shop needs. |
| Image quality | Quality used when generating image output. The template's fallback value is `70`. |
| Image maximum width | Maximum configured image width; template fallback `2048`. |
| Image maximum height | Maximum configured image height; template fallback `2048`. |
| Image processing method | How images are resized or otherwise processed. |
| Maximum upload file size | redSHOP's configured upload-size limit; template fallback `2048` (confirm the unit in the running interface). |

**Upload security:** A permitted MIME type or filename extension alone does not make an uploaded file safe. Configure restrictive types, ensure the server's PHP upload limits are compatible, and test file validation separately. Do not assume the image upload limit also applies to every product-file upload workflow.

## Modules and features

![Modules and features panel](./manual/en-US/chapters/global-configuration/img/rs506-config-modules-features.png)

The current template exposes these controls:

| Setting | What it affects |
| --- | --- |
| Enable statistics | Controls a redSHOP statistics option; the exact collected data should be verified before enabling it. |
| Customer tags | Enables or disables the relevant customer-tagging feature. |
| Address details in shipping | Controls an address-related shipping option; verify checkout output after changing it. |
| Product reservation | Configures redSHOP's product-reservation behaviour. |
| Cart reservation message | Message shown for the configured reservation workflow. |

The product-reservation setting is especially important for limited stock. Test two simultaneous baskets before relying on it to prevent overselling; the presence of a setting does not prove the reservation workflow works in every checkout path.

## Save and verify

After making changes, save the configuration and reload the page. Then check the storefront, product images, file uploads, and checkout as appropriate. When changing upload-related options, test both a valid file and a rejected file.

## Verification notes

**Confirmed in code:** `component/admin/tmpl/configuration/default_general.php`, `default_general_layout_settings.php`, and `default_modules.php`.

**Requires UI confirmation:** translated labels, upload-size units, actual resize options, and the end-to-end behaviour of statistics, shipping-address details, and product reservation.

**Removed from the old article:** unsupported claims about UTF-8 configuration, exact currency-library choices, and image-quality recommendations that were not established by the inspected templates.
