# Customization screenshots

- [ ] Attribute Sets: list, edit and functional example
- [ ] Countries: list, edit and functional example
- [ ] Currency: list, edit and functional example
- [ ] Custom Field Groups: list, edit and functional example
- [ ] redSHOP Custom Fields: list, edit and functional example
- [ ] States: list, edit and functional example
- [ ] Templates: list, edit and functional example
- [ ] Zipcodes/Cities: list, edit and functional example
