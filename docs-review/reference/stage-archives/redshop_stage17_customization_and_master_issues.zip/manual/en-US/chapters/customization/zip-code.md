# Zipcodes/Cities

> **Review draft:** historical manual field inventory and workflows, not yet a faithful full-text replacement of the original. The original article remains the reference until a line-by-line comparison is completed.

## Purpose

This administrator area controls zipcodes/cities in redSHOP. Verify each change on the independent Joomla test installation before enabling it on the production store.

## Historical field reference

| Field in original manual | Check |
|---|---|
| City | Confirm current label, data type, validation, persistence and frontend effect |
| Country name | Confirm current label, data type, validation, persistence and frontend effect |
| State name | Confirm current label, data type, validation, persistence and frontend effect |
| Zipcode | Confirm current label, data type, validation, persistence and frontend effect |
| ID | Confirm current label, data type, validation, persistence and frontend effect |
| From | Confirm current label, data type, validation, persistence and frontend effect |
| To | Confirm current label, data type, validation, persistence and frontend effect |

## Original manual workflows to retain

1. Create a city/ZIP range.
2. Verify lookup and address selection.
3. Test range boundaries and shipping use.

## Current source verification

The current `component/admin/forms/zipcode.xml` on `develop` declares: `id`, `city_name`, `country_code`, `state_code`, `zipcode`, `zipcodeto`. These declarations are verified; business logic and frontend output are not.

## Administrator actions

The historical documentation describes list and edit screens, including New, Edit, Delete, Publish/Unpublish, Check-in, Save, Save & Close, Save & New, Cancel or Copy as applicable. Verify toolbar availability and permissions in the current UI.

## Test checklist

- [ ] Confirm original step-by-step instructions and screenshots against current admin UI
- [ ] Test required fields, invalid input and save/reopen behaviour
- [ ] Verify translations and administrator access control
- [ ] Verify customer-facing effects and safe HTML output
- [ ] Test Joomla 5 and Joomla 6 compatibility

## Source references

- Original: `manual/en-US/chapters/customization/zip-code.md` (`gh-pages`)
- Current form: `component/admin/forms/zipcode.xml` (`develop`)
