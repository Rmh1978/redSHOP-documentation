# redSHOP Custom Fields

> **Review draft:** historical manual field inventory and workflows, not yet a faithful full-text replacement of the original. The original article remains the reference until a line-by-line comparison is completed.

## Purpose

This administrator area controls redshop custom fields in redSHOP. Verify each change on the independent Joomla test installation before enabling it on the production store.

## Historical field reference

| Field in original manual | Check |
|---|---|
| Title | Confirm current label, data type, validation, persistence and frontend effect |
| Name | Confirm current label, data type, validation, persistence and frontend effect |
| Type | Confirm current label, data type, validation, persistence and frontend effect |
| Section | Confirm current label, data type, validation, persistence and frontend effect |
| Group | Confirm current label, data type, validation, persistence and frontend effect |
| Published | Confirm current label, data type, validation, persistence and frontend effect |
| ID | Confirm current label, data type, validation, persistence and frontend effect |
| CSS Class | Confirm current label, data type, validation, persistence and frontend effect |
| Display in Product List | Confirm current label, data type, validation, persistence and frontend effect |
| Show in Checkout | Confirm current label, data type, validation, persistence and frontend effect |
| Show in Front | Confirm current label, data type, validation, persistence and frontend effect |
| Required | Confirm current label, data type, validation, persistence and frontend effect |
| Description | Confirm current label, data type, validation, persistence and frontend effect |
| Size | Confirm current label, data type, validation, persistence and frontend effect |
| Maximum Length | Confirm current label, data type, validation, persistence and frontend effect |
| Columns | Confirm current label, data type, validation, persistence and frontend effect |
| Rows | Confirm current label, data type, validation, persistence and frontend effect |
| Option name | Confirm current label, data type, validation, persistence and frontend effect |
| Option value | Confirm current label, data type, validation, persistence and frontend effect |

## Original manual workflows to retain

1. Create a checkbox field.
2. Create a text area field.
3. Create a radio button field.
4. Create a single select field.
5. Create a text-tag content field.
6. Verify each field on the frontend.

## Current source verification

The original guide covers several custom field types. A direct current-form mapping has **not** been verified; field-type rendering and frontend output need a separate source audit.

## Administrator actions

The historical documentation describes list and edit screens, including New, Edit, Delete, Publish/Unpublish, Check-in, Save, Save & Close, Save & New, Cancel or Copy as applicable. Verify toolbar availability and permissions in the current UI.

## Test checklist

- [ ] Confirm original step-by-step instructions and screenshots against current admin UI
- [ ] Test required fields, invalid input and save/reopen behaviour
- [ ] Verify translations and administrator access control
- [ ] Verify customer-facing effects and safe HTML output
- [ ] Test Joomla 5 and Joomla 6 compatibility

## Source references

- Original: `manual/en-US/chapters/customization/redshop.md` (`gh-pages`)
