# Attribute Sets

> **Review draft:** historical manual field inventory and workflows, not yet a faithful full-text replacement of the original. The original article remains the reference until a line-by-line comparison is completed.

## Purpose

This administrator area controls attribute sets in redSHOP. Verify each change on the independent Joomla test installation before enabling it on the production store.

## Historical field reference

| Field in original manual | Check |
|---|---|
| Name | Confirm current label, data type, validation, persistence and frontend effect |
| Published | Confirm current label, data type, validation, persistence and frontend effect |
| ID | Confirm current label, data type, validation, persistence and frontend effect |
| Add Attribute Parameter | Confirm current label, data type, validation, persistence and frontend effect |
| Attribute parameter field | Confirm current label, data type, validation, persistence and frontend effect |
| Description | Confirm current label, data type, validation, persistence and frontend effect |
| Order | Confirm current label, data type, validation, persistence and frontend effect |
| Attribute required | Confirm current label, data type, validation, persistence and frontend effect |
| Allow multiple selection of attributes | Confirm current label, data type, validation, persistence and frontend effect |
| Hide Attribute Price | Confirm current label, data type, validation, persistence and frontend effect |
| Display Type | Confirm current label, data type, validation, persistence and frontend effect |
| Attribute Value | Confirm current label, data type, validation, persistence and frontend effect |
| Preselect | Confirm current label, data type, validation, persistence and frontend effect |
| Price | Confirm current label, data type, validation, persistence and frontend effect |
| Extra field | Confirm current label, data type, validation, persistence and frontend effect |
| Virtual product number | Confirm current label, data type, validation, persistence and frontend effect |

## Original manual workflows to retain

1. Create an attribute set.
2. Add an attribute parameter and value.
3. Associate the set with a product.
4. Verify single/multiple selection and price changes.

## Current source verification

The current `component/admin/forms/attribute.xml` on `develop` declares: `attribute_id`, `product_id`, `display_type`, `attribute_name`, `attribute_required`, `allow_multiple_selection`, `hide_attribute_price`, `published`. These declarations are verified; business logic and frontend output are not.

## Administrator actions

The historical documentation describes list and edit screens, including New, Edit, Delete, Publish/Unpublish, Check-in, Save, Save & Close, Save & New, Cancel or Copy as applicable. Verify toolbar availability and permissions in the current UI.

## Test checklist

- [ ] Confirm original step-by-step instructions and screenshots against current admin UI
- [ ] Test required fields, invalid input and save/reopen behaviour
- [ ] Verify translations and administrator access control
- [ ] Verify customer-facing effects and safe HTML output
- [ ] Test Joomla 5 and Joomla 6 compatibility

## Source references

- Original: `manual/en-US/chapters/customization/attribute.md` (`gh-pages`)
- Current form: `component/admin/forms/attribute.xml` (`develop`)
