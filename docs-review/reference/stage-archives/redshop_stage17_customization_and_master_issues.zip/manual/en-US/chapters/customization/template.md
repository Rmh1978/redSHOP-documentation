# Templates

> **Review draft:** historical manual field inventory and workflows, not yet a faithful full-text replacement of the original. The original article remains the reference until a line-by-line comparison is completed.

## Purpose

This administrator area controls templates in redSHOP. Verify each change on the independent Joomla test installation before enabling it on the production store.

## Historical field reference

| Field in original manual | Check |
|---|---|
| Template Name | Confirm current label, data type, validation, persistence and frontend effect |
| Section | Confirm current label, data type, validation, persistence and frontend effect |
| Published | Confirm current label, data type, validation, persistence and frontend effect |
| Filter by Template name | Confirm current label, data type, validation, persistence and frontend effect |
| Filter by Template section | Confirm current label, data type, validation, persistence and frontend effect |
| Description | Confirm current label, data type, validation, persistence and frontend effect |

## Original manual workflows to retain

1. Create a template.
2. Select its section.
3. Verify conditional order status, payment and shipping settings.
4. Check rendering and escaping.

## Current source verification

The current `component/admin/forms/template.xml` on `develop` declares: `id`, `name`, `section`, `order_status`, `payment_methods`, `shipping_methods`, `published`, `templateDesc`. These declarations are verified; business logic and frontend output are not.

## Administrator actions

The historical documentation describes list and edit screens, including New, Edit, Delete, Publish/Unpublish, Check-in, Save, Save & Close, Save & New, Cancel or Copy as applicable. Verify toolbar availability and permissions in the current UI.

## Test checklist

- [ ] Confirm original step-by-step instructions and screenshots against current admin UI
- [ ] Test required fields, invalid input and save/reopen behaviour
- [ ] Verify translations and administrator access control
- [ ] Verify customer-facing effects and safe HTML output
- [ ] Test Joomla 5 and Joomla 6 compatibility

## Source references

- Original: `manual/en-US/chapters/customization/template.md` (`gh-pages`)
- Current form: `component/admin/forms/template.xml` (`develop`)
