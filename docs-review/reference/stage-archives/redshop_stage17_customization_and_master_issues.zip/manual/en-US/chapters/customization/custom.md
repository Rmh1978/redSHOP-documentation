# Custom Field Groups

> **Review draft:** historical manual field inventory and workflows, not yet a faithful full-text replacement of the original. The original article remains the reference until a line-by-line comparison is completed.

## Purpose

This administrator area controls custom field groups in redSHOP. Verify each change on the independent Joomla test installation before enabling it on the production store.

## Historical field reference

| Field in original manual | Check |
|---|---|
| Name | Confirm current label, data type, validation, persistence and frontend effect |
| Section | Confirm current label, data type, validation, persistence and frontend effect |
| Description | Confirm current label, data type, validation, persistence and frontend effect |
| Published | Confirm current label, data type, validation, persistence and frontend effect |

## Original manual workflows to retain

1. Create a field group.
2. Assign a custom field to it.
3. Verify field ordering and visibility.

## Current source verification

The current `component/admin/forms/fieldgroup.xml` on `develop` declares: `id`, `name`, `section`, `description`, `published`. These declarations are verified; business logic and frontend output are not.

## Administrator actions

The historical documentation describes list and edit screens, including New, Edit, Delete, Publish/Unpublish, Check-in, Save, Save & Close, Save & New, Cancel or Copy as applicable. Verify toolbar availability and permissions in the current UI.

## Test checklist

- [ ] Confirm original step-by-step instructions and screenshots against current admin UI
- [ ] Test required fields, invalid input and save/reopen behaviour
- [ ] Verify translations and administrator access control
- [ ] Verify customer-facing effects and safe HTML output
- [ ] Test Joomla 5 and Joomla 6 compatibility

## Source references

- Original: `manual/en-US/chapters/customization/custom.md` (`gh-pages`)
- Current form: `component/admin/forms/fieldgroup.xml` (`develop`)
