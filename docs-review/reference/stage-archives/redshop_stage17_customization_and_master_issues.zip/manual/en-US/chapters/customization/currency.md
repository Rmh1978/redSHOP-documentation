# Currency

> **Review draft:** historical manual field inventory and workflows, not yet a faithful full-text replacement of the original. The original article remains the reference until a line-by-line comparison is completed.

## Purpose

This administrator area controls currency in redSHOP. Verify each change on the independent Joomla test installation before enabling it on the production store.

## Historical field reference

| Field in original manual | Check |
|---|---|
| Currency | Confirm current label, data type, validation, persistence and frontend effect |
| Currency code | Confirm current label, data type, validation, persistence and frontend effect |
| ID | Confirm current label, data type, validation, persistence and frontend effect |

## Original manual workflows to retain

1. Create a currency.
2. Select currency in shop configuration.
3. Test storefront and checkout.

## Current source verification

The current `component/admin/forms/currency.xml` on `develop` declares: `id`, `name`, `code`. These declarations are verified; business logic and frontend output are not.

## Administrator actions

The historical documentation describes list and edit screens, including New, Edit, Delete, Publish/Unpublish, Check-in, Save, Save & Close, Save & New, Cancel or Copy as applicable. Verify toolbar availability and permissions in the current UI.

## Test checklist

- [ ] Confirm original step-by-step instructions and screenshots against current admin UI
- [ ] Test required fields, invalid input and save/reopen behaviour
- [ ] Verify translations and administrator access control
- [ ] Verify customer-facing effects and safe HTML output
- [ ] Test Joomla 5 and Joomla 6 compatibility

## Source references

- Original: `manual/en-US/chapters/customization/currency.md` (`gh-pages`)
- Current form: `component/admin/forms/currency.xml` (`develop`)
