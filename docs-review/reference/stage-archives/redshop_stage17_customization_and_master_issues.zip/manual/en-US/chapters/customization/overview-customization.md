# Customization

redSHOP provides configuration for [Attribute Sets](attribute.md), [Countries](countries.md), [Currency](currency.md), [Custom Field Groups](custom.md), [Custom Fields](redshop.md), [States](states.md), [Templates](template.md) and [Zipcodes/Cities](zip-code.md).

Configure a country before its states and ZIP ranges. Test custom fields and templates in the frontend, and confirm any resulting changes to checkout and shipping.

**Status:** Review draft. Original detailed articles must be preserved and compared line by line before publication.
