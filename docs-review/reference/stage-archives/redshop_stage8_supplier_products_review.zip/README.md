# Stage 8 — Supplier Products

Replaces `manual/en-US/chapters/product-management/supplier-product.md`.

Preserves all major topics from the original manual: list, editor, creating, product assignment, template display, publish/unpublish, copy, delete and check-in.

Source-checked:
- `component/admin/forms/supplier.xml`
- `component/admin/src/Model/SupplierModel.php`
- `component/admin/tmpl/suppliers/default.php`

The current supplier form has four main fields and the model uses unique names when copying. The historical `{supplier_name}` tag, product association and toolbar behaviour still require end-to-end testing. No GitHub commit was made.
