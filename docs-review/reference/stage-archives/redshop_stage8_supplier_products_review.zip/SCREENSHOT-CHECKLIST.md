# Supplier screenshots

Capture on the redSHOP 5.0.6 test site. Place files in `manual/en-US/chapters/product-management/img/`.

- [ ] `rs506-supplier-list.png` — Supplier listing and visible columns.
- [ ] `rs506-supplier-toolbar.png` — Available toolbar actions.
- [ ] `rs506-supplier-editor.png` — Supplier form with name, email, published and description.
- [ ] `rs506-supplier-product-assignment.png` — Supplier selection in product editor.
- [ ] `rs506-supplier-template.png` — Product template with `{supplier_name}`.
- [ ] `rs506-supplier-frontend.png` — Product displaying supplier name.
- [ ] `rs506-supplier-publish.png` — Supplier published.
- [ ] `rs506-supplier-unpublish.png` — Supplier unpublished.
- [ ] `rs506-supplier-copy.png` — Copied supplier record.
- [ ] `rs506-supplier-delete.png` — Supplier delete confirmation.
- [ ] `rs506-supplier-checkin.png` — Check-in action.

Use demonstration suppliers and products; redact real supplier contact details.
