# Working with Suppliers in redSHOP

Suppliers are the businesses or individuals from whom you obtain products. redSHOP lets you maintain supplier records and associate a supplier with a product. You can use this information to organize product sourcing and, where your product template supports it, display supplier information on the storefront.

A **supplier** is not the same as a **manufacturer**. A manufacturer makes or brands the product; a supplier is the party supplying it to your business. Sometimes they are the same company, but they are managed as separate records in redSHOP.

## Open Supplier Management

1. Sign in to the Joomla administrator.
2. Open **Components → redSHOP**.
3. Choose **Products → Suppliers** from the administration navigation.
4. Select a supplier to edit it, or use **New** to create one.

![Supplier list](img/rs506-supplier-list.png)

## Supplier Management list

The supplier list shows the supplier records available to the shop.

The current supplier form defines these fields for list and editing use:

| Field | Description |
| --- | --- |
| **Name** | Name of the supplier. |
| **Email** | Supplier contact email address. |
| **Published** | Whether the supplier record is published. |
| **Description** | Additional information about the supplier. |

The list uses redSHOP's shared administration-list layout, so its exact toolbar arrangement may differ from older screenshots.

### Available list actions

The original supplier management interface documents these actions:

| Action | What it does |
| --- | --- |
| **New** | Create a supplier. |
| **Edit** | Open a supplier record for changes. |
| **Publish** | Publish selected suppliers. |
| **Unpublish** | Unpublish selected suppliers. |
| **Copy** | Duplicate selected supplier records. |
| **Delete** | Delete selected supplier records. |
| **Check-in** | Release supplier records locked for editing. |

![Supplier list toolbar](img/rs506-supplier-toolbar.png)

When selecting several records, check the selection carefully before applying a bulk action.

## Create a supplier

![Supplier editor](img/rs506-supplier-editor.png)

1. Open Supplier Management.
2. Select **New**.
3. Enter the supplier's **Name**.
4. Enter an **Email** address, if applicable.
5. Choose whether the supplier is **Published**.
6. Add a **Description**.
7. Select **Save** or **Save & Close**.
8. Confirm that the supplier appears in the listing.

### Name

The **Name** field is required in the current supplier form. Use a consistent, recognizable name. For example, if you buy several products from the same wholesaler, create one supplier record rather than several slight variations of the same name.

### Email

Optional supplier contact email. The current form applies email validation.

Entering an email does not, by itself, configure automatic purchase orders or supplier notifications. Those workflows require separate functionality.

### Published

The current form defaults new suppliers to **Published = Yes**.

A published supplier can be selected for supported product associations. Whether its information appears on the storefront also depends on the product and its template.

### Description

A rich-text description that can contain information useful to your staff or customers, depending on how it is displayed.

Avoid storing sensitive commercial terms, credentials or private supplier information in this field if it may be rendered on the public storefront.

## Save and close a supplier

The original supplier editor documents these actions:

- **Save:** save changes and remain in the editor.
- **Save & Close:** save changes and return to the supplier list.
- **Save & New:** save and begin creating another supplier.
- **Close:** leave the editor without saving unsaved changes.

If you make changes to an existing supplier, reopen the record to confirm that the values were saved.

## Assign a supplier to a product

The original redSHOP workflow places the supplier selection within the product editor's additional information.

![Supplier assignment on product](img/rs506-supplier-product-assignment.png)

1. Open **Products → Product Management**.
2. Edit the product you want to associate with a supplier.
3. Locate the **Supplier** selection in the product's additional information or corresponding product field.
4. Choose the supplier you created.
5. Save the product.
6. Reopen it to confirm the supplier association.

For example, a product branded by *Example Manufacturer* might be purchased through *Example Wholesale*. The product can have a manufacturer and a supplier without those being the same record.

If the supplier field is missing, check the installed product form, product type and customization before assuming that the supplier record is unavailable.

## Display supplier information on a product page

The original redSHOP manual uses the template tag `{supplier_name}` to display the associated supplier's name.

![Supplier template tag](img/rs506-supplier-template.png)

### Add the supplier name to a product template

1. Open **redSHOP → Customization → Templates**.
2. Find the template used for product detail pages.
3. Open the relevant product template.
4. Add `{supplier_name}` at the location where the supplier name should appear.
5. Save the template.
6. Open a product that has a supplier assigned.
7. Check whether the supplier name appears in the intended location.

For example, a product template could contain:

```text
Supplier: {supplier_name}
```

Only add the tag to a template type that supports it. If the tag appears literally on the page, the active template or installed version may not process that tag.

### Check the storefront result

![Supplier name on storefront](img/rs506-supplier-frontend.png)

Use a test product with a supplier and another without one. Check that the first displays the correct supplier name and that the second does not show a confusing empty label.

Showing a supplier publicly is optional. For shops where supplier relationships are commercially sensitive, keep this information in administration rather than adding the tag to the product template.

## Publish a supplier

1. Open Supplier Management.
2. Select the supplier or suppliers.
3. Choose **Publish**.
4. Confirm the status indicator has changed.

![Published supplier](img/rs506-supplier-publish.png)

Publication controls the supplier record's published state. Test the product page if it relies on supplier information.

## Unpublish a supplier

1. Open Supplier Management.
2. Select the supplier or suppliers.
3. Choose **Unpublish**.
4. Confirm the status indicator has changed.
5. Check products associated with the supplier if the storefront displays supplier details.

![Unpublished supplier](img/rs506-supplier-unpublish.png)

Unpublishing a supplier does not necessarily remove its association from existing products. Check the effect on the frontend in your installation.

## Copy a supplier

1. Select a supplier in the list.
2. Choose **Copy**.
3. Open the new record.
4. Change its name and any other fields that should differ.
5. Save and verify the new record.

![Copied supplier](img/rs506-supplier-copy.png)

The current supplier model configures the supplier **name** as a unique field during copying. Review the generated name before publishing or assigning the copied record.

## Delete a supplier

1. Identify any products associated with the supplier.
2. Reassign those products if needed.
3. Select the supplier in Supplier Management.
4. Choose **Delete**.
5. Confirm the deletion when prompted.
6. Check that the record is gone and the affected products still behave as intended.

![Delete supplier](img/rs506-supplier-delete.png)

Deleting a supplier may affect existing product associations and template output. Prefer unpublishing when you need to retain the record for reference.

## Check in a supplier

A supplier record may remain checked out if an administrator closes the editor unexpectedly.

1. Open Supplier Management.
2. Select the locked record.
3. Choose **Check-in**.
4. Reopen the record to confirm that it can be edited.

![Supplier check-in](img/rs506-supplier-checkin.png)

Check-in releases the edit lock; it does not restore unsaved changes.

## Troubleshooting

### A supplier is missing from the product editor

Confirm that the supplier exists and is published. Check whether the current product form exposes supplier selection in its additional-information area.

### The supplier name is not displayed on the storefront

Confirm the product has a supplier assigned, the active product template includes `{supplier_name}` and the template supports that tag.

### A supplier is not editable

The record may be checked out. Use the available check-in action if you have permission.

### Copying a supplier creates an unexpected name

The supplier model treats the name as unique when copying. Review the duplicated record before using it.

### A deleted supplier is still referenced by products

Check product associations and any cached frontend output. Update products to use a valid supplier record.

## Related documentation

- [Product Management overview](overview-product-management.md)
- [Working with Products](products-redshop.md)
- [Working with Manufacturers](redshop-manufacturers.md)
