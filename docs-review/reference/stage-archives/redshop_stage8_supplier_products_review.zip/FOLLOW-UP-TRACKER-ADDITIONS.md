# Internal follow-up — Supplier Products

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-S01 | OPEN | Verify shared admin list layout columns and toolbar actions in Joomla 5 test installation. |
| DOC-8-S02 | OPEN | Confirm Save / Save & Close / Save & New / Close in current supplier editor. |
| DOC-8-S03 | OPEN | Locate current product supplier field and verify supplier association storage. |
| DOC-8-S04 | OPEN | Verify `{supplier_name}` template tag is still processed by current product template engine. |
| DOC-8-S05 | OPEN | Test unpublished supplier behaviour on product page. |
| DOC-8-S06 | OPEN | Test copy operation and generated unique supplier name. |
| DOC-8-S07 | OPEN | Verify supplier deletion impact on product associations and database constraints. |
| DOC-8-S08 | OPEN | Confirm check-in works after abandoned editing session. |
| DOC-8-S09 | OPEN | Capture 11 screenshots and check article links. |
| DOC-8-S10 | OPEN | Review historical tutorial videos before linking publicly. |
