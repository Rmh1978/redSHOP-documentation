# Communication

redSHOP communication consists of transactional [Mail Templates](mails.md), [Newsletters](newletters.md), and [Newsletter Subscribers](newletters-subcribers.md).

## Recommended sequence

1. Configure transactional templates and verify a test order or account email.
2. Create a newsletter and preview its template.
3. Create or select a consented test subscriber.
4. Send only to test recipients and verify delivery, suppression and unsubscribe behaviour.

The original filenames `newletters.md` and `newletters-subcribers.md` are retained for link compatibility. Their displayed titles use corrected English spelling.

**Status:** Review draft; sending, opt-in and unsubscribe workflows require runtime verification.
