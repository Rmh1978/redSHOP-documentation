# Newsletter Subscribers

> **Review draft** — original manual fields compared with `develop` XML form. Email sending and consent workflows have not been runtime tested.

## Overview

The redSHOP administrator provides a management list and an edit form for newsletter subscribers. Work with test recipients before enabling production email.

## Historical fields

| Field in original guide | Purpose | Status |
|---|---|---|
| Username for subscriber | Subscriber account | Confirm in current administrator |
| Newsletters Subscription Date | Subscription date | Confirm in current administrator |
| Newsletter | Linked newsletter | Confirm in current administrator |
| Published | Subscriber state | Confirm in current administrator |
| Select User | Choose existing account | Confirm in current administrator |
| Select Newsletter | Choose target newsletter | Confirm in current administrator |
| Subscriber Email | Email address | Confirm in current administrator |

## Fields confirmed in current form

`user_id`, `newsletter_id`, `date`, `email`, `published`.

## Test workflow

1. Create a test subscriber using a test account.
2. Confirm association with the intended newsletter.
3. Check whether unpublished subscribers are excluded from sends.
4. Test unsubscribe, deletion and re-subscription handling.

## Administration actions

The historical manual documents New, Edit, Delete, Publish/Unpublish, Save, Save & Close and Cancel where relevant. Newsletters also document Copy and Send. Verify available actions in the current administrator and whether send requires confirmation.

## Operational and security notes

- Never send test campaigns to actual customers.
- Verify opt-in records, suppression, unsubscribe and applicable privacy requirements before any bulk sending.
- Ensure placeholders are escaped appropriately for HTML and email headers.
- Confirm background job/retry behaviour and avoid duplicate mail delivery.
- Protect BCC and subscriber email data in logs and screenshots.

## Screenshots to replace

- Administrator list and filters
- Edit form and template preview
- Test delivery or subscription result

## Source references

- Original guide: `manual/en-US/chapters/communication/newletters-subcribers.md` (`gh-pages`)
- Current form: `component/admin/forms/newslettersubscription.xml` (`develop`)
