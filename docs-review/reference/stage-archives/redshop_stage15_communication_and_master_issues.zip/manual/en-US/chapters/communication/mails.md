# Mails

> **Review draft** — original manual fields compared with `develop` XML form. Email sending and consent workflows have not been runtime tested.

## Overview

The redSHOP administrator provides a management list and an edit form for mails. Work with test recipients before enabling production email.

## Historical fields

| Field in original guide | Purpose | Status |
|---|---|---|
| Mail Name | Internal template label | Confirm in current administrator |
| Mail Subject | Message subject | Confirm in current administrator |
| Mail Section | Event or functional section | Confirm in current administrator |
| Mail BCC | Additional blind-copy recipients | Confirm in current administrator |
| Publish | Enable template | Confirm in current administrator |
| Body | Message body | Confirm in current administrator |

## Fields confirmed in current form

`mail_name`, `mail_section`, `mail_order_status`, `mail_bcc`, `mail_subject`, `published`, `mail_body`.

**Difference from original field inventory:** the current form has `mail_order_status`. Verify which mail sections use it and whether the condition is enforced.

## Test workflow

1. Create a mail template for a non-production event.
2. Set the subject and body, using only supported placeholder tags.
3. Trigger the event with a test customer and inspect the delivered message.
4. Check escaping, language, recipient selection and duplicate sends.

## Administration actions

The historical manual documents New, Edit, Delete, Publish/Unpublish, Save, Save & Close and Cancel where relevant. Newsletters also document Copy and Send. Verify available actions in the current administrator and whether send requires confirmation.

## Operational and security notes

- Never send test campaigns to actual customers.
- Verify opt-in records, suppression, unsubscribe and applicable privacy requirements before any bulk sending.
- Ensure placeholders are escaped appropriately for HTML and email headers.
- Confirm background job/retry behaviour and avoid duplicate mail delivery.
- Protect BCC and subscriber email data in logs and screenshots.

## Screenshots to replace

- Administrator list and filters
- Edit form and template preview
- Test delivery or subscription result

## Source references

- Original guide: `manual/en-US/chapters/communication/mails.md` (`gh-pages`)
- Current form: `component/admin/forms/mail.xml` (`develop`)
