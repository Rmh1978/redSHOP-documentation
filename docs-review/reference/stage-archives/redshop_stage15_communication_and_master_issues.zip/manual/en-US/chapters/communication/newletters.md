# Newsletters

> **Review draft** — original manual fields compared with `develop` XML form. Email sending and consent workflows have not been runtime tested.

## Overview

The redSHOP administrator provides a management list and an edit form for newsletters. Work with test recipients before enabling production email.

## Historical fields

| Field in original guide | Purpose | Status |
|---|---|---|
| Newsletter Name | Campaign label | Confirm in current administrator |
| Newsletter Subject | Email subject | Confirm in current administrator |
| No. of Subscribers | Subscriber count | Confirm in current administrator |
| Published | Publication status | Confirm in current administrator |
| Send Newsletter | Send action | Confirm in current administrator |
| Template | Optional layout template | Confirm in current administrator |
| Newsletter Body | Email content | Confirm in current administrator |

## Fields confirmed in current form

`name`, `subject`, `no_of_subscribers`, `body`, `template_id`, `published`, `tags_default`.

**Difference from original field inventory:** the form includes `tags_default`, a description field for template tags. Validate supported placeholders before documenting them as functional.

## Test workflow

1. Create a newsletter in a test environment.
2. Use a dedicated test subscriber list.
3. Preview and send only to test recipients.
4. Verify rendered layout, unsubscribe mechanism and send logs.

## Administration actions

The historical manual documents New, Edit, Delete, Publish/Unpublish, Save, Save & Close and Cancel where relevant. Newsletters also document Copy and Send. Verify available actions in the current administrator and whether send requires confirmation.

## Operational and security notes

- Never send test campaigns to actual customers.
- Verify opt-in records, suppression, unsubscribe and applicable privacy requirements before any bulk sending.
- Ensure placeholders are escaped appropriately for HTML and email headers.
- Confirm background job/retry behaviour and avoid duplicate mail delivery.
- Protect BCC and subscriber email data in logs and screenshots.

## Screenshots to replace

- Administrator list and filters
- Edit form and template preview
- Test delivery or subscription result

## Source references

- Original guide: `manual/en-US/chapters/communication/newletters.md` (`gh-pages`)
- Current form: `component/admin/forms/newsletter.xml` (`develop`)
