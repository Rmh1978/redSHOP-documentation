# Communication screenshots

- [ ] Mail list and edit form, including order status
- [ ] Mail preview and delivered test email
- [ ] Newsletter list and edit form
- [ ] Newsletter preview and send confirmation
- [ ] Subscriber list and edit form
- [ ] Subscription/unsubscribe frontend flow
