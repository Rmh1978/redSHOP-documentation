# Price Management screenshot checklist

Capture on the redSHOP 5.0.6 test installation and save in `manual/en-US/chapters/product-management/img/`.

- [ ] `rs506-price-product-list.png` — Product Price Management overview, search and price fields.
- [ ] `rs506-price-quantity-popup.png` — Shopper-group quantity price table or modal.
- [ ] `rs506-price-quick-save.png` — Quick-price editing and save control.
- [ ] `rs506-price-product-action.png` — Product editor Add Price action.
- [ ] `rs506-price-rules-list.png` — Product-specific price-rule listing.
- [ ] `rs506-price-rule-editor.png` — Detailed price editor, including dates.
- [ ] `rs506-price-frontend-cart.png` — Test customer's cart showing quantity-based pricing.

Avoid real customer details or live payment information.
