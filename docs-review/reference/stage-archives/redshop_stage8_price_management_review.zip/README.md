# Price Management — Stage 8

Replaces `manual/en-US/chapters/product-management/price-management.md`.

Source checked against:
- `component/admin/tmpl/price/edit.php`
- `component/admin/tmpl/prices/default.php`
- `component/admin/tmpl/productprice/default.php`
- Original 2019 public Price Management manual.

The historical quick-price interface and end-to-end storefront pricing require testing. Potential JavaScript validation issues are documented in the internal tracker, not in the public manual.

No GitHub changes were made.
