# Internal follow-up — Price Management

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-P01 | OPEN | Verify current Product Price Management screen and search controls. |
| DOC-8-P02 | OPEN | Confirm historical plus-icon modal exists and is compatible with Joomla 5. |
| DOC-8-P03 | OPEN | Test quick-price save task `saveprice` versus `productprice.saveprice`. |
| DOC-8-P04 | OPEN | Review `component/admin/tmpl/price/edit.php`: JavaScript validates `form.productprice`, but field is `product_price`; `form.discount_price` check may be reversed. |
| DOC-8-P05 | OPEN | Check price editor quantity range validation, discount price constraints and decimal input. |
| DOC-8-P06 | OPEN | Verify exact New/Edit/Delete toolbar actions on price-rule listing. |
| DOC-8-P07 | OPEN | Test overlapping shopper-group quantity ranges and rule precedence. |
| DOC-8-P08 | OPEN | Test discount date handling, timezone and empty date semantics. |
| DOC-8-P09 | OPEN | Verify storefront unit prices, subtotal, tax and checkout for quantity boundary cases. |
| DOC-8-P10 | OPEN | Capture seven screenshots and verify article links. |
| DOC-8-P11 | OPEN | Review historical tutorial video URLs for continued availability before adding links. |
