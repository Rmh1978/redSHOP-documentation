# Stage 12 screenshot checklist

- [ ] Coupons: list, edit form, frontend and checkout result
- [ ] Vouchers: list, edit form, frontend and checkout result
- [ ] Gift Cards: list, edit form, frontend and checkout result
- [ ] Mass Discounts: list, edit form, frontend and checkout result
- [ ] Order Total Discounts: list, edit form, frontend and checkout result
- [ ] Product Price Discounts: list, edit form, frontend and checkout result
- [ ] Promotions: list, edit form, frontend and checkout result
