# Master issues and gaps — stage 12 continuation

**Important:** This is a continuation register, not a verified merge of every previous stage tracker. Previous stage 11 master list must be merged and deduplicated when available. Do not treat this file as a complete historical issue register.

| ID | Stage | Priority | Finding | Status |
|---|---|---|---|---|
| DOC-001 | 1–5 | High | Full original-to-current field and workflow audit incomplete | Open |
| DOC-002 | 1–11 | High | Joomla 6 regression checks outstanding | Open |
| DOC-003 | 1–11 | Medium | Screenshots not verified on current admin UI | Open |
| SHIP-001 | 11 | High | Shipping rate calculation and provider integration runtime tests | Open |
| DISC-001 | 12 | High | Discount stacking and calculation order not verified | Open |
| DISC-002 | 12 | High | Coupon/voucher usage limits and expiry behaviour not verified | Open |
| DISC-003 | 12 | High | Gift card lifecycle and refund handling not verified | Open |
| DISC-004 | 12 | High | Promotion plugin awards and stock handling not verified | Open |
| DISC-005 | 12 | Medium | XML form fields may differ from dynamic edit view | Open |
| DISC-006 | 12 | Medium | Original screenshots require replacement | Open |
