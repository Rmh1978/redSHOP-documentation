# Gift Cards

> **Review draft — not yet approved for publication.** Historical field descriptions are preserved below; current form fields are independently identified. Runtime behaviour requires testing.

## Purpose

This feature manages gift cards in redSHOP. Configure and test the rule in a non-production store before enabling it for customers.

## Historical administrator fields

| Field in original manual | Description / intended use | Verification |
|---|---|---|
| Status | Publication state | Historical manual; current behaviour to test |
| Gift Card Name | Customer-facing title | Historical manual; current behaviour to test |
| Gift Card Image | Front image | Historical manual; current behaviour to test |
| Gift Card Background Image | Background artwork | Historical manual; current behaviour to test |
| Gift Card Price | Purchase price | Historical manual; current behaviour to test |
| Gift Card Value | Redeemable value | Historical manual; current behaviour to test |
| Gift Card Validity | Duration/expiry setting | Historical manual; current behaviour to test |
| Customer Amount | Whether customer chooses an amount | Historical manual; current behaviour to test |
| Free Shipping | Shipping treatment | Historical manual; current behaviour to test |
| Description | Customer-facing information | Historical manual; current behaviour to test |

## Fields confirmed in current source

The following field names occur in `component/admin/forms/giftcard.xml` on branch `develop`:

`giftcard_id`, `giftcard_name`, `customer_amount`, `giftcard_value`, `giftcard_validity`, `free_shipping`, `giftcard_bgimage`, `giftcard_image_file`, `giftcard_image`, `published`, `giftcard_desc`.

**Scope of verification:** These are XML form declarations, not proof that every field is shown, persisted, validated or used correctly. Other fields may be rendered dynamically by the edit view or plugins.

## Step-by-step test workflow

1. Create a published gift card with a fixed purchase price and value.
2. Open the gift-card list on the frontend and place a test order.
3. Check that purchase and redemption are separate events.
4. Test expiry and remaining balance, if supported by the current implementation.

## Actions and administration

The original manual documents list and edit actions including **New**, **Edit**, **Delete**, **Publish/Unpublish**, **Check-in**, **Save**, **Save & Close**, **Save & New** and **Cancel** where available. Verify the actual toolbar in the current view; not all actions appear on every screen.

## Troubleshooting

If a discount does not appear, verify publication status, start/end dates, customer group, target products or categories, threshold conditions and the discount combination settings under Global Configuration. If the rule appears but the amount is wrong, test tax, shipping and rounding separately. Do not assume a specific stacking priority until verified in the calculation code.

## Screenshots required

- Administrator listing and available actions
- Edit form with all field groups expanded
- Frontend example showing the result
- Cart/checkout totals before and after applying the rule

## Source references

- Historical article: `manual/en-US/chapters/discounts/gift-cards.md` (`gh-pages`)
- Current XML form: `component/admin/forms/giftcard.xml` (`develop`)
- Current model: `component/admin/src/Model/GiftcardModel.php` (identified in repository tree; runtime logic not yet audited)
