# Product Price Discounts

> **Review draft — not yet approved for publication.** Historical field descriptions are preserved below; current form fields are independently identified. Runtime behaviour requires testing.

## Purpose

This feature manages product price discounts in redSHOP. Configure and test the rule in a non-production store before enabling it for customers.

## Historical administrator fields

| Field in original manual | Description / intended use | Verification |
|---|---|---|
| Total amount | Threshold amount | Historical manual; current behaviour to test |
| Condition | Threshold comparison | Historical manual; current behaviour to test |
| Type | Fixed or percentage reduction | Historical manual; current behaviour to test |
| Discount amount | Reduction value | Historical manual; current behaviour to test |
| Start date | Start of eligibility | Historical manual; current behaviour to test |
| End date | End of eligibility | Historical manual; current behaviour to test |
| Category | Categories in scope | Historical manual; current behaviour to test |
| Shopper group | Customer group restriction | Historical manual; current behaviour to test |
| Published | Activation status | Historical manual; current behaviour to test |

## Fields confirmed in current source

The following field names occur in `component/admin/forms/discountproduct.xml` on branch `develop`:

`discount_product_id`, `amount`, `condition`, `start_date`, `end_date`, `category_ids`.

**Scope of verification:** These are XML form declarations, not proof that every field is shown, persisted, validated or used correctly. Other fields may be rendered dynamically by the edit view or plugins.

## Step-by-step test workflow

1. Create a rule restricted to one category.
2. Check eligible and noneligible products in the backend and frontend.
3. Test threshold equality and date expiry.
4. Repeat with a shopper group and compare prices for guests.

## Actions and administration

The original manual documents list and edit actions including **New**, **Edit**, **Delete**, **Publish/Unpublish**, **Check-in**, **Save**, **Save & Close**, **Save & New** and **Cancel** where available. Verify the actual toolbar in the current view; not all actions appear on every screen.

## Troubleshooting

If a discount does not appear, verify publication status, start/end dates, customer group, target products or categories, threshold conditions and the discount combination settings under Global Configuration. If the rule appears but the amount is wrong, test tax, shipping and rounding separately. Do not assume a specific stacking priority until verified in the calculation code.

## Screenshots required

- Administrator listing and available actions
- Edit form with all field groups expanded
- Frontend example showing the result
- Cart/checkout totals before and after applying the rule

## Source references

- Historical article: `manual/en-US/chapters/discounts/product-price-discount.md` (`gh-pages`)
- Current XML form: `component/admin/forms/discountproduct.xml` (`develop`)
- Current model: `component/admin/src/Model/DiscountProductModel.php` (identified in repository tree; runtime logic not yet audited)
