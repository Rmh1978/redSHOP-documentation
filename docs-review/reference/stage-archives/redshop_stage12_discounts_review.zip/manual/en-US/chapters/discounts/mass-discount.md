# Mass Discounts

> **Review draft — not yet approved for publication.** Historical field descriptions are preserved below; current form fields are independently identified. Runtime behaviour requires testing.

## Purpose

This feature manages mass discounts in redSHOP. Configure and test the rule in a non-production store before enabling it for customers.

## Historical administrator fields

| Field in original manual | Description / intended use | Verification |
|---|---|---|
| Name | Campaign label | Historical manual; current behaviour to test |
| Type | Discount calculation type | Historical manual; current behaviour to test |
| Amount | Discount value | Historical manual; current behaviour to test |
| Start date | Campaign start | Historical manual; current behaviour to test |
| End date | Campaign end | Historical manual; current behaviour to test |
| Products | Target products | Historical manual; current behaviour to test |
| Categories | Target categories | Historical manual; current behaviour to test |
| Manufacturers | Target manufacturers | Historical manual; current behaviour to test |

## Fields confirmed in current source

The following field names occur in `component/admin/forms/massdiscount.xml` on branch `develop`:

`id`, `name`, `type`, `start_date`, `end_date`.

**Scope of verification:** These are XML form declarations, not proof that every field is shown, persisted, validated or used correctly. Other fields may be rendered dynamically by the edit view or plugins.

## Step-by-step test workflow

1. Create one campaign for a single product.
2. Repeat with a category and a manufacturer selection.
3. Check the same product when multiple rules overlap.
4. Test date boundaries and discount priority.

## Actions and administration

The original manual documents list and edit actions including **New**, **Edit**, **Delete**, **Publish/Unpublish**, **Check-in**, **Save**, **Save & Close**, **Save & New** and **Cancel** where available. Verify the actual toolbar in the current view; not all actions appear on every screen.

## Troubleshooting

If a discount does not appear, verify publication status, start/end dates, customer group, target products or categories, threshold conditions and the discount combination settings under Global Configuration. If the rule appears but the amount is wrong, test tax, shipping and rounding separately. Do not assume a specific stacking priority until verified in the calculation code.

## Screenshots required

- Administrator listing and available actions
- Edit form with all field groups expanded
- Frontend example showing the result
- Cart/checkout totals before and after applying the rule

## Source references

- Historical article: `manual/en-US/chapters/discounts/mass-discount.md` (`gh-pages`)
- Current XML form: `component/admin/forms/massdiscount.xml` (`develop`)
- Current model: `component/admin/src/Model/MassDiscountModel.php` (identified in repository tree; runtime logic not yet audited)
