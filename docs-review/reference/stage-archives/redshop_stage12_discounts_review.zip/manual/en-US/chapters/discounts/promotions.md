# Promotions

> **Review draft — not yet approved for publication.** Historical field descriptions are preserved below; current form fields are independently identified. Runtime behaviour requires testing.

## Purpose

This feature manages promotions in redSHOP. Configure and test the rule in a non-production store before enabling it for customers.

## Historical administrator fields

| Field in original manual | Description / intended use | Verification |
|---|---|---|
| Name | Campaign name | Historical manual; current behaviour to test |
| Promotion Type | Promotion plugin/type | Historical manual; current behaviour to test |
| Description | Internal description | Historical manual; current behaviour to test |
| Publication | Enabled status | Historical manual; current behaviour to test |
| Condition Type | Condition selection | Historical manual; current behaviour to test |
| Manufacturer | Manufacturer condition | Historical manual; current behaviour to test |
| Category | Category condition | Historical manual; current behaviour to test |
| Product | Product condition | Historical manual; current behaviour to test |
| Quantity | Required quantity | Historical manual; current behaviour to test |
| From | Range start | Historical manual; current behaviour to test |
| To | Range end | Historical manual; current behaviour to test |
| Award Product | Reward product | Historical manual; current behaviour to test |
| Award Quantity | Reward quantity | Historical manual; current behaviour to test |
| Free Shipping | Reward shipping waiver | Historical manual; current behaviour to test |

## Fields confirmed in current source

The following field names occur in `component/admin/forms/promotion.xml` on branch `develop`:

`id`, `name`, `type`, `desc`.

**Scope of verification:** These are XML form declarations, not proof that every field is shown, persisted, validated or used correctly. Other fields may be rendered dynamically by the edit view or plugins.

## Step-by-step test workflow

1. Create a simple product-quantity promotion using a test product.
2. Add quantities just below and above the threshold.
3. Verify the award, stock effect and cart recalculation.
4. Check interaction with vouchers, coupons and other promotions.

## Actions and administration

The original manual documents list and edit actions including **New**, **Edit**, **Delete**, **Publish/Unpublish**, **Check-in**, **Save**, **Save & Close**, **Save & New** and **Cancel** where available. Verify the actual toolbar in the current view; not all actions appear on every screen.

## Troubleshooting

If a discount does not appear, verify publication status, start/end dates, customer group, target products or categories, threshold conditions and the discount combination settings under Global Configuration. If the rule appears but the amount is wrong, test tax, shipping and rounding separately. Do not assume a specific stacking priority until verified in the calculation code.

## Screenshots required

- Administrator listing and available actions
- Edit form with all field groups expanded
- Frontend example showing the result
- Cart/checkout totals before and after applying the rule

## Source references

- Historical article: `manual/en-US/chapters/discounts/promotions.md` (`gh-pages`)
- Current XML form: `component/admin/forms/promotion.xml` (`develop`)
- Current model: `component/admin/src/Model/PromotionModel.php` (identified in repository tree; runtime logic not yet audited)
