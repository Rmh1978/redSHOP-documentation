# Discounts

redSHOP has multiple discount mechanisms. Choose the mechanism based on whether the offer uses a code, applies automatically to an order threshold, targets products or categories, or awards an item.

| Mechanism | Documentation |
|---|---|
| Coupon | [Coupons](coupon.md) |
| Voucher | [Vouchers](voucher.md) |
| Gift card | [Gift Cards](gift-cards.md) |
| Mass discount | [Mass Discounts](mass-discount.md) |
| Order total discount | [Order Total Discounts](order-total-discount.md) |
| Product price discount | [Product Price Discounts](product-price-discount.md) |
| Promotion | [Promotions](promotions.md) |

## Before enabling a campaign

Use a test account and order. Verify discount stacking, taxes, shipping, currency precision, date boundaries and whether a coupon can be reused. Keep one known-good test order per discount mechanism. Check the discount settings under Global Configuration before assuming that different promotions combine.

**Status:** Review draft. Individual mechanisms need current model/controller and frontend calculation verification.
