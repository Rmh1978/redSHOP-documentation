# Order Total Discounts

> **Review draft — not yet approved for publication.** Historical field descriptions are preserved below; current form fields are independently identified. Runtime behaviour requires testing.

## Purpose

This feature manages order total discounts in redSHOP. Configure and test the rule in a non-production store before enabling it for customers.

## Historical administrator fields

| Field in original manual | Description / intended use | Verification |
|---|---|---|
| Name | Rule label | Historical manual; current behaviour to test |
| Total amount | Order threshold | Historical manual; current behaviour to test |
| Condition | Lower, Equal or Higher | Historical manual; current behaviour to test |
| Type | Total or Percentage | Historical manual; current behaviour to test |
| Discount amount | Discount applied when threshold matches | Historical manual; current behaviour to test |
| Start date | Start of eligibility | Historical manual; current behaviour to test |
| End date | End of eligibility | Historical manual; current behaviour to test |
| Shopper group | Eligible customer group | Historical manual; current behaviour to test |
| Published | Activation status | Historical manual; current behaviour to test |

## Fields confirmed in current source

The following field names occur in `component/admin/forms/discount.xml` on branch `develop`:

`discount_id`, `amount`, `condition`, `start_date`, `end_date`, `shopper_group`.

**Scope of verification:** These are XML form declarations, not proof that every field is shown, persisted, validated or used correctly. Other fields may be rendered dynamically by the edit view or plugins.

## Step-by-step test workflow

1. Create a test shopper group and assign a test customer.
2. Configure an order threshold and a percentage discount.
3. Test totals just below, equal to and above the threshold.
4. Repeat as a guest and another shopper group to confirm restrictions.

## Actions and administration

The original manual documents list and edit actions including **New**, **Edit**, **Delete**, **Publish/Unpublish**, **Check-in**, **Save**, **Save & Close**, **Save & New** and **Cancel** where available. Verify the actual toolbar in the current view; not all actions appear on every screen.

## Troubleshooting

If a discount does not appear, verify publication status, start/end dates, customer group, target products or categories, threshold conditions and the discount combination settings under Global Configuration. If the rule appears but the amount is wrong, test tax, shipping and rounding separately. Do not assume a specific stacking priority until verified in the calculation code.

## Screenshots required

- Administrator listing and available actions
- Edit form with all field groups expanded
- Frontend example showing the result
- Cart/checkout totals before and after applying the rule

## Source references

- Historical article: `manual/en-US/chapters/discounts/order-total-discount.md` (`gh-pages`)
- Current XML form: `component/admin/forms/discount.xml` (`develop`)
- Current model: `component/admin/src/Model/DiscountModel.php` (identified in repository tree; runtime logic not yet audited)
