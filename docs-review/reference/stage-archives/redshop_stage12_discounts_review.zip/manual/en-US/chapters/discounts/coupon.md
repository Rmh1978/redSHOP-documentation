# Coupons

> **Review draft — not yet approved for publication.** Historical field descriptions are preserved below; current form fields are independently identified. Runtime behaviour requires testing.

## Purpose

This feature manages coupons in redSHOP. Configure and test the rule in a non-production store before enabling it for customers.

## Historical administrator fields

| Field in original manual | Description / intended use | Verification |
|---|---|---|
| Coupon code | Unique code entered by the customer | Historical manual; current behaviour to test |
| Type | Discount value interpretation | Historical manual; current behaviour to test |
| Value | Discount amount or percentage | Historical manual; current behaviour to test |
| Start date | Earliest eligible date | Historical manual; current behaviour to test |
| End date | Last eligible date | Historical manual; current behaviour to test |
| Effect | Historical subtotal/effect selection | Historical manual; current behaviour to test |
| Subtotal | Historical calculation basis | Historical manual; current behaviour to test |
| Free shipping | Shipping waiver option | Historical manual; current behaviour to test |
| Amount left | Remaining redemption quantity | Historical manual; current behaviour to test |
| Published | Enable or disable the coupon | Historical manual; current behaviour to test |

## Fields confirmed in current source

The following field names occur in `component/admin/forms/coupon.xml` on branch `develop`:

`id`, `code`, `type`, `start_date`, `end_date`, `effect`, `free_shipping`.

**Scope of verification:** These are XML form declarations, not proof that every field is shown, persisted, validated or used correctly. Other fields may be rendered dynamically by the edit view or plugins.

## Step-by-step test workflow

1. Create a coupon in the administrator and record the code, validity dates and intended discount.
2. Apply the code in the cart before and after its start date, then after expiry.
3. Check discounted subtotal, tax, shipping and remaining uses.
4. Unpublish the coupon and confirm it can no longer be redeemed.

## Actions and administration

The original manual documents list and edit actions including **New**, **Edit**, **Delete**, **Publish/Unpublish**, **Check-in**, **Save**, **Save & Close**, **Save & New** and **Cancel** where available. Verify the actual toolbar in the current view; not all actions appear on every screen.

## Troubleshooting

If a discount does not appear, verify publication status, start/end dates, customer group, target products or categories, threshold conditions and the discount combination settings under Global Configuration. If the rule appears but the amount is wrong, test tax, shipping and rounding separately. Do not assume a specific stacking priority until verified in the calculation code.

## Screenshots required

- Administrator listing and available actions
- Edit form with all field groups expanded
- Frontend example showing the result
- Cart/checkout totals before and after applying the rule

## Source references

- Historical article: `manual/en-US/chapters/discounts/coupon.md` (`gh-pages`)
- Current XML form: `component/admin/forms/coupon.xml` (`develop`)
- Current model: `component/admin/src/Model/CouponModel.php` (identified in repository tree; runtime logic not yet audited)
