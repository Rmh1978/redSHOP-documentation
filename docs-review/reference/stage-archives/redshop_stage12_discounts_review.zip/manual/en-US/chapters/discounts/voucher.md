# Vouchers

> **Review draft — not yet approved for publication.** Historical field descriptions are preserved below; current form fields are independently identified. Runtime behaviour requires testing.

## Purpose

This feature manages vouchers in redSHOP. Configure and test the rule in a non-production store before enabling it for customers.

## Historical administrator fields

| Field in original manual | Description / intended use | Verification |
|---|---|---|
| Code | Voucher redemption code | Historical manual; current behaviour to test |
| Amount | Voucher value | Historical manual; current behaviour to test |
| Type | Amount or percentage mode | Historical manual; current behaviour to test |
| Start date | Historical validity start | Historical manual; current behaviour to test |
| End date | Expiry date | Historical manual; current behaviour to test |
| Free ship | Shipping waiver option | Historical manual; current behaviour to test |
| Published | Whether voucher can be redeemed | Historical manual; current behaviour to test |
| Amount left | Remaining redemption balance/quantity; verify semantics | Historical manual; current behaviour to test |
| Product | Eligible product association | Historical manual; current behaviour to test |

## Fields confirmed in current source

The following field names occur in `component/admin/forms/voucher.xml` on branch `develop`:

`id`, `code`, `amount`, `type`, `end_date`, `free_ship`, `voucher_products`.

**Scope of verification:** These are XML form declarations, not proof that every field is shown, persisted, validated or used correctly. Other fields may be rendered dynamically by the edit view or plugins.

## Step-by-step test workflow

1. Create a voucher with a specific product restriction.
2. Test eligible and ineligible products in the cart.
3. Apply the voucher and inspect totals and shipping.
4. Verify expiry, repeated redemption and disabling the voucher.

## Actions and administration

The original manual documents list and edit actions including **New**, **Edit**, **Delete**, **Publish/Unpublish**, **Check-in**, **Save**, **Save & Close**, **Save & New** and **Cancel** where available. Verify the actual toolbar in the current view; not all actions appear on every screen.

## Troubleshooting

If a discount does not appear, verify publication status, start/end dates, customer group, target products or categories, threshold conditions and the discount combination settings under Global Configuration. If the rule appears but the amount is wrong, test tax, shipping and rounding separately. Do not assume a specific stacking priority until verified in the calculation code.

## Screenshots required

- Administrator listing and available actions
- Edit form with all field groups expanded
- Frontend example showing the result
- Cart/checkout totals before and after applying the rule

## Source references

- Historical article: `manual/en-US/chapters/discounts/voucher.md` (`gh-pages`)
- Current XML form: `component/admin/forms/voucher.xml` (`develop`)
- Current model: `component/admin/src/Model/VoucherModel.php` (identified in repository tree; runtime logic not yet audited)
