# Stage 12 — Discounts review

- Eight English articles drafted, including an overview and seven feature guides.
- Historical field labels extracted from all seven original guides.
- Current Joomla XML form declarations confirmed against `Rmh1978/redSHOP-rmh` branch `develop`.
- Relevant models and views identified in repository tree, but business logic not yet inspected.
- No GitHub commits, staging changes or screenshots.

## Priority verification

1. Discount stacking and precedence across coupon, voucher, mass discount and promotions.
2. Tax and shipping calculation base.
3. Date/time-zone boundaries, expiration and remaining redemptions.
4. Guest vs shopper group and category restrictions.
5. Gift card purchase, activation, partial redemption and refunds.
6. Promotions plugin loading and award stock accounting.
7. Review historical screenshots and replace outdated Joomla UI.
