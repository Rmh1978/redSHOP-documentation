# Documentation roadmap

Current completed **draft** stages: 1–12. These are not all approved.

Estimated remaining work: users, VAT, communication, discounts follow-up, import/export, customization, customer input, media, accounting integration, modules, plugins, FAQ, and final audit. With 156 articles across 21 repository areas, a **20–23 stage** plan is provisional, not a fixed inventory of one stage per area.

Final approval requires historical-content comparison, source verification, Joomla 5/6 test coverage, screenshot audit, and issue-register closure.
