# Stage 1 screenshot checklist

Capture on Joomla 5 test installation, with no private credentials visible.

- [ ] `rs506-install-upload.png` — Joomla extension package upload.
- [ ] `rs506-install-setup.png` — current redSHOP setup/wizard screen, if it exists.
- [ ] `rs506-update-extensions.png` — Joomla extension update screen.
