# Installing redSHOP

Install redSHOP through Joomla's extension installer, then configure the shop and verify a complete test order before making it available to customers.

## Before installation

- Verify the [minimum requirements](redshop-minimum-requirements.md) for your Joomla and redSHOP versions.
- Obtain the **installable package** for the intended redSHOP release. The historical documentation linked to the original redCOMPONENT GitHub repository; do not assume that an old release is compatible with the current fork.
- Back up an existing Joomla installation and database, even if redSHOP is not currently installed.
- Identify required modules, plugins, payment methods, shipping methods and language packs. A core installation does not necessarily enable these integrations.
- Prepare a staging site with a test customer and test payment configuration.

## Install the component

1. Sign in to the Joomla administrator.
2. Open **System → Install → Extensions** (Joomla 5-style navigation).
3. Select **Upload Package File**.
4. Upload the redSHOP installation ZIP. Do not upload a GitHub source-code ZIP unless it has been packaged as an installable Joomla extension.
5. Wait for Joomla's installation result; do not refresh or navigate away while the installer is processing.
6. Check for warnings, missing dependencies or database migration errors.
7. Open **Components → redSHOP** and verify the administrator dashboard loads.

![Joomla extension installer](img/rs506-install-upload.png)

## Initial shop configuration

The original installation guide described three post-install options: **Configuration Wizard**, **Install Demo Content** and **Cancel**. These were part of the historical interface; check whether the current release still offers them.

### Configuration Wizard

Historically, the wizard walked through five sections including shop identity and address, shipping countries, terms and conditions, user account settings, currency, taxes and discounts. If the current release provides a wizard, use it to establish the basic configuration and then review the full global configuration screen.

See [Configuration Wizard](redshop-configuration-wizard.md).

### Install Demo Content

The original documentation described demo data with **2 manufacturers, 3 categories and 12 products**, including images and descriptions. Those figures apply to the old installer only. **Do not install demo content on a production shop** or an existing catalogue without first checking whether it overwrites or duplicates records.

### Cancel / skip setup

Historically, **Cancel** opened the redSHOP main menu without running the wizard. If the current installer offers a skip option, review configuration manually before enabling checkout.

![Initial setup](img/rs506-install-setup.png)

## Verify installation

1. Open redSHOP global configuration and confirm shop name, address, currency, tax settings and email configuration.
2. Create or verify a test category, product and customer.
3. Confirm a product can be displayed in the storefront and added to the cart.
4. Test checkout with a non-live payment method.
5. Verify the order appears in the administrator, with the expected totals and status.
6. Check order confirmation email, stock changes and shipping selection.
7. Confirm scheduled tasks and integration plugins are enabled only where needed.
8. Check Joomla and PHP logs for errors.

## Installing related modules and plugins

Use the Joomla extension installer for each supported package. Enable the extension in Joomla's plugin or module manager, configure credentials and permissions, and test the relevant workflow. Installing a plugin does not necessarily enable it.

## Troubleshooting

| Symptom | Check |
| --- | --- |
| ZIP rejected | Wrong archive type, incomplete upload, package size limits. |
| Installation times out | PHP execution time, memory, server logs. |
| Database migration fails | Database privileges, table schema, SQL error log. |
| redSHOP menu missing | Component installation status, administrator permissions, extension state. |
| Frontend products missing | Published product/category, Joomla menu, templates and shopper-group visibility. |
| Checkout fails | Payment/shipping plugin, taxes, session handling, HTTPS and error logs. |

The original guide also recommended checking PHP settings, file/folder permissions and host settings. Those remain useful diagnostic categories, but do not weaken file permissions broadly to resolve an installation problem.
