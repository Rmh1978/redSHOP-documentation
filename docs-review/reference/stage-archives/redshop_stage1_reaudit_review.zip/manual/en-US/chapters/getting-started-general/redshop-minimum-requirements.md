# redSHOP Minimum Requirements

redSHOP runs inside Joomla. Its requirements therefore depend on **both** the Joomla release and the particular redSHOP package. Verify both before installing or upgrading.

## Recommended compatibility checks

1. Confirm the Joomla version supported by the redSHOP release you intend to install.
2. Compare PHP, database and web-server requirements against the official compatibility information for that Joomla release.
3. Confirm that all required PHP extensions are enabled and that PHP upload size, execution time and memory limits can accommodate the installation package.
4. Verify the database user has permission to create and alter tables during installation and updates.
5. Confirm Joomla can write to its temporary, cache and log directories.
6. Check that payment, shipping, accounting and other redSHOP plugins support the target PHP and Joomla versions.
7. Test the package on a separate installation before deploying to production.

## PHP

The historical redSHOP manual stated **PHP 5.6+** for redSHOP up to 2.1.4 and **PHP 7.0+** for versions from 2.1.5. **These figures are historical and are not valid minimum requirements for current Joomla 5 or Joomla 6 deployments.** Use the target Joomla version's published PHP requirements and the release-specific redSHOP compatibility statement.

Check `php.ini` settings including `memory_limit`, `upload_max_filesize`, `post_max_size`, and `max_execution_time`. An extension upload can fail even when the PHP version itself is compatible.

## Database

The original guide listed MySQL 5.0.4+. That is obsolete for current Joomla. Use a database version supported by your installed Joomla release and verify compatibility with redSHOP SQL migrations and plugins. Back up the database before any update.

## Web server and URLs

The historical guide listed Apache 2.x and IIS 7. These are not current compatibility guarantees. Joomla can run behind different supported web servers; use the server and rewrite configuration recommended for your Joomla release. For Apache search-engine-friendly URLs, configure `mod_rewrite` and the Joomla rewrite rules where applicable. Test canonical URLs, redirects, checkout callbacks and payment webhooks after changing rewrite rules.

## Environment checklist

| Check | Why it matters |
| --- | --- |
| Joomla and redSHOP release compatibility | Prevents unsupported API calls and installation failures. |
| PHP version and extensions | Required for Joomla, redSHOP and integrations. |
| Database version and privileges | Required for schema creation and migrations. |
| HTTPS and valid certificates | Protects customer sessions and payment redirects. |
| Writable Joomla directories | Needed for extension installation and logs. |
| Scheduled jobs / cron | May be needed by fulfilment and integrations. |
| Mail transport | Needed for order and account notifications. |
| Backup and rollback | Required for safe upgrades. |

## Troubleshooting

**Installer refuses the package:** confirm that the archive is an installable Joomla extension package rather than a repository source archive. Check Joomla's installation log and PHP error log.

**White screen or HTTP 500:** check PHP errors, enabled extensions and version compatibility; restore the backup if the upgrade is incomplete.

**URLs return 404:** review Joomla SEF settings, rewrite configuration and web-server logs.

**Payments or shipping fail after a PHP update:** test the relevant integration plugins separately; the core component may work even when an integration is incompatible.

## Historical note

The previous article covered Joomla 2.5/3, PHP 5.6/7.0, MySQL 5.0.4, Apache 2.x and IIS 7 (last updated 2020). Those values are retained here for historical context only, not as modern deployment advice.
