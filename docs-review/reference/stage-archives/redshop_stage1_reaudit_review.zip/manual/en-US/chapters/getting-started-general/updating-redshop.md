# Updating redSHOP

Updates may contain bug fixes, security fixes, database migrations and changes to integrations. A successful installation message is **not** proof that checkout, payments, shipping and accounting still work.

## Before updating

1. Identify the installed redSHOP, Joomla, PHP and database versions.
2. Read the release notes and migration instructions for the target redSHOP package.
3. Confirm that payment, shipping, template overrides, scheduled jobs and other integrations support the target release.
4. Make a **restorable backup of files and database**; test the restore procedure.
5. Clone the site to a separate staging environment with its own database.
6. Disable or redirect outbound customer email and live payment capture in staging.
7. Record the current checkout, order, customer and product workflows so you can compare after updating.

## Update on staging

1. Open **System → Update → Extensions** and check for an available redSHOP update if the release provides a configured update site.
2. If the update is distributed as a package, open **System → Install → Extensions** and upload the correct installable ZIP.
3. Wait for the installer and any database migrations to complete.
4. Inspect Joomla extension/database maintenance information and relevant logs for errors.
5. Clear caches only as needed and reload the administrator and storefront.
6. Verify the installed redSHOP version.
7. Run the post-update checks below.

![Joomla extension update](img/rs506-update-extensions.png)

**Do not assume every redSHOP fork or release supports Joomla's automatic update channel.** The update method and package source must match the release being deployed.

## Post-update acceptance tests

| Area | Test |
| --- | --- |
| Catalogue | Products, categories, media and prices remain intact. |
| Customer accounts | Login, registration and shopper-group pricing work. |
| Cart and checkout | Totals, tax, shipping and discount calculations are correct. |
| Orders | Existing orders open; a new test order can be created. |
| Payments | Test/sandbox transaction, callback and status updates work. |
| Shipping | Delivery methods and pickup-point selection work where installed. |
| Emails | Order and account notifications use correct templates. |
| Integrations | Accounting, fulfilment, scheduled jobs and APIs work. |
| URLs | Product, category and checkout links resolve correctly. |
| Logs | No new PHP, Joomla or database errors. |

Only after staging passes should the production update be scheduled. Back up production again immediately before deployment, then repeat critical smoke tests.

## Rollback

If an update fails, stop taking new orders while investigating. Restore **both** application files and the matching database snapshot; restoring only the code can leave an incompatible migrated schema. Reconcile any orders or payments received after the backup before resuming sales.

## Historical migration guidance

The original manual documented updating redSHOP 1.5.x and a Joomla 2.5 → 3 migration through redSHOP 1.3.3.1 → 1.5, including an **Optimize Tables** step. Those instructions were written in 2015 and must **not** be used as a direct upgrade procedure for Joomla 5 or Joomla 6. A legacy migration requires a dedicated, version-specific plan and testing of intermediate steps.

The historical guide linked to the original redCOMPONENT releases and suggested a hosting backup or Akeeba Backup. A backup tool remains useful, but ensure the resulting backup is complete and restorable.

## Troubleshooting

**Installer says success but frontend breaks:** inspect template overrides, plugins, PHP logs and routing.

**Database errors:** inspect migration output and compare schema with the expected version; do not manually rerun arbitrary SQL on production.

**Customer notifications are sent from staging:** disable outbound mail or route it to a test mailbox before testing again.

**Payment status stops updating:** verify webhook URLs, credentials, payment plugin compatibility and error logs.
