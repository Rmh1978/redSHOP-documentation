# Stage 1 — technical follow-ups

- [ ] Verify actual current redSHOP 5.0.6 supported Joomla/PHP/database versions against release metadata and tests.
- [ ] Verify Joomla 6 support; do not claim it without test evidence.
- [ ] Inspect package manifest, installer scripts, database migrations and post-install screen.
- [ ] Confirm whether Configuration Wizard, Install Demo Content and Cancel still appear.
- [ ] Confirm availability of Joomla extension update channel and required download key.
- [ ] Test clean install and upgrade on isolated redshop6 clone.
- [ ] Test rollback from a real database migration.
- [ ] Check internal links, images and cross-references.
- [ ] Review original pages for historical details not yet represented.
