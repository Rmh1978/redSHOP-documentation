# Stage 1 review

Rewritten three original pages: Minimum Requirements (original 1,142 characters), Installing redSHOP (3,681), Updating redSHOP (2,977). Preserved historical requirements, wizard/demo content details, post-install options and legacy upgrade instructions with explicit obsolete-version warnings. Added current Joomla 5-style navigation, operational checklists and migration/rollback guidance.

**Limitations:** Current redSHOP 5.0.6 installer manifest and runtime behaviour not yet checked against source; no screenshots captured; no live test. This is a documentation draft, not a validated compatibility matrix.
