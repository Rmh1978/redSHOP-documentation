# redSHOP documentation — master outstanding issues and errors

This is the first collated tracker generated from available earlier review files. **OPEN** means unverified, not a confirmed software defect. Items may overlap. It is not a GitHub issue tracker and has not been committed.

## Stage 11 — Shipping

- [ ] SHIP-11-01 Compare every original Shipping Methods field and action against current editor
- [ ] SHIP-11-02 Verify rate model persistence and rule precedence
- [ ] SHIP-11-03 Test weight, volume, dimension and postal-code boundaries
- [ ] SHIP-11-04 Test product/country and shopper-group rate scenarios
- [ ] SHIP-11-05 Check shipping VAT and mixed tax rates
- [ ] SHIP-11-06 Verify shipping box form fields and matching algorithm
- [ ] SHIP-11-07 Verify wrapping assignment, frontend display and price calculation
- [ ] SHIP-11-08 Audit shipping-rate jQuery and Joomla.submitbutton for Joomla 6
- [ ] SHIP-11-09 Verify active carrier plugins and provider API compatibility
- [ ] SHIP-11-10 Capture and verify shipping screenshots and internal links

## Existing trackers (verbatim, for reconciliation)

Imported 21 existing tracker documents. Repeated tasks have not yet been deduplicated; original stage labels are retained.

### redshop004_phase1_3_revised / FOLLOW-UP-TRACKER.md

# redSHOP documentation – follow-up tracker

This is an **internal working list**, not part of the published documentation. Keep it updated as code review, UI testing and screenshots are completed.

**Scope:** redSHOP 5.0.6, documentation phases 1–5. **Status:** Open.  
**Conventions:** `OPEN` = needs work; `IN PROGRESS` = being reviewed; `DONE` = checked and completed.  

| ID | Article | Follow-up | Status |
|---|---|---|---|
| D045-01 | cart.md | Confirm cart timeout unit and actual expiration behavior | OPEN |
| D045-02 | cart.md | Verify minimum order total calculation with VAT, discounts and shipping | OPEN |
| D045-03 | cart.md | Document checkout variants, AJAX cart and payment/shipping interaction with examples | OPEN |
| D045-04 | orders.md | Verify order email timing for successful, failed and delayed payments | OPEN |
| D045-05 | orders.md | Confirm order/invoice numbering and free-order invoice behavior | OPEN |
| D045-06 | feature-settings.md | Verify where inline editing works in administrator UI | OPEN |
| D045-07 | feature-settings.md | Test review submission and wishlist behavior for guests and registered customers | OPEN |
| D045-08 | feature-settings.md | Verify stock deduction, reservation and notification scenarios | OPEN |
| D045-09 | seo.md | Verify placeholder syntax and available tokens in each metadata field | OPEN |
| D045-10 | seo.md | Test Joomla SEF, category paths, multilingual routes and redirects | OPEN |
| D045-11 | integration.md | Separate supported integrations from legacy UI sections; verify provider API compatibility | OPEN |
| D045-12 | integration.md | Write dedicated setup guides for Billy, Flatpay, Bambora, PostNord and Relatel where applicable | OPEN |
| D045-13 | dashboard.md | Confirm current menu visibility list and behavior under restricted Joomla ACL | OPEN |
| D045-14 | all six | Capture screenshots from redSHOP 5.0.6 test site; replace image placeholders | OPEN |
| D045-15 | all six | Verify menu labels and frontend behavior on Joomla 5.4 | OPEN |
| D045-16 | all six | Joomla 6 compatibility testing before claiming support | OPEN |

## Phases 1–3

| ID | Article | Follow-up | Status |
|---|---|---|---|
| D013-01 | requirements | Confirm supported Joomla/PHP/database matrix and Joomla 6 upgrade test | OPEN |
| D013-02 | installation | Verify clean installation, bundled extensions and installer result screens | OPEN |
| D013-03 | updating | Verify update server, download-key UI, manual ZIP update and migration from legacy releases | OPEN |
| D013-04 | wizard | Confirm wizard entry point, step navigation, field labels and save behavior | OPEN |
| D013-05 | wizard | Test all registration methods, terms and invoice-email settings | OPEN |
| D013-06 | general | Verify all configuration tabs, general settings, upload-size units and image resizing | OPEN |
| D013-07 | general | Test statistics, product reservation and shipping-address settings | OPEN |
| D013-08 | user | Test registration methods, verification emails, portal restrictions and shopper group assignments | OPEN |
| D013-09 | products | Verify download storage access, limits, product templates and catalogue features | OPEN |
| D013-10 | price | Verify VAT calculations, tax-exempt pricing, coupon stacking and discount emails | OPEN |
| D013-11 | all phases 1–3 | Capture and review screenshots; verify labels on Joomla 5.4 | OPEN |
| D013-12 | all phases 1–3 | Check rendered documentation links and image paths in site generator | OPEN |

## How to maintain

Update the status and add a short note/date as items are addressed. When a feature is verified, expand the public article and replace any “will be added in a future update” text with the final instructions. Do not publish this tracker under the manual chapters directory.


### redshop004_phase4_5_revised / FOLLOW-UP-TRACKER.md

# redSHOP documentation – follow-up tracker

This is an **internal working list**, not part of the published documentation. Keep it updated as code review, UI testing and screenshots are completed.

**Scope:** redSHOP 5.0.6, documentation phases 4–5. **Status:** Open.  
**Conventions:** `OPEN` = needs work; `IN PROGRESS` = being reviewed; `DONE` = checked and completed.  

| ID | Article | Follow-up | Status |
|---|---|---|---|
| D045-01 | cart.md | Confirm cart timeout unit and actual expiration behavior | OPEN |
| D045-02 | cart.md | Verify minimum order total calculation with VAT, discounts and shipping | OPEN |
| D045-03 | cart.md | Document checkout variants, AJAX cart and payment/shipping interaction with examples | OPEN |
| D045-04 | orders.md | Verify order email timing for successful, failed and delayed payments | OPEN |
| D045-05 | orders.md | Confirm order/invoice numbering and free-order invoice behavior | OPEN |
| D045-06 | feature-settings.md | Verify where inline editing works in administrator UI | OPEN |
| D045-07 | feature-settings.md | Test review submission and wishlist behavior for guests and registered customers | OPEN |
| D045-08 | feature-settings.md | Verify stock deduction, reservation and notification scenarios | OPEN |
| D045-09 | seo.md | Verify placeholder syntax and available tokens in each metadata field | OPEN |
| D045-10 | seo.md | Test Joomla SEF, category paths, multilingual routes and redirects | OPEN |
| D045-11 | integration.md | Separate supported integrations from legacy UI sections; verify provider API compatibility | OPEN |
| D045-12 | integration.md | Write dedicated setup guides for Billy, Flatpay, Bambora, PostNord and Relatel where applicable | OPEN |
| D045-13 | dashboard.md | Confirm current menu visibility list and behavior under restricted Joomla ACL | OPEN |
| D045-14 | all six | Capture screenshots from redSHOP 5.0.6 test site; replace image placeholders | OPEN |
| D045-15 | all six | Verify menu labels and frontend behavior on Joomla 5.4 | OPEN |
| D045-16 | all six | Joomla 6 compatibility testing before claiming support | OPEN |

## How to maintain

Update the status and add a short note/date as items are addressed. When a feature is verified, expand the public article and replace any “will be added in a future update” text with the final instructions. Do not publish this tracker under the manual chapters directory.


### redshop_004_phase6_8 / FOLLOW-UP-TRACKER-ADDITIONS.md

# Documentation follow-up tracker — phases 6–8

Internal editorial checklist. Do not publish this file as an end-user article.

| ID | Article | Follow-up | Status |
|---|---|---|---|
| DOC-029 | `global-configuration/categories.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-030 | `global-configuration/manufacturers.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-031 | `global-configuration/newsletter.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-032 | `global-configuration/about.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-033 | `global-configuration/start-here.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-034 | `categories/overview-category.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-035 | `categories/redshop-categories.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-036 | `product-management/overview-product-management.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-037 | `product-management/products-redshop.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |


### redshop_phase6_categories / FOLLOW-UP-TRACKER-ADDITIONS.md

# Internal follow-up additions — Phase 6, Categories

| ID | Status | Topic | Action |
| --- | --- | --- | --- |
| P6-CAT-01 | OPEN | Previous/Next navigation | Verify whether all legacy controls still appear in redSHOP 5.0.6 and whether the active frontend templates consume them. |
| P6-CAT-02 | OPEN | Image configuration | Locate and verify lightbox, watermark, default image and out-of-stock image settings in the current configuration UI. |
| P6-CAT-03 | OPEN | Category ordering | Check exact ordering choices and whether newest means creation or publishing date. |
| P6-CAT-04 | OPEN | Pagination overrides | Confirm which Joomla menu/category settings override the global category count. |
| P6-CAT-05 | OPEN | Discontinued products | Confirm storefront template handling of the discontinued-product message. |
| P6-CAT-06 | OPEN | Text shortening | Test suffix behavior, zero/empty limits and multibyte characters in storefront templates. |
| P6-CAT-07 | OPEN | Template precedence | Verify category-specific template override precedence. |
| P6-CAT-08 | OPEN | Screenshots | Capture and check seven images; remove any legacy-only references that no longer apply. |


### redshop_phase6_final / FOLLOW-UP-TRACKER-ADDITIONS.md

# Internal follow-up — Phase 6, About and Start Here

| ID | Status | Verification task |
| --- | --- | --- |
| DOC-6-A01 | OPEN | Verify About tab's four panels and visible labels on `/tests/redshop6`. |
| DOC-6-A02 | OPEN | Confirm installed/published indicators accurately reflect Joomla extension state, including disabled plugins. |
| DOC-6-A03 | OPEN | Verify server-information values on the running site; redact sensitive details in screenshots. |
| DOC-6-A04 | OPEN | Check whether empty module/plugin lists hide their entire tables and whether docs need a note. |
| DOC-6-S01 | OPEN | Verify exact Configuration entry point, tab names and ordering on redSHOP 5.0.6. |
| DOC-6-S02 | OPEN | Verify relative Markdown links render correctly in the published documentation site. |
| DOC-6-S03 | OPEN | Capture seven screenshots and check mobile readability. |
| DOC-6-S04 | OPEN | Confirm global-vs-record-specific override examples for each related section during later article reviews. |


### redshop_phase6_manufacturers / FOLLOW-UP-TRACKER-ADDITIONS.md

# Internal follow-up — Manufacturers

| ID | Status | Task |
| --- | --- | --- |
| DOC-6-M01 | OPEN | Verify actual dropdown choices for manufacturer ordering and manufacturer product ordering on redSHOP 5.0.6. |
| DOC-6-M02 | OPEN | Test manufacturer-specific template override precedence. |
| DOC-6-M03 | OPEN | Test manufacturer and supplier email delivery using safe test accounts; confirm event/trigger and templates. |
| DOC-6-M04 | OPEN | Verify title truncation and suffix behaviour in active frontend templates. |
| DOC-6-M05 | OPEN | Confirm mapping of all three manufacturer product thumbnail dimension pairs to frontend layouts and image cache behaviour. |
| DOC-6-M06 | OPEN | Verify watermark application and required watermark image configuration. |
| DOC-6-M07 | OPEN | Capture and review three screenshots from `/tests/redshop6`. |


### redshop_phase6_newsletter / FOLLOW-UP-TRACKER-ADDITIONS.md

# Internal follow-up — Newsletter

| ID | Status | Task |
| --- | --- | --- |
| DOC-6-N01 | OPEN | Trace newsletter test button submission (`task=apply`) through controller/model to verify whether and when a test message is actually sent. |
| DOC-6-N02 | OPEN | Test confirmation workflow, email content, subscription state and confirmation links on redSHOP 5.0.6. |
| DOC-6-N03 | OPEN | Verify batch size and pause settings are used by the actual newsletter sending process, including error and timeout handling. |
| DOC-6-N04 | OPEN | Check default newsletter selection, template output, sender and reply-to headers. |
| DOC-6-N05 | OPEN | Confirm visibility of dependent settings when newsletter is disabled and enabled. |
| DOC-6-N06 | OPEN | Capture three screenshots from `/tests/redshop6` and check labels. |
| DOC-6-N07 | OPEN | Confirm data protection and unsubscribe behaviour in subscriber management; document separately in communication chapter. |


### redshop_phase7_categories / FOLLOW-UP-TRACKER-ADDITIONS.md

# Internal follow-up — Stage 7

Status: Source-reviewed draft; UI and end-to-end testing pending.

| ID | Status | Action |
| --- | --- | --- |
| DOC-7-01 | OPEN | Compare all category listing columns, toolbar actions and check-in behaviour with redSHOP 5.0.6. |
| DOC-7-02 | OPEN | Verify parent/unpublished-child behaviour and category deletion/copy handling. |
| DOC-7-03 | OPEN | Test category editor fields, per-category template overrides and allowed-template selector tag. |
| DOC-7-04 | OPEN | Inspect actual category SEO XML fieldset and generated frontend metadata. |
| DOC-7-05 | OPEN | Test new Product Filters tab, supported fields, frontend template integration and attribute selection. |
| DOC-7-06 | OPEN | Confirm whether historical Custom Fields and Accessories tabs remain, have moved or were removed. Do not describe them as confirmed current UI. |
| DOC-7-07 | OPEN | Confirm category-level accessory pricing precedence against product-specific accessory rules. |
| DOC-7-08 | OPEN | Test shopper-group category visibility and administrative access controls. |
| DOC-7-09 | OPEN | Verify mass discounts, product-price discounts and shopper-group precedence on test orders. |
| DOC-7-10 | OPEN | Test category wrapping and shipping-rate restrictions, including mixed-category carts. |
| DOC-7-11 | OPEN | Verify current CSV/XML import/export workflow, formats and category parent mapping. |
| DOC-7-12 | OPEN | Confirm available Joomla category menu item types and labels. |
| DOC-7-13 | OPEN | Verify historic category template tags and frontpage/product-category layouts. |
| DOC-7-14 | OPEN | Verify media manager category assignments and image cache behaviour. |
| DOC-7-15 | OPEN | Verify current text-library integration and custom-field output. |
| DOC-7-16 | OPEN | Capture 16 current screenshots and check docs relative paths. |
| DOC-7-17 | OPEN | Review original tutorial video links for accessibility and version relevance before considering reuse. |


### redshop_stage10_orders / FOLLOW-UP-TRACKER-ADDITIONS.md

# Stage 10 — open checks

- [ ] Confirm current Orders list columns and toolbar actions.
- [ ] Test search by order ID, order number, name, email and phone.
- [ ] Test date, order status and payment status filters.
- [ ] Test bulk status changes and customer notification flag.
- [ ] Verify PDF print and CSV/full CSV/GLS/GLS Business exports.
- [ ] Verify deletion side effects and retention requirements.
- [ ] Test manual order for existing customer.
- [ ] Test new-customer account creation and password security.
- [ ] Test dynamic product rows, attributes, discounts and VAT.
- [ ] Confirm Save + Pay / Save without Email / Save & Close email semantics.
- [ ] Confirm default status count and uniqueness of status codes.
- [ ] Test status changes from list, editor and dashboard.
- [ ] Verify notification, shipping and payment plugin side effects.
- [ ] Verify quotation Send email behaviour.
- [ ] Test frontend Quote menu and quotation-to-order conversion.
- [ ] Verify frontend Orders menu, Reorder warning and one-step checkout.
- [ ] Security-test Order Tracker authorization.
- [ ] Locate current Product Order Search route and filters.
- [ ] Check order-list jQuery/custom JS for Joomla 6 compatibility.
- [ ] Perform field-by-field original-content audit (especially Add Order).
- [ ] Capture all screenshot placeholders and verify rendered links.
- [ ] Review historical video links before reuse.


### redshop_stage1_reaudit / FOLLOW-UP-TRACKER.md

# Stage 1 — technical follow-ups

- [ ] Verify actual current redSHOP 5.0.6 supported Joomla/PHP/database versions against release metadata and tests.
- [ ] Verify Joomla 6 support; do not claim it without test evidence.
- [ ] Inspect package manifest, installer scripts, database migrations and post-install screen.
- [ ] Confirm whether Configuration Wizard, Install Demo Content and Cancel still appear.
- [ ] Confirm availability of Joomla extension update channel and required download key.
- [ ] Test clean install and upgrade on isolated redshop6 clone.
- [ ] Test rollback from a real database migration.
- [ ] Check internal links, images and cross-references.
- [ ] Review original pages for historical details not yet represented.


### redshop_stage8_consolidated / CONSOLIDATED-FOLLOW-UP-TRACKER.md

# Stage 8 — consolidated follow-up tracker

## Product Management

# Internal follow-up — Stage 8

This is a source-reviewed documentation draft, not a live-tested certification.

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-01 | OPEN | Compare current product list columns, toolbar and bulk category actions with the historical manual. |
| DOC-8-02 | OPEN | Verify current Product Price Management workflow and shopper-group quantity rules. |
| DOC-8-03 | OPEN | Check all Product Information fields, validation, date/time handling and tax labels in the test UI. |
| DOC-8-04 | OPEN | Test downloadable-product access, limits and file storage; verify protection against direct file access. |
| DOC-8-05 | OPEN | Test subscriptions, renewals and serial-number delivery where configured. |
| DOC-8-06 | OPEN | Confirm product custom-field display and available editor tabs. |
| DOC-8-07 | OPEN | Test additional image publishing and media gallery output. |
| DOC-8-08 | OPEN | Test attribute-set copy; source contains `task==product.ajaxDisplayAttributeSet` and may require a fix. |
| DOC-8-09 | OPEN | Test attribute/subproperty price calculations and required selection. |
| DOC-8-10 | OPEN | Verify product vs category accessory precedence and related-product rendering. |
| DOC-8-11 | OPEN | Confirm redPRODUCTFINDER integration availability and UI. |
| DOC-8-12 | OPEN | Verify product SEO fieldset, SEF URLs and generated metadata. |
| DOC-8-13 | OPEN | Review Discount Calculator units, dimension handling and discount precedence. |
| DOC-8-14 | OPEN | Verify accounting integration field mapping. |
| DOC-8-15 | OPEN | Test individual payment-method restrictions, including mixed-product carts. |
| DOC-8-16 | OPEN | Verify mass discount and product price discount fields, ordering and shopper-group rules. |
| DOC-8-17 | OPEN | Capture 15 screenshots and verify relative links against actual docs tree. |
| DOC-8-18 | OPEN | Audit original 2019 product article field-by-field to ensure no still-relevant advanced fields were omitted from the rewritten draft. |


## Manufacturers

# Internal follow-up: Product Management — Manufacturers

| ID | Status | Task |
| --- | --- | --- |
| DOC-8-M01 | OPEN | Confirm current manufacturer list toolbar, filters, columns and copy/delete/check-in behaviour. |
| DOC-8-M02 | OPEN | Verify manufacturer form fields, required template selection and default products-per-page on test site. |
| DOC-8-M03 | OPEN | Confirm manufacturer image upload and alt text behaviour. |
| DOC-8-M04 | OPEN | Verify SEO values in generated frontend metadata and routing. |
| DOC-8-M05 | OPEN | Test product-to-manufacturer assignment and listing pagination. |
| DOC-8-M06 | OPEN | Test manufacturer mass discounts and priority against product discounts. |
| DOC-8-M07 | OPEN | Identify supported manufacturer template tags and verify product-page manufacturer-name tag. |
| DOC-8-M08 | OPEN | Confirm available Joomla manufacturer menu item types and labels. |
| DOC-8-M09 | OPEN | Confirm manufacturer email notification trigger and delivery. |
| DOC-8-M10 | OPEN | Capture seven screenshots. |


## Price Management

# Internal follow-up — Price Management

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-P01 | OPEN | Verify current Product Price Management screen and search controls. |
| DOC-8-P02 | OPEN | Confirm historical plus-icon modal exists and is compatible with Joomla 5. |
| DOC-8-P03 | OPEN | Test quick-price save task `saveprice` versus `productprice.saveprice`. |
| DOC-8-P04 | OPEN | Review `component/admin/tmpl/price/edit.php`: JavaScript validates `form.productprice`, but field is `product_price`; `form.discount_price` check may be reversed. |
| DOC-8-P05 | OPEN | Check price editor quantity range validation, discount price constraints and decimal input. |
| DOC-8-P06 | OPEN | Verify exact New/Edit/Delete toolbar actions on price-rule listing. |
| DOC-8-P07 | OPEN | Test overlapping shopper-group quantity ranges and rule precedence. |
| DOC-8-P08 | OPEN | Test discount date handling, timezone and empty date semantics. |
| DOC-8-P09 | OPEN | Verify storefront unit prices, subtotal, tax and checkout for quantity boundary cases. |
| DOC-8-P10 | OPEN | Capture seven screenshots and verify article links. |
| DOC-8-P11 | OPEN | Review historical tutorial video URLs for continued availability before adding links. |


## Supplier Products

# Internal follow-up — Supplier Products

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-S01 | OPEN | Verify shared admin list layout columns and toolbar actions in Joomla 5 test installation. |
| DOC-8-S02 | OPEN | Confirm Save / Save & Close / Save & New / Close in current supplier editor. |
| DOC-8-S03 | OPEN | Locate current product supplier field and verify supplier association storage. |
| DOC-8-S04 | OPEN | Verify `{supplier_name}` template tag is still processed by current product template engine. |
| DOC-8-S05 | OPEN | Test unpublished supplier behaviour on product page. |
| DOC-8-S06 | OPEN | Test copy operation and generated unique supplier name. |
| DOC-8-S07 | OPEN | Verify supplier deletion impact on product associations and database constraints. |
| DOC-8-S08 | OPEN | Confirm check-in works after abandoned editing session. |
| DOC-8-S09 | OPEN | Capture 11 screenshots and check article links. |
| DOC-8-S10 | OPEN | Review historical tutorial videos before linking publicly. |


## Media

# Internal follow-up — Media Management

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-MED01 | OPEN | Verify exact Media navigation labels and available list toolbar actions. |
| DOC-8-MED02 | OPEN | Inspect current `medium` editor fields and supported media types; verify video and YouTube support. |
| DOC-8-MED03 | OPEN | Test media type and media section filtering, including item-specific popup. |
| DOC-8-MED04 | OPEN | Test new media upload and association with a product. |
| DOC-8-MED05 | OPEN | Test category image media record creation and association. |
| DOC-8-MED06 | OPEN | Test main product image and additional image workflow, including default media. |
| DOC-8-MED07 | OPEN | Test manufacturer media association and deletion restrictions. |
| DOC-8-MED08 | OPEN | Test reusing one file across multiple product records without overwriting an existing association. |
| DOC-8-MED09 | OPEN | Verify property and subproperty image selection and storefront behaviour. |
| DOC-8-MED10 | OPEN | Review `MediaModel::delete` and `MediumTable::doDelete` for deletion side effects, shared-file safety, and transaction consistency. |
| DOC-8-MED11 | OPEN | Review upload validation, MIME/extension checks, and file access permissions. |
| DOC-8-MED12 | OPEN | Verify product download root isolation from public media paths. |
| DOC-8-MED13 | OPEN | Capture 10 screenshots and validate all relative documentation links. |
| DOC-8-MED14 | OPEN | Review original tutorial videos for relevance and availability. |


### redshop_stage8_manufacturers / FOLLOW-UP-TRACKER-ADDITIONS.md

# Internal follow-up: Product Management — Manufacturers

| ID | Status | Task |
| --- | --- | --- |
| DOC-8-M01 | OPEN | Confirm current manufacturer list toolbar, filters, columns and copy/delete/check-in behaviour. |
| DOC-8-M02 | OPEN | Verify manufacturer form fields, required template selection and default products-per-page on test site. |
| DOC-8-M03 | OPEN | Confirm manufacturer image upload and alt text behaviour. |
| DOC-8-M04 | OPEN | Verify SEO values in generated frontend metadata and routing. |
| DOC-8-M05 | OPEN | Test product-to-manufacturer assignment and listing pagination. |
| DOC-8-M06 | OPEN | Test manufacturer mass discounts and priority against product discounts. |
| DOC-8-M07 | OPEN | Identify supported manufacturer template tags and verify product-page manufacturer-name tag. |
| DOC-8-M08 | OPEN | Confirm available Joomla manufacturer menu item types and labels. |
| DOC-8-M09 | OPEN | Confirm manufacturer email notification trigger and delivery. |
| DOC-8-M10 | OPEN | Capture seven screenshots. |


### redshop_stage8_media / FOLLOW-UP-TRACKER-ADDITIONS.md

# Internal follow-up — Media Management

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-MED01 | OPEN | Verify exact Media navigation labels and available list toolbar actions. |
| DOC-8-MED02 | OPEN | Inspect current `medium` editor fields and supported media types; verify video and YouTube support. |
| DOC-8-MED03 | OPEN | Test media type and media section filtering, including item-specific popup. |
| DOC-8-MED04 | OPEN | Test new media upload and association with a product. |
| DOC-8-MED05 | OPEN | Test category image media record creation and association. |
| DOC-8-MED06 | OPEN | Test main product image and additional image workflow, including default media. |
| DOC-8-MED07 | OPEN | Test manufacturer media association and deletion restrictions. |
| DOC-8-MED08 | OPEN | Test reusing one file across multiple product records without overwriting an existing association. |
| DOC-8-MED09 | OPEN | Verify property and subproperty image selection and storefront behaviour. |
| DOC-8-MED10 | OPEN | Review `MediaModel::delete` and `MediumTable::doDelete` for deletion side effects, shared-file safety, and transaction consistency. |
| DOC-8-MED11 | OPEN | Review upload validation, MIME/extension checks, and file access permissions. |
| DOC-8-MED12 | OPEN | Verify product download root isolation from public media paths. |
| DOC-8-MED13 | OPEN | Capture 10 screenshots and validate all relative documentation links. |
| DOC-8-MED14 | OPEN | Review original tutorial videos for relevance and availability. |


### redshop_stage8_price_management / FOLLOW-UP-TRACKER-ADDITIONS.md

# Internal follow-up — Price Management

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-P01 | OPEN | Verify current Product Price Management screen and search controls. |
| DOC-8-P02 | OPEN | Confirm historical plus-icon modal exists and is compatible with Joomla 5. |
| DOC-8-P03 | OPEN | Test quick-price save task `saveprice` versus `productprice.saveprice`. |
| DOC-8-P04 | OPEN | Review `component/admin/tmpl/price/edit.php`: JavaScript validates `form.productprice`, but field is `product_price`; `form.discount_price` check may be reversed. |
| DOC-8-P05 | OPEN | Check price editor quantity range validation, discount price constraints and decimal input. |
| DOC-8-P06 | OPEN | Verify exact New/Edit/Delete toolbar actions on price-rule listing. |
| DOC-8-P07 | OPEN | Test overlapping shopper-group quantity ranges and rule precedence. |
| DOC-8-P08 | OPEN | Test discount date handling, timezone and empty date semantics. |
| DOC-8-P09 | OPEN | Verify storefront unit prices, subtotal, tax and checkout for quantity boundary cases. |
| DOC-8-P10 | OPEN | Capture seven screenshots and verify article links. |
| DOC-8-P11 | OPEN | Review historical tutorial video URLs for continued availability before adding links. |


### redshop_stage8_product_management / FOLLOW-UP-TRACKER-ADDITIONS.md

# Internal follow-up — Stage 8

This is a source-reviewed documentation draft, not a live-tested certification.

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-01 | OPEN | Compare current product list columns, toolbar and bulk category actions with the historical manual. |
| DOC-8-02 | OPEN | Verify current Product Price Management workflow and shopper-group quantity rules. |
| DOC-8-03 | OPEN | Check all Product Information fields, validation, date/time handling and tax labels in the test UI. |
| DOC-8-04 | OPEN | Test downloadable-product access, limits and file storage; verify protection against direct file access. |
| DOC-8-05 | OPEN | Test subscriptions, renewals and serial-number delivery where configured. |
| DOC-8-06 | OPEN | Confirm product custom-field display and available editor tabs. |
| DOC-8-07 | OPEN | Test additional image publishing and media gallery output. |
| DOC-8-08 | OPEN | Test attribute-set copy; source contains `task==product.ajaxDisplayAttributeSet` and may require a fix. |
| DOC-8-09 | OPEN | Test attribute/subproperty price calculations and required selection. |
| DOC-8-10 | OPEN | Verify product vs category accessory precedence and related-product rendering. |
| DOC-8-11 | OPEN | Confirm redPRODUCTFINDER integration availability and UI. |
| DOC-8-12 | OPEN | Verify product SEO fieldset, SEF URLs and generated metadata. |
| DOC-8-13 | OPEN | Review Discount Calculator units, dimension handling and discount precedence. |
| DOC-8-14 | OPEN | Verify accounting integration field mapping. |
| DOC-8-15 | OPEN | Test individual payment-method restrictions, including mixed-product carts. |
| DOC-8-16 | OPEN | Verify mass discount and product price discount fields, ordering and shopper-group rules. |
| DOC-8-17 | OPEN | Capture 15 screenshots and verify relative links against actual docs tree. |
| DOC-8-18 | OPEN | Audit original 2019 product article field-by-field to ensure no still-relevant advanced fields were omitted from the rewritten draft. |


### redshop_stage8_supplier_products / FOLLOW-UP-TRACKER-ADDITIONS.md

# Internal follow-up — Supplier Products

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-S01 | OPEN | Verify shared admin list layout columns and toolbar actions in Joomla 5 test installation. |
| DOC-8-S02 | OPEN | Confirm Save / Save & Close / Save & New / Close in current supplier editor. |
| DOC-8-S03 | OPEN | Locate current product supplier field and verify supplier association storage. |
| DOC-8-S04 | OPEN | Verify `{supplier_name}` template tag is still processed by current product template engine. |
| DOC-8-S05 | OPEN | Test unpublished supplier behaviour on product page. |
| DOC-8-S06 | OPEN | Test copy operation and generated unique supplier name. |
| DOC-8-S07 | OPEN | Verify supplier deletion impact on product associations and database constraints. |
| DOC-8-S08 | OPEN | Confirm check-in works after abandoned editing session. |
| DOC-8-S09 | OPEN | Capture 11 screenshots and check article links. |
| DOC-8-S10 | OPEN | Review historical tutorial videos before linking publicly. |


### redshop_stage9_stockroom / FOLLOW-UP-TRACKER-ADDITIONS.md

# Stage 9 follow-up

- [ ] Verify stockroom list toolbar and actions on redshop6.
- [ ] Verify minimum-stock threshold behaviour.
- [ ] Verify stockroom delivery-time output on frontend.
- [ ] Test product, property and subproperty inventory save.
- [ ] Test preorder quantities and reset without affecting real orders.
- [ ] Confirm print action and whether export is supported.
- [ ] Confirm custom Stock Option choices and comparison semantics.
- [ ] Verify stock image template tags and frontend output.
- [ ] Confirm deletion behaviour for stockroom and stock image records.
- [ ] Capture eight screenshots.
- [ ] Perform field-by-field original-content audit and verify rendered links.
- [ ] Review Joomla 6 compatibility of stockroom admin JavaScript.

## Additional original-content checks

- [ ] Verify the historical `redSHOP Stockroom Status notice for admin` plugin and whether minimum-stock notifications are still supported.
- [ ] Verify Stockroom List Inventory, Copy, Publish, Unpublish and search controls.
- [ ] Verify historical Inventory **Export Data** CSV action and its columns; current listing explicitly shows print.
- [ ] Verify stockroom totals shown in the inventory listing.
- [ ] Confirm `{product_stock_amount_image}` is supported by current template parser and test with in-stock/out-of-stock rules.
- [ ] Check stock-image listing search and filtering against current UI.
- [ ] Review original Fleeq tutorial links before reuse.


### stage2 / FOLLOW-UP-TRACKER.md

# Technical and publication follow-ups — stage 2

- [ ] `redshop-configuration-wizard.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `redshop-main-menu.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `redshop-navigation-panel.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots


### stage3 / FOLLOW-UP-TRACKER.md

# Technical and publication follow-ups — stage 3

- [ ] `overview-global-configuration.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `general.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `user.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `products.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `price.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots


### stage4 / FOLLOW-UP-TRACKER.md

# Technical and publication follow-ups — stage 4

- [ ] `cart.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `orders.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `feature-settings.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots


### stage5 / FOLLOW-UP-TRACKER.md

# Technical and publication follow-ups — stage 5

- [ ] `seo.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `integration.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `dashboard.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots

