# Shipping Boxes

Shipping boxes define named package dimensions and priorities. They are separate from shipping methods and rates. The original manual documents list and edit screens and the create-box workflow; this revision retains that coverage.

## Shipping Boxes list — field reference

| Field | Meaning / verification |
|---|---|
| Name | Identifies the package; use a meaningful internal name. |
| Length | Box length in the configured length unit. |
| Width | Box width in the configured length unit. |
| Height | Box height in the configured length unit. |
| Priority | Ordering/selection priority; verify current calculation semantics. |
| Published | Whether the box is available. |
| ID | Internal identifier. |

## Actions

The historical list toolbar includes **New**, **Delete**, **Publish**, **Unpublish**, and **Check-in**. The historical editor includes **Save**, **Save & Close**, **Save & New**, and **Cancel**. Confirm current toolbar labels and permissions in the test administrator.

## Create a shipping box

1. Open redSHOP administration → Shipping → Shipping Boxes.
2. Select **New** and enter a descriptive name such as `Small parcel 30 × 20 × 10 cm`.
3. Enter length, width and height in the same unit configured for product dimensions. For example, enter `30`, `20`, `10` only if the unit is centimetres.
4. Set a priority, publish the box, and save.
5. Reopen it to confirm saved dimensions and test a product/order that should fit the box.

## Important tests

- Compare a product's packed dimensions to the box dimensions; do not assume that simple volume alone proves physical fit.
- Check the effect of priority when two boxes match.
- Verify whether package size affects the chosen shipping rate or label service.
- Test unpublished boxes and mixed-size carts.

## Source references

- `component/admin/src/Model/ShippingBoxModel.php`
- `component/admin/src/Model/ShippingBoxesModel.php`
- `component/admin/tmpl/shippingbox/edit.php` (delegates to a shared edit layout)
- `component/admin/tmpl/shippingboxes/default.php`

**Verification boundary:** Model and view presence confirmed. Actual box-selection algorithm, form field implementation and toolbar behaviour still require source tracing and runtime tests.
