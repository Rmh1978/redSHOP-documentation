# Shipping Methods and Rates

Shipping methods determine which shipping service or calculation plugin is used. Shipping rates are rules attached to a method. The original manual includes method lists, method editing, rate lists, rate editing, and worked examples for product/country and shopper-group restrictions.

## Shipping Method list

| Historical field | Meaning |
|---|---|
| Shipping Method Name | Displayed method identifier/name. |
| Plugin | Associated shipping plugin. |
| redSHOP Version | Historical compatibility/version indicator; verify current relevance. |
| Support Rate | Whether the method supports configured rates. |
| Support Location | Whether location conditions are supported. |
| Published | Enable/disable the method. |
| ID | Internal method identifier. |

The historical method editor includes **Shipping Method Name**, **Shipping Class**, **Published** and **Shipping Rates**. Save, Save & Close and Cancel were available. Plugin support and current UI fields must be checked in the test installation.

## Shipping Rate list

The historical rate list displays **Shipping Rate Name**, **Shipping Rate**, **Priority**, and **ID**. Its toolbar documents **New**, **Copy**, **Edit**, **Delete**, and **Close**. Test copying a rate to ensure country, category and shopper-group restrictions are not unintentionally broadened.

## Shipping Rate detail — full historical field inventory

| Field | Purpose / check |
|---|---|
| Shipping Rate Name | Administrator-facing rule name. |
| Weight Start / Weight End | Lower and upper weight bounds. |
| Volume Start / Volume End | Lower and upper volume bounds. |
| Shipping Rate Length Start / End | Length range. |
| Shipping Rate Width Start / End | Width range. |
| Shipping Rate Height Start / End | Height range. |
| Order Total Start / End | Order-value bounds. |
| Zip code start / end | Postal-code range; check formatting and leading zeros. |
| Country | Allowed destination countries. |
| State | State/region restrictions. |
| Shipping Rate Product | Product restriction. |
| Category | Product category restriction. |
| Shopper Groups | Customer group restriction. |
| Shipping Rate | Charge applied by the rule. |
| Priority | Relative rate priority. |
| This shipping rate is for | Historical scope/condition selector; verify available choices. |
| VAT group | Tax group applied to the shipping charge. |
| Add VAT | Whether VAT is added according to configured rules. |
| Consignor Carrier Code | Carrier-specific reference; verify supported integration. |

## Example 1 — product and country-specific shipping rate

1. Enable a test shipping method and open its **Shipping Rates**.
2. Create a rate named `Test product — Denmark`.
3. Select Denmark under **Country** and a published test product under **Shipping Rate Product**.
4. Set a test charge, an appropriate priority, and save.
5. Place an order containing that product to a Danish address; verify the rate appears.
6. Repeat with a different product and destination; confirm the restricted rate is not offered.
7. Check the rate's tax treatment and the final order total.

## Example 2 — shopper-group shipping rate

1. Create a shopper group specifically for testing.
2. Add a rate restricted to that group.
3. Sign in as a member of the group and verify eligibility.
4. Sign in as a user outside the group and verify the rate is not offered.
5. Check what happens when multiple rates have the same priority.

## Failure diagnosis

- **Rate missing:** Check method publication, plugin availability, destination, product/category, shopper group, dimension ranges and order value.
- **Unexpected charge:** Check units, range boundaries, VAT group, shipping-tax configuration and overlapping rules.
- **Carrier label fails:** Inspect the provider integration separately; a valid rate does not prove carrier API access.
- **No shipping at checkout:** Check Global Configuration → Cart and whether shipping is required for the products.

## Source references and Joomla compatibility

- `component/admin/src/Model/ShippingMethodModel.php`
- `component/admin/src/Model/ShippingMethodsModel.php`
- `component/admin/src/Model/ShippingrateModel.php`
- `component/admin/src/Model/ShippingratesModel.php`
- `component/admin/tmpl/shippingrate/edit.php`

The current rate editor still uses `jQuery` and overrides `Joomla.submitbutton`. Audit the JavaScript and its validation against Joomla 6; do not claim the interface is fully future-proof without testing. **No actual rate calculation or provider API has been live-tested.**
