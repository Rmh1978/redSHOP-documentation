# Wrappings

Wrapping Management lets administrators offer a wrapping choice for products. The historical manual describes the list screen, edit screen, creation, frontend display and customer selection.

## Wrappings list

| Historical field | Description |
|---|---|
| Wrapping Name | Name displayed in the list and possibly to the customer. |
| Wrapping Image | Illustration of the wrapping. |
| Wrapping Price | Charge for selecting it. |
| Use for all products | Makes wrapping generally available rather than restricted. |
| Published | Availability of the wrapping. |

Historical list actions include **New**, **Edit**, **Delete**, **Publish**, and **Unpublish**. Historical edit actions include **Save**, **Save & Close**, and **Cancel**.

## Current wrapper form — verified fields

The current `component/admin/forms/wrapper.xml` defines:

| Form name | Description |
|---|---|
| `id` | Internal identifier (hidden). |
| `name` | Required wrapper name. |
| `price` | Numeric wrapping price. |
| `product_id` | Product assignment. |
| `category_id` | Category assignment. |
| `image` | Wrapper image. |
| `use_to_all` | Make available to all products. |
| `published` | Publication status. |

This is a more complete inventory than the old manual, which did not clearly describe product assignment.

## Create a wrapping

1. Open redSHOP administration → Shipping → Wrappings.
2. Create a wrapper named `Gift wrap — blue`.
3. Enter a test price, upload an image and select applicable products or categories, unless **Use for all products** is intended.
4. Publish and save the wrapper.
5. Open an eligible product on the frontend and check that the wrapping is offered by the active product template.
6. Add the product to the cart, select wrapping, and verify its price, tax and order details.

## Frontend troubleshooting

If the wrapper is not displayed, check publication, product/category assignment, global wrapping configuration, product template and whether the required template tags or layout are present. Verify the customer can change or remove the selection before checkout. Check the same order after saving and in confirmation email/invoice if supported.

## Source references

- `component/admin/forms/wrapper.xml`
- `component/admin/tmpl/wrapper/edit.php`
- `component/admin/tmpl/wrappers/default.php`
- `component/admin/tmpl/configuration/default_wrapping.php`
- `media/com_redshop/templates/wrapper_template/default.php`

**Verification boundary:** Current form field names were confirmed in source. Exact storefront rendering, tax rules and per-item vs per-order price application remain to be tested.
