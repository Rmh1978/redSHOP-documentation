# Shipping in redSHOP

redSHOP shipping administration includes **Shipping Methods**, **Shipping Rates**, **Shipping Boxes**, and **Wrappings**. A shipping method supplies the carrier or calculation mechanism; its rates may depend on the destination, products, shopper group, weight, dimensions, or order value. Shipping boxes represent physical package sizes. Wrappings are optional product presentation or gift-wrap selections, not shipping carriers.

## Where to begin

1. Check which shipping plugins are installed and published. A method's availability does not prove its external carrier API is working.
2. Set consistent weight and dimension units in Global Configuration → Products.
3. Configure shipping destinations, VAT and checkout requirements before defining rates.
4. Create and test a rate for a sample product, a shopper group, and an allowed destination.
5. Test shipping selection and the final order total as a guest and a registered customer.

## Guides

- [Shipping Methods and Rates](shipping-methods.md)
- [Shipping Boxes](shipping-boxs.md)
- [Wrappings](wrappings.md)

## Compatibility and verification

The current `develop` branch includes separate administrator models and views for shipping methods, rates and boxes, plus a Joomla form for wrappers. Historical carrier integrations require independent API verification. Use a separate Joomla 5/6 test installation; do not enter production credentials in screenshots.
