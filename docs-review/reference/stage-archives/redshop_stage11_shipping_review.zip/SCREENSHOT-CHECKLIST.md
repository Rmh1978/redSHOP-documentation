# Stage 11 screenshot checklist

- [ ] Shipping Methods list and toolbar
- [ ] Shipping Method edit with plugin and publication settings
- [ ] Shipping Rate list and priority
- [ ] Shipping Rate edit: ranges, countries, products, shopper groups, VAT
- [ ] Shipping Boxes list and edit
- [ ] Wrappings list and editor
- [ ] Frontend shipping method selection and order totals
- [ ] Frontend wrapping choice and cart line

No screenshots have been captured or fabricated.
