# Proposed documentation roadmap

Repository inventory: 156 Markdown files across 21 directory/intro groups, including 16 changelog files and 1 introduction. A stage is a work package, not necessarily a directory. Earlier stages 1–10 covered some topics in overlapping batches; the following is a proposed planning baseline, not an assertion that all previous work is finished.

- Stages 1–10: existing Getting Started, Global Configuration, Categories, Products, Stockroom, Orders and related revisions; quality audit OPEN.
- Stage 11: Shipping (4 articles).
- Stage 12: Users (4 articles).
- Stage 13: Discounts (8 articles).
- Stage 14: Communication (4 articles).
- Stage 15: Customer Input (3 articles).
- Stage 16: Customization (9 articles).
- Stage 17: VAT (4 articles) and accounting/e-conomic (4 articles).
- Stage 18: Import/Export (3 articles), Media (2 articles), FAQ (5 articles).
- Stage 19: Modules (22 articles) and plugins (20 articles), potentially split into smaller stages.
- Stage 20: Changelog (16 articles), introduction, navigation, cross-links, screenshot validation and final release audit.

Actual total likely 20–23 stages depending on plugin/module batching. Remaining work is not a simple count because the existing stage coverage overlaps.
