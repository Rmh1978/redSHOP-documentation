# redSHOP system requirements

> **Documentation target:** redSHOP 5.0.6  
> **Compatibility verified in release documentation:** Joomla 5.4 and PHP 8.2  
> **Joomla 6:** Not yet verified. Do not treat Joomla 6 compatibility as confirmed until installation and upgrade tests pass.  
> **Review status:** Source-checked; confirm the actual server environment before deployment.

redSHOP is a Joomla e-commerce component. The web server must satisfy both the requirements of the installed Joomla version and those of the redSHOP release.

## Supported environment

| Software | Status for redSHOP 5.0.6 |
| --- | --- |
| Joomla 5.4 | Current documented compatibility target |
| PHP 8.2 | Current documented minimum PHP target |
| Joomla 6 | Not yet verified |
| Database | Use a database server supported by the selected Joomla version; redSHOP's installation includes MySQL SQL scripts. A separate redSHOP minimum database version has not been verified. |
| Web server | Use a server configuration supported by Joomla. No redSHOP-specific Apache/IIS minimum has been verified. |

**Important:** These are the compatibility claims recorded in the current redSHOP release-system documentation, not a guarantee that every optional integration has been tested in every environment. PHP 8.3 and later should be validated separately before being listed as supported.

## Before installation

1. Confirm the Joomla and PHP versions in **System → System Information**.
2. Verify that your database server is supported by the installed Joomla version.
3. Confirm that Joomla can write to its required temporary and log directories.
4. Ensure the web server can install a Joomla extension ZIP package.
5. Take a full backup before installing redSHOP on an existing production website.
6. Check any required payment, shipping, or accounting integrations separately. They may have additional prerequisites.

![Joomla System Information showing PHP and database versions](./manual/en-US/chapters/getting-started-general/img/rs506-system-information.png)

## Installation package

The redSHOP 5.0.6 component manifest declares a component, the redSHOP library, site modules, and multiple plugins. The installer script processes bundled libraries, modules, and plugins. Available integrations and their configuration depend on the release package and which extensions are enabled.

Do not use the legacy Joomla 2.5 / Joomla 3 / PHP 5 requirements from older versions of this manual.

## Related articles

- [Installing redSHOP](chapters/getting-started-general/installing-redshop.md)
- [Updating redSHOP](chapters/getting-started-general/updating-redshop.md)

---

*Documentation reviewed against source: redSHOP 5.0.6. Runtime screenshots and compatibility testing pending.*
