# Installing redSHOP

> **Documentation target:** redSHOP 5.0.6  
> **Joomla target:** 5.4  
> **Review status:** Installation manifest and installer code checked; exact post-install screen requires UI verification.

This guide explains how to install the redSHOP component on an existing Joomla website.

## Before you begin

- Use a supported Joomla/PHP environment. See [System requirements](chapters/getting-started-general/redshop-minimum-requirements.md).
- Obtain the **official redSHOP installation ZIP** supplied for your subscription or installation. Do not assume that a GitHub source archive is an installable Joomla package.
- Back up the site's files and database, particularly if redSHOP has been installed before.
- Sign in to Joomla with an account allowed to install extensions.

## Install the component

1. In Joomla administration, open **System → Install → Extensions**.
2. Use the **Upload Package File** area to select the redSHOP installation ZIP.
3. Wait for Joomla to finish processing the package. Do not close the browser while installation is running.
4. Check the Joomla installation result for errors or warnings.
5. Open redSHOP from the Joomla **Components** menu, if it appears there in your installation.

![Joomla extension installer with the upload area](./manual/en-US/chapters/getting-started-general/img/rs506-install-upload.png)

![Joomla extension installation result](./manual/en-US/chapters/getting-started-general/img/rs506-install-result.png)

The redSHOP manifest identifies the component, its library, bundled site modules, and plugins. The installer script attempts to install those bundled extensions. Some integrations may need additional configuration and may not be enabled by default.

## Initial configuration

After installation, open the redSHOP administration and review your shop's settings, including shop details, countries, currencies, tax settings, customers, shipping, and payment methods. Configure only the extensions you intend to use.

The source contains a **Configuration Wizard** view and controller, but the exact entry point and behavior on a clean Joomla 5.4 installation have not yet been verified. If a setup wizard appears, follow its on-screen steps; otherwise use redSHOP's configuration screens. Do not rely on the legacy manual's claim that exactly three buttons appear after installation.

![redSHOP administration after installation](./manual/en-US/chapters/getting-started-general/img/rs506-install-redshop-dashboard.png)

## Verify the installation

1. Confirm that the redSHOP component opens without an error.
2. Check **System → Manage → Extensions** for the component and the plugins/modules required by your store.
3. Review the relevant payment and shipping plugins before enabling them.
4. Create or inspect a test product and verify that it can be displayed on the storefront.
5. Test checkout with a safe test configuration before accepting live orders.

![Joomla extension manager filtered to redSHOP extensions](./manual/en-US/chapters/getting-started-general/img/rs506-install-extensions.png)

## Troubleshooting

**The ZIP cannot be uploaded:** Check Joomla's upload limits, PHP limits, and available disk space. Confirm you have the release ZIP, not a source-code ZIP.

**The component installs but cannot open:** Review the Joomla error log and verify the installed PHP version and required redSHOP library.

**A plugin or module is missing:** Inspect the Joomla extension list and the contents of the supplied release package. The source manifest alone does not prove every extension was packaged successfully.

**Installation reports a database error:** Save the exact error message and check the database privileges and server compatibility. Restore from backup if the site is left in an unusable state.

## Related articles

- [System requirements](chapters/getting-started-general/redshop-minimum-requirements.md)
- [Updating redSHOP](chapters/getting-started-general/updating-redshop.md)

---

*Documentation reviewed against source: redSHOP 5.0.6. Screenshots and first-install workflow pending verification.*
