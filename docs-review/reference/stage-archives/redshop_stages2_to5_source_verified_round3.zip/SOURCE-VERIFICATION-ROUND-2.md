# Source verification round 2

Checked directly against `Rmh1978/redSHOP-rmh`, branch `develop`.

| Source | Finding | Status |
|---|---|---|
| `configuration/default_general.php` | Includes settings, general layout and modules subtemplates | Confirmed |
| `configuration/default_price.php` | Show-price conditional UI, currency symbol, separators, precision, tax exemption and catalog mode | Confirmed |
| `configuration/default_rating_settings.php` | Rating message, favoured reviews and thumbnail sizes | Confirmed |
| `configuration/default_integration.php` | GLS, Clickatell, Post Denmark and e-conomic subtemplates | Confirmed |
| `configuration/default_menuhide.php` | `MENUHIDE` list and checkbox hierarchy | Confirmed |
| `configuration/default_menuhide.php` | jQuery and legacy Bootstrap classes | Confirmed |
| `configuration/default_price.php` | jQuery used in currency symbol helper | Confirmed |

## Not yet confirmed

- Full runtime semantics and validation of each of the 134 historical settings.
- Backend saving and model-side validation.
- Compatibility of provider integrations and their external APIs.
- Joomla 6 frontend/admin regression testing.
- Screenshots and original-to-revision loss audit for every article.

No GitHub commits or test-site changes were made.
