# Products

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Products** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## General

Review default product display and catalogue settings, including products with variants and accessories.

## Unit Settings

Configure units used for weight, length and dimensions. Verify shipping calculations if carrier rules depend on these units.

## Download

Current code exposes `PRODUCT_DOWNLOAD_LIMIT`, `PRODUCT_DOWNLOAD_DAYS` and `PRODUCT_DOWNLOAD_ROOT`. The root is a filesystem path, not a public download URL. Test access control, path validation and expired links.

## Wrapping Management

Check whether gift wrapping is enabled and how prices, VAT and available choices are shown.

## Catalog Management and Samples

Historical settings cover catalogue mode and product samples. Verify installed modules and storefront workflows.

## Product Template and Image Settings

Check the product detail template and image dimensions. Regenerate or clear cached thumbnails where required.

## Accessory Products

Check accessory product selection, pricing and image dimensions. Test products with no accessories and several accessories.

## Related Products

Check related-product selection, layout and image sizes; verify that the display does not include unpublished products.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_producttab.php`
- `component/admin/tmpl/configuration/default_product_unit.php`
- `component/admin/tmpl/configuration/default_download.php`
- `component/admin/tmpl/configuration/default_wrapping.php`
- `component/admin/tmpl/configuration/default_catalog.php`
- `component/admin/tmpl/configuration/default_product_template_image_settings.php`
- `component/admin/tmpl/configuration/default_accessory_product.php`
- `component/admin/tmpl/configuration/default_related_product.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.

## Detailed historical field reference

| Original setting | What it controls | Validation |
|---|---|---|
| Default category | Whether the default category option is enabled | Verify current meaning in category selectors |
| Default volume unit | Millimetres, centimetres, inches, feet or metres | Check shipping-box dimensions |
| Default weight unit | Grams, pounds or kilograms | Check weight-based shipping rates |
| No. of Decimals | Precision used for measurements | Compare stored and displayed values |
| Maximal number of downloads | Maximum downloads per purchase | Test product-specific overrides |
| Download Period in Days | Link lifetime | Test expiry and per-product override |
| Download Products root | Physical file directory | Check access control and migration |
| Wrapping thumbnail width/height | Wrapping gallery image sizes | Check image output |
| Autoscroll for wrapping | Horizontal gallery behaviour | Test template support |
| Catalog Reminder 1/2 | Timing of catalogue reminder emails | Verify scheduler and mail templates |
| Catalog Discount Duration / percentage | Coupon lifetime and value | Verify creation and expiry |
| Enable Catalog Reminder | Enables historical reminder workflow | Verify current plugin |
| Sample Reminder 1/2/3 | Product-sample reminder schedule | Verify current plugin and templates |
| Default Product template | Default product detail template | Check per-product overrides |
| Default sorting of products | Name, price, SKU, newest or manual order | Verify frontend selector |
| Display out of stock after normal products | Push unavailable products lower | Check sorting |
| Display Out of Stock Attribute Data | Attribute visibility when out of stock | Test variant selection |
| Show Product Images in Lightbox | Main and additional image behaviour | Check current lightbox |
| Watermark Product Image / Thumb / Additional | Image watermark toggles | Verify generated images |
| Product Hover Image / Additional Hover | Hover images and sizes | Test mobile and desktop |
| Attribute / Sub-attribute scroller thumbs | Variant image galleries | Confirm template tags |
| Pre-order Image | Image indicating preorder availability | Check stock and preorder state |
| Show Accessory as individual product in cart | Accessory as separate cart line | Verify totals and VAT |
| Show Accessory Product in Lightbox | Accessory image behaviour | Check current lightbox |
| Default Accessory Sorting | Accessory sort order | Verify frontend |
| Accessory title / description length and suffix | Truncation and continuation | Check accessibility |
| Two-way related product | Reciprocal relation between products | Test A→B and B→A |
| Child Product Dropdown Output | Product name or number | Check variants |
| Parent Product should be purchasable | Allow parent with child products | Verify add-to-cart |
| Default sorting of related products | Related product order | Check frontend |

### Example: migrating downloadable products

If changing `PRODUCT_DOWNLOAD_ROOT`, record the old absolute directory, make a backup, verify the new directory exists and is protected, migrate files using a controlled process, then test an existing paid order and an expired download. The current editor falls back to `JPATH_ROOT/components/com_redshop/assets/download/product` if the configured directory is missing. This fallback is **not** proof that moving files is automatic.
