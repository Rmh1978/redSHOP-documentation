# Stage 3 — revision status

5 English articles revised with original section coverage, examples, code-file anchors and test workflows.

**Not publication-ready:** historical detail and field-by-field original comparison remain incomplete; code execution and screenshots have not been verified. No GitHub changes.

Additional field-level historical reference added for selected high-impact articles. All other articles still require a complete original-field audit.
