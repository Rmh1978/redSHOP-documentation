# Source verification round 3

Repository: `Rmh1978/redSHOP-rmh`, branch `develop`.

Inspected these current PHP templates:

- `configuration/default_settings.php`
- `configuration/default_modules.php`
- `configuration/default_general_layout_settings.php`
- `configuration/default_shopper_group.php`
- `configuration/default_discount.php`
- `configuration/default_discount_mail.php`
- `configuration/default_gls.php`
- `configuration/default_clicktell.php`
- `configuration/default_postdk.php`
- `configuration/default_economic.php`

## Verified additions

- General configuration includes currency-layer key and upload controls.
- User/portal settings include login/logout redirects, name and logo.
- Discount configuration includes coupon/voucher stacking-related controls and post-purchase mail timing.
- Clickatell includes sender ID, country prefix and custom SMS.
- PostNord includes automatic label settings, tracking email and SMS options.
- e-conomic includes booking order status and invoice draft configuration.

## Remaining limitations

Source inspection confirms that administrator templates expose these controls, not that backend validation, external provider APIs or frontend behaviour are correct. No staging site access, live testing or screenshots. Field-by-field comparison across all original articles remains unfinished.
