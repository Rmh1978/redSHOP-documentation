# Cart

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Cart** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Add To Cart Settings

Test button availability, minimum quantities, out-of-stock handling and feedback after adding an item.

## Cart Settings

Current code exposes `CART_TIMEOUT`, `AJAX_CART_DISPLAY_TIME`, `AJAX_DETAIL_BOX_WIDTH`, `AJAX_DETAIL_BOX_HEIGHT`, `AJAX_BOX_WIDTH`, `AJAX_BOX_HEIGHT`, `DEFAULT_QUANTITY`, `DEFAULT_QUANTITY_SELECTBOX_VALUE`, `CONTINUE_REDIRECT_LINK` and `MINIMUM_ORDER_TOTAL`.

## Payment

Check whether payment selection is required, and verify each active payment method with its own test credentials.

## Shipping

Review shipping-method requirements and stockroom/container dependencies. Digital-only shops may need different settings.

## Securing checkout

Confirm HTTPS, CSRF protection, checkout validation, session persistence and customer isolation. A configuration option is not a substitute for a security test.

## Cart Image Settings

Verify thumbnail sizes, aspect ratios and layout in cart, mini-cart and checkout.

## Preorders and quotations

Historical cart settings cover preorder messages, stockrooms and quotations. Verify interactions with actual stock counts.

## Regression checklist

Test guest and registered checkout, cart timeout, discounts, shipping, payment failure and retry.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_cart_settings.php`
- `component/admin/tmpl/configuration/default_payment_ship_secure.php`
- `component/admin/tmpl/configuration/default_cart_template_image_setting.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.

## Historical cart and checkout field reference

| Setting | Purpose |
|---|---|
| One Step Checkout | Uses a one-page checkout template instead of historical multi-step flow |
| Show Shipping in Cart | Display shipping charges in cart |
| Attribute images in cart | Display selected variant image instead of main product image |
| Quantity change in cart | Allow direct quantity editing |
| Quantity Max Characters | Maximum quantity input digits |
| Default product quantities | Comma-separated quantity presets such as `1, 5, 10, 20` |
| Link Continue Shopping | Destination after clicking Continue Shopping |
| Minimum Order Total | Minimum subtotal/total threshold before checkout, depending on calculation |
| Payment Calculation based on | Historical Total or Subtotal options |
| First Invoice Number | Historical numbering reference; current order tab also contains invoice-number fields |
| Shipping same as Billing | Default state of same-address checkbox |
| Enable Shipping Method | Whether checkout requires shipping details |
| Split delivery cost | Historical split-delivery setting |
| Delivery time difference for split delivery calculation | Historical split-delivery timing |
| Delivery Rule (in week) | Historical delivery rule |
| SSL URL in Checkout | Historical HTTPS control; modern Joomla sites should enforce HTTPS globally |
| SSL in Backend | Historical HTTPS control; do not rely on it as sole security measure |
| Cart Reservation Message | Message when final stock is reserved in another cart |
| Product Thumb in Cart | Thumbnail width/height |
| Watermark in Cart thumb | Thumbnail watermark |
| Add to Cart Image / Background | Historical custom button graphics |
| Request Quote Image / Background | Historical quotation button graphics |
| Add to cart update/delete image | Historical cart action graphics |

### Example: minimum order total

Set a test minimum and attempt checkout with an order just below and just above the threshold. Repeat with discounts, tax, shipping and a different currency. The current code includes `MINIMUM_ORDER_TOTAL`, but the exact comparison basis must be checked in the cart calculation.

### Example: quantity presets

Enter `1, 5, 10, 20` in the historical default quantity field. Test whether the active product template actually renders the dropdown and whether it respects stock and maximum quantity rules.
