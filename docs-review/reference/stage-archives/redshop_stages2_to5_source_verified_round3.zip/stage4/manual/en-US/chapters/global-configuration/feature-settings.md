# Feature Settings

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Feature Settings** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Rating

Check review display, moderation and customer eligibility. Current code references `RATING_MSG`, `FAVOURED_REVIEWS` and rating thumbnail dimensions.

## Comparison

Enable comparison only if the template supports it; test different product types.

## Inline Edit

Historical feature: verify permissions and CSRF behaviour before enabling in an administrator workflow.

## Wishlist

Test anonymous versus authenticated users, wishlist persistence and access controls.

## Import/Export

Review allowed formats, character encoding and permission checks; test imports against a database backup.

## Stockroom

Current source references stockroom image dimensions and `DEFAULT_STOCKROOM_BELOW_AMOUNT_NUMBER`; verify threshold and stock-status display.

## Feature dependency checklist

Check associated plugins, templates and modules for each feature rather than treating the global toggle as proof of functionality.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_rating_settings.php`
- `component/admin/tmpl/configuration/default_comparison_settings.php`
- `component/admin/tmpl/configuration/default_feature_inline_edit.php`
- `component/admin/tmpl/configuration/default_wishlist_settings.php`
- `component/admin/tmpl/configuration/default_feature_import_export.php`
- `component/admin/tmpl/configuration/default_stockroom_settings.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.


## Historical field inventory — original manual audit

The following field labels were recovered from the original documentation. Their presence here preserves the original coverage; exact current UI labels and behaviour must be checked on the test installation.

### Rating and comparison

| Historical field | Verification focus |
|---|---|
| Rating/Review completed message | Customer-facing display and email output |
| Number favoured reviews | Value, validation, current availability and frontend effect |
| Login Required (reviews) | Value, validation, current availability and frontend effect |
| Login Required (comparison) | Value, validation, current availability and frontend effect |
| Max. No. of Products to Compare | Value, validation, current availability and frontend effect |
| Comparison can be done: Category | Value, validation, current availability and frontend effect |
| Comparison can be done: Globally | Value, validation, current availability and frontend effect |
| Product Comparison Template | Value, validation, current availability and frontend effect |
| Compare Product Thumb | Value, validation, current availability and frontend effect |

### Import/Export

| Historical field | Verification focus |
|---|---|
| Min file size | Value, validation, current availability and frontend effect |
| Max file size | Value, validation, current availability and frontend effect |
| Allowed file MIME | Value, validation, current availability and frontend effect |
| Allowed file extension | Value, validation, current availability and frontend effect |
| Max Line | Value, validation, current availability and frontend effect |

### Stockroom

| Historical field | Verification focus |
|---|---|
| Stockroom in menu redSHOP administrator | Value, validation, current availability and frontend effect |
| Use Stockroom | Value, validation, current availability and frontend effect |
| Alert below amount number | Value, validation, current availability and frontend effect |
| Default Stockroom | Value, validation, current availability and frontend effect |
| Use Out of Stock Image | Value, validation, current availability and frontend effect |
| Enable Stockroom Notification | Value, validation, current availability and frontend effect |
| Default Stock Amount Image Width/Height | Value, validation, current availability and frontend effect |

## Verified rating controls

The current `default_rating_settings.php` template references `RATING_MSG`, `FAVOURED_REVIEWS`, `RATING_THUMB_IMAGE_WIDTH` and `RATING_THUMB_IMAGE_HEIGHT`. These correspond to the review-completion message, favoured-review count and rating thumbnail dimensions. Test the frontend review form and any moderation workflow before treating historical review permissions as current.

### Example: review confirmation

Submit a review using a test customer, confirm the completion message, and check whether the review is published immediately or awaits approval. Then test a visitor who is not logged in.
