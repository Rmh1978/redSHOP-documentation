# Original-field coverage audit

- `stage3/manual/en-US/chapters/global-configuration/general.md`: 22 historical fields enumerated across 3 groups.
- `stage3/manual/en-US/chapters/global-configuration/user.md`: 19 historical fields enumerated across 2 groups.
- `stage3/manual/en-US/chapters/global-configuration/price.md`: 43 historical fields enumerated across 4 groups.
- `stage4/manual/en-US/chapters/global-configuration/feature-settings.md`: 21 historical fields enumerated across 3 groups.
- `stage5/manual/en-US/chapters/global-configuration/integration.md`: 15 historical fields enumerated across 4 groups.
- `stage5/manual/en-US/chapters/global-configuration/dashboard.md`: 14 historical fields enumerated across 1 groups.

These are recovered original labels, not verified current features. Check source model/controller and redshop6 before publication.
