# Stage 8 screenshot checklist

Save screenshots under `manual/en-US/chapters/product-management/img/`.

- [ ] `rs506-product-list.png` — Product list.
- [ ] `rs506-product-list-actions.png` — List toolbar and bulk actions.
- [ ] `rs506-product-price-management.png` — Price management screen.
- [ ] `rs506-product-editor.png` — Product editor overview.
- [ ] `rs506-product-information.png` — Product Information.
- [ ] `rs506-product-types.png` — Product Types and download options.
- [ ] `rs506-product-custom-fields.png` — Custom fields.
- [ ] `rs506-product-images.png` — Main and other images.
- [ ] `rs506-product-attributes.png` — Attributes and properties.
- [ ] `rs506-product-accessories.png` — Accessories and related products.
- [ ] `rs506-product-seo.png` — SEO fields.
- [ ] `rs506-product-discount-calculator.png` — Discount calculator.
- [ ] `rs506-product-payment-methods.png` — Product-specific payment methods.
- [ ] `rs506-product-mass-discounts.png` — Mass-discount setup.
- [ ] `rs506-product-price-discounts.png` — Price-discount rules.

Use test products and redact any private customer, supplier or payment data.
