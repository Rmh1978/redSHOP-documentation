# Stage 8 — Product Management

Contains:
- `manual/en-US/chapters/product-management/overview-product-management.md`
- `manual/en-US/chapters/product-management/products-redshop.md`

The main article preserves the original major sections (listing, pricing, information, product types, custom fields, images, attributes, accessories, related products, finder, SEO, discount calculator, accounting, payment methods, mass discounts and price discounts).

Checked against current `develop` source including:
- `component/admin/tmpl/product/edit_general_data.php`
- `component/admin/tmpl/product/edit_producttype.php`
- `component/admin/tmpl/product/edit_product_attribute.php`
- `component/admin/tmpl/product/edit_product_accessory.php`
- `component/admin/tmpl/product/edit_product_payment_method.php`
- `component/admin/tmpl/product/edit_calculator.php`
- `component/admin/forms/product.xml`

Other original material remains a historical reference and needs UI verification. Full field-by-field audit and end-to-end tests are still open. Do not treat this draft as fully validated. No GitHub commits made.
