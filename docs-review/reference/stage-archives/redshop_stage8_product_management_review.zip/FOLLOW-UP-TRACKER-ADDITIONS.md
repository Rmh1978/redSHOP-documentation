# Internal follow-up — Stage 8

This is a source-reviewed documentation draft, not a live-tested certification.

| ID | Status | Verification |
| --- | --- | --- |
| DOC-8-01 | OPEN | Compare current product list columns, toolbar and bulk category actions with the historical manual. |
| DOC-8-02 | OPEN | Verify current Product Price Management workflow and shopper-group quantity rules. |
| DOC-8-03 | OPEN | Check all Product Information fields, validation, date/time handling and tax labels in the test UI. |
| DOC-8-04 | OPEN | Test downloadable-product access, limits and file storage; verify protection against direct file access. |
| DOC-8-05 | OPEN | Test subscriptions, renewals and serial-number delivery where configured. |
| DOC-8-06 | OPEN | Confirm product custom-field display and available editor tabs. |
| DOC-8-07 | OPEN | Test additional image publishing and media gallery output. |
| DOC-8-08 | OPEN | Test attribute-set copy; source contains `task==product.ajaxDisplayAttributeSet` and may require a fix. |
| DOC-8-09 | OPEN | Test attribute/subproperty price calculations and required selection. |
| DOC-8-10 | OPEN | Verify product vs category accessory precedence and related-product rendering. |
| DOC-8-11 | OPEN | Confirm redPRODUCTFINDER integration availability and UI. |
| DOC-8-12 | OPEN | Verify product SEO fieldset, SEF URLs and generated metadata. |
| DOC-8-13 | OPEN | Review Discount Calculator units, dimension handling and discount precedence. |
| DOC-8-14 | OPEN | Verify accounting integration field mapping. |
| DOC-8-15 | OPEN | Test individual payment-method restrictions, including mixed-product carts. |
| DOC-8-16 | OPEN | Verify mass discount and product price discount fields, ordering and shopper-group rules. |
| DOC-8-17 | OPEN | Capture 15 screenshots and verify relative links against actual docs tree. |
| DOC-8-18 | OPEN | Audit original 2019 product article field-by-field to ensure no still-relevant advanced fields were omitted from the rewritten draft. |
