# Screenshot checklist — phases 6–8

Take screenshots in Joomla administration on the redSHOP 5.0.6 test site. Do not capture personal data, live orders or credentials.

- [ ] `global-configuration/img/rs506-categories-overview.png` — Category configuration: relevant administrator overview or edit screen.
- [ ] `global-configuration/img/rs506-manufacturers-overview.png` — Manufacturer configuration: relevant administrator overview or edit screen.
- [ ] `global-configuration/img/rs506-newsletter-overview.png` — Newsletter configuration: relevant administrator overview or edit screen.
- [ ] `global-configuration/img/rs506-about-overview.png` — About and system information: relevant administrator overview or edit screen.
- [ ] `global-configuration/img/rs506-start-here-overview.png` — Configuration: start here: relevant administrator overview or edit screen.
- [ ] `categories/img/rs506-overview-category-overview.png` — Category management overview: relevant administrator overview or edit screen.
- [ ] `categories/img/rs506-redshop-categories-overview.png` — Working with categories: relevant administrator overview or edit screen.
- [ ] `product-management/img/rs506-overview-product-management-overview.png` — Product management overview: relevant administrator overview or edit screen.
- [ ] `product-management/img/rs506-products-redshop-overview.png` — Working with products: relevant administrator overview or edit screen.
