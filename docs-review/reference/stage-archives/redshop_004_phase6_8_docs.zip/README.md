# redSHOP documentation — phases 6–8

Nine English articles organized in repository paths under `manual/en-US/chapters/`.

- Phase 6: five Global Configuration articles.
- Phase 7: two Category Management articles.
- Phase 8: two Product Management articles.

Copy the `manual/` directory into the documentation repository. Keep `FOLLOW-UP-TRACKER-ADDITIONS.md` private and merge its entries into the existing follow-up tracker (28 earlier entries). Capture the screenshots in `SCREENSHOT-CHECKLIST.md` before publishing or remove unfulfilled image references temporarily.

Source reference: `Rmh1978/redSHOP-rmh` branch `develop`, redSHOP 5.0.6. These guides are intentionally concise where runtime behaviour has not been verified. The original extensive articles may include functionality that requires separate follow-up; preserve the previous versions in Git history.
