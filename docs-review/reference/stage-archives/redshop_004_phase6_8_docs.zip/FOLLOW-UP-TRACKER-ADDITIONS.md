# Documentation follow-up tracker — phases 6–8

Internal editorial checklist. Do not publish this file as an end-user article.

| ID | Article | Follow-up | Status |
|---|---|---|---|
| DOC-029 | `global-configuration/categories.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-030 | `global-configuration/manufacturers.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-031 | `global-configuration/newsletter.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-032 | `global-configuration/about.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-033 | `global-configuration/start-here.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-034 | `categories/overview-category.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-035 | `categories/redshop-categories.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-036 | `product-management/overview-product-management.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
| DOC-037 | `product-management/products-redshop.md` | Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions. | OPEN |
