# Category management overview

This guide describes the relevant redSHOP administration workflow for the 5.0.6 documentation series.

![Category management overview overview](./manual/en-US/chapters/categories/img/rs506-overview-category-overview.png)

## Organize the catalog

Categories group products into browsable sections. Plan names and parent-child relationships before creating a large catalog.

## Manage categories

Open the redSHOP category management area to create, edit, publish and organize categories. Verify which actions are available to your Joomla administrator account.

## Templates and images

Choose appropriate category layouts and images, and review the resulting frontend pages on desktop and mobile.

## Next steps

Continue with the Working with Categories guide for detailed category editing instructions.

