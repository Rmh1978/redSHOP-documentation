# Working with categories

This guide describes the relevant redSHOP administration workflow for the 5.0.6 documentation series.

![Working with categories overview](./manual/en-US/chapters/categories/img/rs506-redshop-categories-overview.png)

## Find and edit categories

Open redSHOP in Joomla administration and navigate to the category list. Use the available search and filters to locate a category, then open its edit form.

## Create a category

Use the New action, enter a clear category name, choose the parent category when applicable, and complete the fields required by your site. Save the record before checking the storefront.

## Category information

Review description, publication state, images and other available category fields. Keep category text useful to customers and avoid repeating the same content across multiple pages.

## Product and access settings

Review product assignments and any shopper-group or access restrictions configured for the category. Test with an appropriate customer account if the store has restricted catalog sections.

## SEO and templates

Set a suitable layout and review SEO-related fields in the category edit form. Confirm the actual page URL and metadata after saving.

## Verification

Open the category in the frontend and confirm that its products, links, images and navigation appear as intended. More detailed field-by-field examples will be added in a future update.

