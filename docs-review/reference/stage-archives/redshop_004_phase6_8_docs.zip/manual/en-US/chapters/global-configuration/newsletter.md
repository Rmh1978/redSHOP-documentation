# Newsletter configuration

This guide describes the relevant redSHOP administration workflow for the 5.0.6 documentation series.

![Newsletter configuration overview](./manual/en-US/chapters/global-configuration/img/rs506-newsletter-overview.png)

## Enable and confirm subscriptions

Enable newsletters only if you intend to maintain a subscriber list. The newsletter confirmation setting controls the sign-up confirmation option; test subscription and unsubscribe flows before inviting customers.

## Sender identity

Set the sender name and sender email address. Use a valid mailbox and ensure the Joomla mail configuration is working.

## Batch delivery

Configure how many newsletter emails are sent in a batch and the pause between batches. Start with conservative values appropriate to your mail provider.

## Test mail

Enter a testing email address and use the available test action before sending a newsletter to subscribers.

