# About and system information

This guide describes the relevant redSHOP administration workflow for the 5.0.6 documentation series.

![About and system information overview](./manual/en-US/chapters/global-configuration/img/rs506-about-overview.png)

## System information

Open the About tab in redSHOP configuration to review the system information displayed by the installed version.

## Modules

Review the redSHOP modules reported in the About tab. The availability of an extension does not necessarily mean it is enabled or configured for use.

## Shipping and payment plugins

The About tab includes shipping and payment plugin sections. Check the Joomla extension manager and the individual plugin settings before activating a payment or shipping method.

