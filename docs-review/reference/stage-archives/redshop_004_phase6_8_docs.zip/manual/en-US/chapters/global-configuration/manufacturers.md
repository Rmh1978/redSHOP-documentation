# Manufacturer configuration

This guide describes the relevant redSHOP administration workflow for the 5.0.6 documentation series.

![Manufacturer configuration overview](./manual/en-US/chapters/global-configuration/img/rs506-manufacturers-overview.png)

## Manufacturer settings

Select the default manufacturer template, manufacturer ordering, and product ordering within manufacturer views. Set the maximum title length and optional truncation suffix as needed.

## Notification settings

The configuration includes manufacturer and supplier email toggles. Before enabling either option, confirm the recipient addresses and test the relevant order flow.

## Images

Configure manufacturer image and thumbnail dimensions. Watermark options are available for manufacturer images and thumbnails; check the final appearance with your actual image assets.

