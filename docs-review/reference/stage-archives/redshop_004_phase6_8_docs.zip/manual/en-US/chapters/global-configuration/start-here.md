# Configuration: start here

This guide describes the relevant redSHOP administration workflow for the 5.0.6 documentation series.

![Configuration: start here overview](./manual/en-US/chapters/global-configuration/img/rs506-start-here-overview.png)

## Open configuration

Sign in to Joomla administration, open redSHOP, and select Configuration. The available tabs group settings for store behaviour, customers, products, prices, checkout, orders, SEO and integrations.

## Before making changes

Record the current values and create a backup before changing checkout, tax, payment, shipping, or account settings. Test those changes on a staging site.

## Save and verify

Save the settings, then verify the corresponding frontend or administrator workflow. Some settings require suitable templates, plugins, or other configuration before they have a visible effect.

## Where to continue

Use the dedicated configuration articles for Categories, Manufacturers, Newsletter, Cart, Orders, Products, Price and SEO. More detailed examples will be added in a future update.

