# Category configuration

This guide describes the relevant redSHOP administration workflow for the 5.0.6 documentation series.

![Category configuration overview](./manual/en-US/chapters/global-configuration/img/rs506-categories-overview.png)

## Category ordering and limits

Choose the default category ordering method and the maximum number of categories shown where the selected layout supports these settings. Review the storefront after changing either value.

## Descriptions and suffixes

Configure maximum character counts and ending suffixes for category titles, descriptions, and product text in category listings. A suffix can indicate truncated text; test the result with long titles and multilingual content.

## Templates

Select the default category and category-list templates. Individual category settings may provide a different template, so verify the rendered page rather than relying only on the global default.

## Images

Review the image and thumbnail dimensions offered in the Categories tab. Prepare images with consistent proportions to reduce cropping and layout shifts.

