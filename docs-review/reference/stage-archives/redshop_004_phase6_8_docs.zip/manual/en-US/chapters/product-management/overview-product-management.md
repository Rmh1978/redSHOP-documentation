# Product management overview

This guide describes the relevant redSHOP administration workflow for the 5.0.6 documentation series.

![Product management overview overview](./manual/en-US/chapters/product-management/img/rs506-overview-product-management-overview.png)

## Manage your catalog

The product management area is used to maintain product records, prices, images and product-specific settings.

## Prepare products

Before creating a product, collect its name, SKU, description, category assignment, images, pricing and any required stock or shipping information.

## Test storefront behaviour

After saving a product, verify its category placement, detail page, price and add-to-cart flow. Additional configuration may be needed for downloadable products and product variants.

## Continue reading

See Working with Products and Price Management for more detailed procedures.

