# Working with products

This guide describes the relevant redSHOP administration workflow for the 5.0.6 documentation series.

![Working with products overview](./manual/en-US/chapters/product-management/img/rs506-products-redshop-overview.png)

## Open the product list

In Joomla administration, open redSHOP and navigate to Products. Use the available search and filters to find an existing product.

## Create or edit a product

Choose New to create a product, or open an existing product to edit it. Enter a descriptive name and SKU, assign categories and fill in the relevant product information.

## Prices and tax

Review the product price, applicable VAT settings and any shopper-group or quantity-based prices used by your store. Check the final amount in the frontend.

## Images and media

Add suitable product images and verify thumbnail and detail-page presentation. Keep original assets backed up before replacing them.

## Attributes and accessories

Where used, configure product attributes, accessories and related products. Test each selectable combination and confirm the cart receives the intended item and price.

## Stock and fulfilment

Review stock-related settings and any product-specific shipping or download requirements. Test the behaviour for both available and unavailable stock.

## Publish and test

Save the product, verify its publication state, then check its category listing, detail page and checkout flow. A detailed reference for individual fields will be added in a future update.

