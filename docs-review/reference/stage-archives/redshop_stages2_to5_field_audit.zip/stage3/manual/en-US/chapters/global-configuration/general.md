# General

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **General** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Store Settings

Review store name, contact and business address fields. These values may appear in emails, invoices and storefront templates.

## Modules and Features

Enable only installed and supported features. A visible configuration toggle does not guarantee the associated plugin or module is present.

## General Layout Settings

Check date/time presentation, display defaults and layout-related options. Verify the result in both administrator and frontend views.

## Validation workflow

Save a single changed field, reload the form, inspect the storefront and check customer-facing documents for the expected value.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_general.php`
- `component/admin/tmpl/configuration/default_modules.php`
- `component/admin/tmpl/configuration/default_general_layout_settings.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.


## Historical field inventory — original manual audit

The following field labels were recovered from the original documentation. Their presence here preserves the original coverage; exact current UI labels and behaviour must be checked on the test installation.

### Store settings

| Historical field | Verification focus |
|---|---|
| Shop Name | Value, validation, current availability and frontend effect |
| Shop Country | Value, validation, current availability and frontend effect |
| Retail Countries | Value, validation, current availability and frontend effect |
| Default Shipping Country | Value, validation, current availability and frontend effect |
| Date Format | Value, validation, current availability and frontend effect |
| Welcome Message | Customer-facing display and email output |
| Administrator Email | Customer-facing display and email output |
| Use Multibyte Encoding | Value, validation, current availability and frontend effect |
| Currency Libraries | Value, validation, current availability and frontend effect |

### Modules and features

| Historical field | Verification focus |
|---|---|
| Retail Countries | Value, validation, current availability and frontend effect |
| Enable Statistics | Value, validation, current availability and frontend effect |
| Enable Customer Tagging | Value, validation, current availability and frontend effect |
| Enable Address Detail in Shipping | Value, validation, current availability and frontend effect |
| Enable Product Reserve | Value, validation, current availability and frontend effect |
| Cart Reservation Message | Customer-facing display and email output |
| Do you want to load redSHOP style | Value, validation, current availability and frontend effect |

### Layout and upload

| Historical field | Verification focus |
|---|---|
| Legal Extensions (File Types) | Value, validation, current availability and frontend effect |
| Image quality | Value, validation, current availability and frontend effect |
| Image max width | Value, validation, current availability and frontend effect |
| Images max height | Value, validation, current availability and frontend effect |
| Images processing method | Value, validation, current availability and frontend effect |
| Max file size upload | Value, validation, current availability and frontend effect |
