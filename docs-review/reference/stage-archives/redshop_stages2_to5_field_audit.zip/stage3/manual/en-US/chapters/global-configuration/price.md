# Price

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Price** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Main Price Settings

The current source references `REDCURRENCY_SYMBOL`, `PRICE_SEPERATOR`, `THOUSAND_SEPERATOR`, `PRICE_DECIMAL`, `CALCULATION_PRICE_DECIMAL` and `ZERO_PRICE_REPLACE`. Distinguish display precision from calculation precision.

## VAT / Tax

Current code references `VAT_RATE_AFTER_DISCOUNT`, `VAT_INTROTEXT`, `WITH_VAT_TEXT_INFO` and `WITHOUT_VAT_TEXT_INFO`. Verify tax rules for customer location, shopper group and discounted items.

## Gift Card Image Settings

The original manual includes gift card image settings; test only if gift card functionality is enabled.

## Discount

Verify interaction between global, product, category and shopper-group discounts; avoid assuming stacking order.

## Discount Mail

Review triggers, recipient rules and templates before enabling customer-facing discount emails.

## Price regression tests

Compare base price, discounted price, shipping, VAT and final order total for a guest and a registered shopper.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_price.php`
- `component/admin/tmpl/configuration/default_vat.php`
- `component/admin/tmpl/configuration/default_discount.php`
- `component/admin/tmpl/configuration/default_discount_mail.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.


## Historical field inventory — original manual audit

The following field labels were recovered from the original documentation. Their presence here preserves the original coverage; exact current UI labels and behaviour must be checked on the test installation.

### Price presentation

| Historical field | Verification focus |
|---|---|
| Currency | Value, validation, current availability and frontend effect |
| Currency Symbol | Value, validation, current availability and frontend effect |
| Currency Symbol Position | Value, validation, current availability and frontend effect |
| Decimal Separator | Value, validation, current availability and frontend effect |
| Thousand Separator | Value, validation, current availability and frontend effect |
| Number of Price Decimals | Value, validation, current availability and frontend effect |
| Number of Price Round | Value, validation, current availability and frontend effect |
| Use Tax Exempt | Value, validation, current availability and frontend effect |
| Show Tax Exempt in Front | Value, validation, current availability and frontend effect |
| Apply VAT for Tax Exempt | Value, validation, current availability and frontend effect |
| Remove Add to Cart from front (use as catalog) | Value, validation, current availability and frontend effect |
| Show Price | Value, validation, current availability and frontend effect |

### Tax

| Historical field | Verification focus |
|---|---|
| Default Country | Value, validation, current availability and frontend effect |
| Default State | Value, validation, current availability and frontend effect |
| Default VAT Group | Value, validation, current availability and frontend effect |
| Default VAT Calculation based on | Value, validation, current availability and frontend effect |
| Webshop | Value, validation, current availability and frontend effect |
| Customer | Value, validation, current availability and frontend effect |
| EU Mode | Value, validation, current availability and frontend effect |
| Apply VAT on Discount | Value, validation, current availability and frontend effect |
| Calculation based on | Value, validation, current availability and frontend effect |
| Based on Billing Address | Value, validation, current availability and frontend effect |
| Based on Shipping Address | Value, validation, current availability and frontend effect |
| VAT introtext | Customer-facing display and email output |
| Introtext (without VAT) | Customer-facing display and email output |
| Introtext (with VAT) | Customer-facing display and email output |

### Discounts

| Historical field | Verification focus |
|---|---|
| Allowed combinations of discounts | Value, validation, current availability and frontend effect |
| Discount/voucher/coupon | Value, validation, current availability and frontend effect |
| Discount + voucher/coupon | Value, validation, current availability and frontend effect |
| Discount + voucher (single) + coupon (single) | Value, validation, current availability and frontend effect |
| Discount + voucher (multiple) + coupon (multiple) | Value, validation, current availability and frontend effect |
| Enable Coupons | Value, validation, current availability and frontend effect |
| Enable Vouchers | Value, validation, current availability and frontend effect |

### Discount mail

| Historical field | Verification focus |
|---|---|
| Send Special discount mail | Customer-facing display and email output |
| Calculate shipping based | Value, validation, current availability and frontend effect |
| Value of discount coupon is percentage or total | Value, validation, current availability and frontend effect |
| Amount | Value, validation, current availability and frontend effect |
| Send discount mail | Customer-facing display and email output |
| No of days for mail 1 After Purchase | Customer-facing display and email output |
| No of days for mail 2 After Purchase | Customer-facing display and email output |
| No of days for mail 3 After Purchase | Customer-facing display and email output |
| VAT after discount | Value, validation, current availability and frontend effect |
| Coupon Validity in Days | Value, validation, current availability and frontend effect |
