# Dashboard

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Dashboard** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Purpose

The dashboard tab configures which menu links or widgets are visible; hiding a shortcut does not uninstall the feature.

## Historical groups

The original manual includes Products, Orders, Discount, Communication, Shipping, User, Import/Export, Customization, Customer Input, Statistics, Configuration, Tools, Categories and Medias.

## Current implementation

The current `default_dashboard.php` loads the `menuhide` subtemplate. Verify individual options there and test the resulting dashboard after saving.

## Recommended layout

Keep frequently used product, order and stock views visible. Hide unsupported integrations and obsolete tools after confirming they are not needed.

## Permissions

Menu visibility must not be treated as access control. Verify Joomla ACL independently.

## Test

Save a single visibility change, reload the dashboard, check links and verify an unauthorized account cannot access restricted routes directly.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_dashboard.php`
- `component/admin/tmpl/configuration/default_menuhide.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.


## Historical field inventory — original manual audit

The following field labels were recovered from the original documentation. Their presence here preserves the original coverage; exact current UI labels and behaviour must be checked on the test installation.

### Dashboard visibility groups

| Historical field | Verification focus |
|---|---|
| Product | Value, validation, current availability and frontend effect |
| Orders | Value, validation, current availability and frontend effect |
| Discount | Value, validation, current availability and frontend effect |
| Communication | Value, validation, current availability and frontend effect |
| Shipping | Value, validation, current availability and frontend effect |
| User | Value, validation, current availability and frontend effect |
| Import/Export | Value, validation, current availability and frontend effect |
| Customization | Value, validation, current availability and frontend effect |
| Customer Input | Value, validation, current availability and frontend effect |
| Statistics | Value, validation, current availability and frontend effect |
| Configuration | Value, validation, current availability and frontend effect |
| Tool | Value, validation, current availability and frontend effect |
| Categories | Value, validation, current availability and frontend effect |
| Medias | Value, validation, current availability and frontend effect |
