# Manufacturer screenshots

Save to `manual/en-US/chapters/product-management/img/`:
- [ ] `rs506-manufacturer-list.png` — Manufacturer listing.
- [ ] `rs506-manufacturer-toolbar.png` — Toolbar and list actions.
- [ ] `rs506-manufacturer-editor.png` — Details tab including all current fields.
- [ ] `rs506-manufacturer-seo.png` — SEO tab.
- [ ] `rs506-manufacturer-product-assignment.png` — Manufacturer selection in product editor.
- [ ] `rs506-manufacturer-discount.png` — Manufacturer-based mass discount.
- [ ] `rs506-manufacturer-frontend.png` — Published manufacturer page.
