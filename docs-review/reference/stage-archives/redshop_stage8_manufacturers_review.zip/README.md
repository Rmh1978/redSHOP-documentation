# Product Management — Manufacturers

This package updates `manual/en-US/chapters/product-management/redshop-manufacturers.md`.

The article preserves all major topics from the original 2019 manual, with verified current form fields from:
- `component/admin/forms/manufacturer.xml`
- `component/admin/tmpl/manufacturer/edit.php`

The list, frontend, discount and menu workflows are described from historical documentation and require live verification. The internal tracker contains these tasks. No GitHub commit was made.
