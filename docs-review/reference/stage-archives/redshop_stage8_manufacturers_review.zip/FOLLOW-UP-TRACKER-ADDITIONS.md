# Internal follow-up: Product Management — Manufacturers

| ID | Status | Task |
| --- | --- | --- |
| DOC-8-M01 | OPEN | Confirm current manufacturer list toolbar, filters, columns and copy/delete/check-in behaviour. |
| DOC-8-M02 | OPEN | Verify manufacturer form fields, required template selection and default products-per-page on test site. |
| DOC-8-M03 | OPEN | Confirm manufacturer image upload and alt text behaviour. |
| DOC-8-M04 | OPEN | Verify SEO values in generated frontend metadata and routing. |
| DOC-8-M05 | OPEN | Test product-to-manufacturer assignment and listing pagination. |
| DOC-8-M06 | OPEN | Test manufacturer mass discounts and priority against product discounts. |
| DOC-8-M07 | OPEN | Identify supported manufacturer template tags and verify product-page manufacturer-name tag. |
| DOC-8-M08 | OPEN | Confirm available Joomla manufacturer menu item types and labels. |
| DOC-8-M09 | OPEN | Confirm manufacturer email notification trigger and delivery. |
| DOC-8-M10 | OPEN | Capture seven screenshots. |
