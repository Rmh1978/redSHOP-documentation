# VAT/Tax & Currency

Use [Currency](currency.md) to define currencies, [VAT/Tax Group](vat-group.md) to group tax rates, and [VAT/Tax Rate](vat-rate.md) to assign rates by tax group and location.

## Recommended configuration sequence

1. Create or confirm the currency.
2. Create the tax group.
3. Create one or more tax rates, selecting the applicable shopper group, country, state and EU setting.
4. Review the shop's global VAT calculation settings.
5. Test private and company customers, billing versus shipping addresses, discounted orders and tax-exempt cases.

**Warning:** Tax rules are jurisdiction-specific. This documentation describes redSHOP configuration and is not tax or legal advice. Do not infer legal correctness from a successfully calculated checkout total.
