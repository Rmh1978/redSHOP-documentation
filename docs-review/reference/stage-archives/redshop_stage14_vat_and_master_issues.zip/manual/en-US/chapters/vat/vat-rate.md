# VAT/Tax Rate

> **Documentation review draft.** Historical content inventory is cross-checked against the current administrator XML form on `develop`; calculation behaviour is not yet verified.

## Purpose

Use the redSHOP administrator to configure vat/tax rate records. Verify the configured result with test orders before changing production tax or currency settings.

## Original manual field reference

| Field | Explanation | Status |
|---|---|---|
| Name | Rate name | Original manual; confirm runtime |
| Group | Linked VAT/Tax group | Original manual; confirm runtime |
| Country | Country condition | Original manual; confirm runtime |
| State | Region condition | Original manual; confirm runtime |
| Amount | Tax percentage or amount; verify unit | Original manual; confirm runtime |
| EU Country | EU classification setting | Original manual; confirm runtime |

## Confirmed current form fields

`name`, `tax_group_id`, `shopper_group`, `tax_country`, `tax_state`, `tax_rate`, `is_eu_country`.

**Important difference:** The current form includes a required `shopper_group` field, which is not in the original manual field list. Verify how shopper-group restrictions interact with country, state and EU mode.

## Administrator workflow

1. Create a tax group and then a rate linked to it.
2. Configure country and optional state conditions.
3. Test matching and nonmatching billing/shipping addresses.
4. Check the same cart with a shopper group and a discount.

## Listing and edit actions

The historical guide covers list/detail screens and the actions New, Delete, Check-in, Save, Save & Close, Save & New and Cancel where applicable. Verify Publish/Unpublish and the available toolbar actions in the current Joomla administrator.

## Validation checklist

- [ ] Verify required fields and error messages
- [ ] Save and reopen the record to confirm persistence
- [ ] Verify currency or VAT effect on product detail, cart and order totals
- [ ] Confirm that changing configuration does not retroactively alter completed orders
- [ ] Check Joomla 5 and Joomla 6 administrator behaviour

## Source references

- Original documentation: `manual/en-US/chapters/vat/vat-rate.md` (`gh-pages`)
- Current form: `component/admin/forms/taxrate.xml` (`develop`)
