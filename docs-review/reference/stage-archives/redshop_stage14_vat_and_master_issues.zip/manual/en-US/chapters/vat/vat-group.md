# VAT/Tax Group

> **Documentation review draft.** Historical content inventory is cross-checked against the current administrator XML form on `develop`; calculation behaviour is not yet verified.

## Purpose

Use the redSHOP administrator to configure vat/tax group records. Verify the configured result with test orders before changing production tax or currency settings.

## Original manual field reference

| Field | Explanation | Status |
|---|---|---|
| VAT/Tax Group Name | Tax-group identifier | Original manual; confirm runtime |
| Published | Availability of group | Original manual; confirm runtime |
| Tax Rate | Associated rates shown in the listing | Original manual; confirm runtime |
| ID | Internal record identifier | Original manual; confirm runtime |

## Confirmed current form fields

`name`, `published`.

## Administrator workflow

1. Create a named published tax group.
2. Assign a test tax rate to the group.
3. Confirm the group is available in product and shop tax settings.

## Listing and edit actions

The historical guide covers list/detail screens and the actions New, Delete, Check-in, Save, Save & Close, Save & New and Cancel where applicable. Verify Publish/Unpublish and the available toolbar actions in the current Joomla administrator.

## Validation checklist

- [ ] Verify required fields and error messages
- [ ] Save and reopen the record to confirm persistence
- [ ] Verify currency or VAT effect on product detail, cart and order totals
- [ ] Confirm that changing configuration does not retroactively alter completed orders
- [ ] Check Joomla 5 and Joomla 6 administrator behaviour

## Source references

- Original documentation: `manual/en-US/chapters/vat/vat-group.md` (`gh-pages`)
- Current form: `component/admin/forms/taxgroup.xml` (`develop`)
