# Currency

> **Documentation review draft.** Historical content inventory is cross-checked against the current administrator XML form on `develop`; calculation behaviour is not yet verified.

## Purpose

Use the redSHOP administrator to configure currency records. Verify the configured result with test orders before changing production tax or currency settings.

## Original manual field reference

| Field | Explanation | Status |
|---|---|---|
| Currency | Currency display name | Original manual; confirm runtime |
| Currency code | ISO-style code used by redSHOP | Original manual; confirm runtime |
| ID | Internal record identifier | Original manual; confirm runtime |

## Confirmed current form fields

`name`, `code`.

## Administrator workflow

1. Create a currency with a distinct code.
2. Select it in Global Configuration where applicable.
3. Check storefront price formatting and checkout currency.

## Listing and edit actions

The historical guide covers list/detail screens and the actions New, Delete, Check-in, Save, Save & Close, Save & New and Cancel where applicable. Verify Publish/Unpublish and the available toolbar actions in the current Joomla administrator.

## Validation checklist

- [ ] Verify required fields and error messages
- [ ] Save and reopen the record to confirm persistence
- [ ] Verify currency or VAT effect on product detail, cart and order totals
- [ ] Confirm that changing configuration does not retroactively alter completed orders
- [ ] Check Joomla 5 and Joomla 6 administrator behaviour

## Source references

- Original documentation: `manual/en-US/chapters/vat/currency.md` (`gh-pages`)
- Current form: `component/admin/forms/currency.xml` (`develop`)
