# Stage 14 screenshots

- [ ] Currency list and edit form
- [ ] VAT group list and edit form
- [ ] VAT rate list and edit form including shopper group
- [ ] Global VAT settings
- [ ] Checkout with taxable and exempt customer
