# redSHOP — shared master issue and gap register

**Status:** Consolidated working register for stages 1–13, generated from available local follow-up trackers and the stage 11/12 master files. No item has been marked resolved without evidence. This is not a list of confirmed software bugs.

Imported **310 task occurrences** from **23 source files**, grouped into **237 distinct text-normalized tasks**. Similar-but-not-identical tasks can still overlap. Source file names are retained for traceability.

## Master register

| ID | Status | Task / verification | Source tracker(s) |
|---|---|---|---|
| M-0001 | OPEN | 11 — High — Shipping rate calculation and provider integration runtime tests | redshop_stage12_discounts/MASTER-ISSUES-AND-GAPS.md |
| M-0002 | OPEN | 12 — High — Coupon/voucher usage limits and expiry behaviour not verified | redshop_stage12_discounts/MASTER-ISSUES-AND-GAPS.md |
| M-0003 | OPEN | 12 — High — Discount stacking and calculation order not verified | redshop_stage12_discounts/MASTER-ISSUES-AND-GAPS.md |
| M-0004 | OPEN | 12 — High — Gift card lifecycle and refund handling not verified | redshop_stage12_discounts/MASTER-ISSUES-AND-GAPS.md |
| M-0005 | OPEN | 12 — High — Promotion plugin awards and stock handling not verified | redshop_stage12_discounts/MASTER-ISSUES-AND-GAPS.md |
| M-0006 | OPEN | 12 — Medium — Original screenshots require replacement | redshop_stage12_discounts/MASTER-ISSUES-AND-GAPS.md |
| M-0007 | OPEN | 12 — Medium — XML form fields may differ from dynamic edit view | redshop_stage12_discounts/MASTER-ISSUES-AND-GAPS.md |
| M-0008 | OPEN | 1–11 — High — Joomla 6 regression checks outstanding | redshop_stage12_discounts/MASTER-ISSUES-AND-GAPS.md |
| M-0009 | OPEN | 1–11 — Medium — Screenshots not verified on current admin UI | redshop_stage12_discounts/MASTER-ISSUES-AND-GAPS.md |
| M-0010 | OPEN | 1–5 — High — Full original-to-current field and workflow audit incomplete | redshop_stage12_discounts/MASTER-ISSUES-AND-GAPS.md |
| M-0011 | OPEN | `cart.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage4/FOLLOW-UP-TRACKER.md |
| M-0012 | OPEN | `categories/overview-category.md` — Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions | redshop_004_phase6_8/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0013 | OPEN | `categories/redshop-categories.md` — Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions | redshop_004_phase6_8/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0014 | OPEN | `dashboard.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage5/FOLLOW-UP-TRACKER.md |
| M-0015 | OPEN | `feature-settings.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage4/FOLLOW-UP-TRACKER.md |
| M-0016 | OPEN | `general.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage3/FOLLOW-UP-TRACKER.md |
| M-0017 | OPEN | `global-configuration/about.md` — Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions | redshop_004_phase6_8/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0018 | OPEN | `global-configuration/categories.md` — Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions | redshop_004_phase6_8/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0019 | OPEN | `global-configuration/manufacturers.md` — Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions | redshop_004_phase6_8/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0020 | OPEN | `global-configuration/newsletter.md` — Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions | redshop_004_phase6_8/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0021 | OPEN | `global-configuration/start-here.md` — Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions | redshop_004_phase6_8/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0022 | OPEN | `integration.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage5/FOLLOW-UP-TRACKER.md |
| M-0023 | OPEN | `orders.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage4/FOLLOW-UP-TRACKER.md |
| M-0024 | OPEN | `overview-global-configuration.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage3/FOLLOW-UP-TRACKER.md |
| M-0025 | OPEN | `price.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage3/FOLLOW-UP-TRACKER.md |
| M-0026 | OPEN | `product-management/overview-product-management.md` — Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions | redshop_004_phase6_8/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0027 | OPEN | `product-management/products-redshop.md` — Verify exact admin navigation, field labels, behaviour and screenshot on test site; expand field-level instructions | redshop_004_phase6_8/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0028 | OPEN | `products.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage3/FOLLOW-UP-TRACKER.md |
| M-0029 | OPEN | `redshop-configuration-wizard.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage2/FOLLOW-UP-TRACKER.md |
| M-0030 | OPEN | `redshop-main-menu.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage2/FOLLOW-UP-TRACKER.md |
| M-0031 | OPEN | `redshop-navigation-panel.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage2/FOLLOW-UP-TRACKER.md |
| M-0032 | OPEN | `seo.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage5/FOLLOW-UP-TRACKER.md |
| M-0033 | OPEN | `user.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots | redshop_stages2_to5_deep_revision/stage3/FOLLOW-UP-TRACKER.md |
| M-0034 | OPEN | all phases 1–3 — Capture and review screenshots; verify labels on Joomla 5.4 | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |
| M-0035 | OPEN | all phases 1–3 — Check rendered documentation links and image paths in site generator | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |
| M-0036 | OPEN | all six — Capture screenshots from redSHOP 5.0.6 test site; replace image placeholders | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0037 | OPEN | all six — Joomla 6 compatibility testing before claiming support | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0038 | OPEN | all six — Verify menu labels and frontend behavior on Joomla 5.4 | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0039 | OPEN | Audit original 2019 product article field-by-field to ensure no still-relevant advanced fields were omitted from the rewritten draft | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0040 | OPEN | Audit shipping-rate jQuery and Joomla.submitbutton for Joomla 6 | redshop_stage11_shipping/MASTER-ISSUES-AND-GAPS.md |
| M-0041 | OPEN | Capture 10 screenshots and validate all relative documentation links | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0042 | OPEN | Capture 11 screenshots and check article links | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_supplier_products/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0043 | OPEN | Capture 15 screenshots and verify relative links against actual docs tree | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0044 | OPEN | Capture 16 current screenshots and check docs relative paths | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0045 | OPEN | Capture all screenshot placeholders and verify rendered links | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0046 | OPEN | Capture and review three screenshots from `/tests/redshop6` | redshop_phase6_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0047 | OPEN | Capture and verify shipping screenshots and internal links | redshop_stage11_shipping/MASTER-ISSUES-AND-GAPS.md |
| M-0048 | OPEN | Capture eight screenshots | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0049 | OPEN | Capture seven screenshots | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0050 | OPEN | Capture seven screenshots and check mobile readability | redshop_phase6_final/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0051 | OPEN | Capture seven screenshots and verify article links | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_price_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0052 | OPEN | Capture three screenshots from `/tests/redshop6` and check labels | redshop_phase6_newsletter/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0053 | OPEN | cart.md — Confirm cart timeout unit and actual expiration behavior | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0054 | OPEN | cart.md — Document checkout variants, AJAX cart and payment/shipping interaction with examples | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0055 | OPEN | cart.md — Verify minimum order total calculation with VAT, discounts and shipping | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0056 | OPEN | Category ordering — Check exact ordering choices and whether newest means creation or publishing date | redshop_phase6_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0057 | OPEN | Check all Product Information fields, validation, date/time handling and tax labels in the test UI | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0058 | OPEN | Check default newsletter selection, template output, sender and reply-to headers | redshop_phase6_newsletter/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0059 | OPEN | Check internal links, images and cross-references | redshop_stage1_reaudit/FOLLOW-UP-TRACKER.md |
| M-0060 | OPEN | Check order-list jQuery/custom JS for Joomla 6 compatibility | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0061 | OPEN | Check price editor quantity range validation, discount price constraints and decimal input | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_price_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0062 | OPEN | Check shipping VAT and mixed tax rates | redshop_stage11_shipping/MASTER-ISSUES-AND-GAPS.md |
| M-0063 | OPEN | Check stock-image listing search and filtering against current UI | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0064 | OPEN | Check user and shopper-group editor compatibility with Joomla 6 | stage13/users |
| M-0065 | OPEN | Check whether empty module/plugin lists hide their entire tables and whether docs need a note | redshop_phase6_final/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0066 | OPEN | Compare all category listing columns, toolbar actions and check-in behaviour with redSHOP 5.0.6 | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0067 | OPEN | Compare current product list columns, toolbar and bulk category actions with the historical manual | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0068 | OPEN | Compare every original Shipping Methods field and action against current editor | redshop_stage11_shipping/MASTER-ISSUES-AND-GAPS.md |
| M-0069 | OPEN | Confirm `{product_stock_amount_image}` is supported by current template parser and test with in-stock/out-of-stock rules | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0070 | OPEN | Confirm availability of Joomla extension update channel and required download key | redshop_stage1_reaudit/FOLLOW-UP-TRACKER.md |
| M-0071 | OPEN | Confirm available Joomla category menu item types and labels | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0072 | OPEN | Confirm available Joomla manufacturer menu item types and labels | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0073 | OPEN | Confirm category-level accessory pricing precedence against product-specific accessory rules | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0074 | OPEN | Confirm check-in works after abandoned editing session | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_supplier_products/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0075 | OPEN | Confirm current manufacturer list toolbar, filters, columns and copy/delete/check-in behaviour | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0076 | OPEN | Confirm current Orders list columns and toolbar actions | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0077 | OPEN | Confirm custom Stock Option choices and comparison semantics | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0078 | OPEN | Confirm data protection and unsubscribe behaviour in subscriber management; document separately in communication chapter | redshop_phase6_newsletter/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0079 | OPEN | Confirm default status count and uniqueness of status codes | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0080 | OPEN | Confirm deletion behaviour for stockroom and stock image records | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0081 | OPEN | Confirm global-vs-record-specific override examples for each related section during later article reviews | redshop_phase6_final/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0082 | OPEN | Confirm historical plus-icon modal exists and is compatible with Joomla 5 | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_price_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0083 | OPEN | Confirm installed/published indicators accurately reflect Joomla extension state, including disabled plugins | redshop_phase6_final/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0084 | OPEN | Confirm manufacturer email notification trigger and delivery | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0085 | OPEN | Confirm manufacturer image upload and alt text behaviour | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0086 | OPEN | Confirm mapping of all three manufacturer product thumbnail dimension pairs to frontend layouts and image cache behaviour | redshop_phase6_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0087 | OPEN | Confirm print action and whether export is supported | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0088 | OPEN | Confirm product custom-field display and available editor tabs | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0089 | OPEN | Confirm redPRODUCTFINDER integration availability and UI | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0090 | OPEN | Confirm Save + Pay / Save without Email / Save & Close email semantics | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0091 | OPEN | Confirm Save / Save & Close / Save & New / Close in current supplier editor | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_supplier_products/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0092 | OPEN | Confirm visibility of dependent settings when newsletter is disabled and enabled | redshop_phase6_newsletter/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0093 | OPEN | Confirm whether Configuration Wizard, Install Demo Content and Cancel still appear | redshop_stage1_reaudit/FOLLOW-UP-TRACKER.md |
| M-0094 | OPEN | Confirm whether historical Custom Fields and Accessories tabs remain, have moved or were removed. Do not describe them as confirmed current UI | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0095 | OPEN | dashboard.md — Confirm current menu visibility list and behavior under restricted Joomla ACL | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0096 | OPEN | Discontinued products — Confirm storefront template handling of the discontinued-product message | redshop_phase6_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0097 | OPEN | feature-settings.md — Test review submission and wishlist behavior for guests and registered customers | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0098 | OPEN | feature-settings.md — Verify stock deduction, reservation and notification scenarios | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0099 | OPEN | feature-settings.md — Verify where inline editing works in administrator UI | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0100 | OPEN | general — Test statistics, product reservation and shipping-address settings | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |
| M-0101 | OPEN | general — Verify all configuration tabs, general settings, upload-size units and image resizing | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |
| M-0102 | OPEN | Identify supported manufacturer template tags and verify product-page manufacturer-name tag | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0103 | OPEN | Image configuration — Locate and verify lightbox, watermark, default image and out-of-stock image settings in the current configuration UI | redshop_phase6_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0104 | OPEN | Inspect actual category SEO XML fieldset and generated frontend metadata | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0105 | OPEN | Inspect current `medium` editor fields and supported media types; verify video and YouTube support | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0106 | OPEN | Inspect package manifest, installer scripts, database migrations and post-install screen | redshop_stage1_reaudit/FOLLOW-UP-TRACKER.md |
| M-0107 | OPEN | installation — Verify clean installation, bundled extensions and installer result screens | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |
| M-0108 | OPEN | integration.md — Separate supported integrations from legacy UI sections; verify provider API compatibility | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0109 | OPEN | integration.md — Write dedicated setup guides for Billy, Flatpay, Bambora, PostNord and Relatel where applicable | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0110 | OPEN | Locate current Product Order Search route and filters | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0111 | OPEN | Locate current product supplier field and verify supplier association storage | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_supplier_products/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0112 | OPEN | orders.md — Confirm order/invoice numbering and free-order invoice behavior | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0113 | OPEN | orders.md — Verify order email timing for successful, failed and delayed payments | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0114 | OPEN | Pagination overrides — Confirm which Joomla menu/category settings override the global category count | redshop_phase6_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0115 | OPEN | Perform field-by-field original-content audit (especially Add Order) | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0116 | OPEN | Perform field-by-field original-content audit and verify rendered links | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0117 | OPEN | Previous/Next navigation — Verify whether all legacy controls still appear in redSHOP 5.0.6 and whether the active frontend templates consume them | redshop_phase6_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0118 | OPEN | price — Verify VAT calculations, tax-exempt pricing, coupon stacking and discount emails | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |
| M-0119 | OPEN | products — Verify download storage access, limits, product templates and catalogue features | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |
| M-0120 | OPEN | Replace outdated user screenshots and verify links | stage13/users |
| M-0121 | OPEN | requirements — Confirm supported Joomla/PHP/database matrix and Joomla 6 upgrade test | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |
| M-0122 | OPEN | Review `component/admin/tmpl/price/edit.php`: JavaScript validates `form.productprice`, but field is `product_price`; `form.discount_price` check may be reversed | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_price_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0123 | OPEN | Review `MediaModel::delete` and `MediumTable::doDelete` for deletion side effects, shared-file safety, and transaction consistency | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0124 | OPEN | Review Discount Calculator units, dimension handling and discount precedence | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0125 | OPEN | Review historical tutorial video URLs for continued availability before adding links | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_price_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0126 | OPEN | Review historical tutorial videos before linking publicly | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_supplier_products/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0127 | OPEN | Review historical video links before reuse | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0128 | OPEN | Review Joomla 6 compatibility of stockroom admin JavaScript | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0129 | OPEN | Review original Fleeq tutorial links before reuse | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0130 | OPEN | Review original pages for historical details not yet represented | redshop_stage1_reaudit/FOLLOW-UP-TRACKER.md |
| M-0131 | OPEN | Review original tutorial video links for accessibility and version relevance before considering reuse | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0132 | OPEN | Review original tutorial videos for relevance and availability | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0133 | OPEN | Review upload validation, MIME/extension checks, and file access permissions | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0134 | OPEN | Screenshots — Capture and check seven images; remove any legacy-only references that no longer apply | redshop_phase6_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0135 | OPEN | Security-test Order Tracker authorization | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0136 | OPEN | seo.md — Test Joomla SEF, category paths, multilingual routes and redirects | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0137 | OPEN | seo.md — Verify placeholder syntax and available tokens in each metadata field | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md, redshop004_phase4_5_revised/FOLLOW-UP-TRACKER.md |
| M-0138 | OPEN | Template precedence — Verify category-specific template override precedence | redshop_phase6_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0139 | OPEN | Test additional image publishing and media gallery output | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0140 | OPEN | Test attribute-set copy; source contains `task==product.ajaxDisplayAttributeSet` and may require a fix | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0141 | OPEN | Test attribute/subproperty price calculations and required selection | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0142 | OPEN | Test bulk status changes and customer notification flag | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0143 | OPEN | Test category editor fields, per-category template overrides and allowed-template selector tag | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0144 | OPEN | Test category image media record creation and association | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0145 | OPEN | Test category wrapping and shipping-rate restrictions, including mixed-category carts | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0146 | OPEN | Test clean install and upgrade on isolated redshop6 clone | redshop_stage1_reaudit/FOLLOW-UP-TRACKER.md |
| M-0147 | OPEN | Test confirmation workflow, email content, subscription state and confirmation links on redSHOP 5.0.6 | redshop_phase6_newsletter/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0148 | OPEN | Test copy operation and generated unique supplier name | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_supplier_products/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0149 | OPEN | Test date, order status and payment status filters | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0150 | OPEN | Test discount date handling, timezone and empty date semantics | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_price_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0151 | OPEN | Test downloadable-product access, limits and file storage; verify protection against direct file access | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0152 | OPEN | Test dynamic product rows, attributes, discounts and VAT | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0153 | OPEN | Test frontend Quote menu and quotation-to-order conversion | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0154 | OPEN | Test individual payment-method restrictions, including mixed-product carts | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0155 | OPEN | Test main product image and additional image workflow, including default media | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0156 | OPEN | Test manual order for existing customer | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0157 | OPEN | Test manufacturer and supplier email delivery using safe test accounts; confirm event/trigger and templates | redshop_phase6_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0158 | OPEN | Test manufacturer mass discounts and priority against product discounts | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0159 | OPEN | Test manufacturer media association and deletion restrictions | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0160 | OPEN | Test manufacturer-specific template override precedence | redshop_phase6_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0161 | OPEN | Test media type and media section filtering, including item-specific popup | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0162 | OPEN | Test new media upload and association with a product | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0163 | OPEN | Test new Product Filters tab, supported fields, frontend template integration and attribute selection | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0164 | OPEN | Test new-customer account creation and password security | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0165 | OPEN | Test overlapping shopper-group quantity ranges and rule precedence | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_price_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0166 | OPEN | Test preorder quantities and reset without affecting real orders | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0167 | OPEN | Test product, property and subproperty inventory save | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0168 | OPEN | Test product-to-manufacturer assignment and listing pagination | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0169 | OPEN | Test product/country and shopper-group rate scenarios | redshop_stage11_shipping/MASTER-ISSUES-AND-GAPS.md |
| M-0170 | OPEN | Test quick-price save task `saveprice` versus `productprice.saveprice` | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_price_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0171 | OPEN | Test reusing one file across multiple product records without overwriting an existing association | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0172 | OPEN | Test rollback from a real database migration | redshop_stage1_reaudit/FOLLOW-UP-TRACKER.md |
| M-0173 | OPEN | Test search by order ID, order number, name, email and phone | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0174 | OPEN | Test shopper-group category visibility and administrative access controls | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0175 | OPEN | Test status changes from list, editor and dashboard | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0176 | OPEN | Test subscriptions, renewals and serial-number delivery where configured | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0177 | OPEN | Test unique username/email, password security and error messages | stage13/users |
| M-0178 | OPEN | Test unpublished supplier behaviour on product page | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_supplier_products/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0179 | OPEN | Test weight, volume, dimension and postal-code boundaries | redshop_stage11_shipping/MASTER-ISSUES-AND-GAPS.md |
| M-0180 | OPEN | Text shortening — Test suffix behavior, zero/empty limits and multibyte characters in storefront templates | redshop_phase6_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0181 | OPEN | Trace newsletter test button submission (`task=apply`) through controller/model to verify whether and when a test message is actually sent | redshop_phase6_newsletter/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0182 | OPEN | updating — Verify update server, download-key UI, manual ZIP update and migration from legacy releases | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |
| M-0183 | OPEN | user — Test registration methods, verification emails, portal restrictions and shopper group assignments | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |
| M-0184 | OPEN | Verify `{supplier_name}` template tag is still processed by current product template engine | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_supplier_products/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0185 | OPEN | Verify About tab's four panels and visible labels on `/tests/redshop6` | redshop_phase6_final/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0186 | OPEN | Verify accounting integration field mapping | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0187 | OPEN | Verify active carrier plugins and provider API compatibility | redshop_stage11_shipping/MASTER-ISSUES-AND-GAPS.md |
| M-0188 | OPEN | Verify actual current redSHOP 5.0.6 supported Joomla/PHP/database versions against release metadata and tests | redshop_stage1_reaudit/FOLLOW-UP-TRACKER.md |
| M-0189 | OPEN | Verify actual dropdown choices for manufacturer ordering and manufacturer product ordering on redSHOP 5.0.6 | redshop_phase6_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0190 | OPEN | Verify batch size and pause settings are used by the actual newsletter sending process, including error and timeout handling | redshop_phase6_newsletter/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0191 | OPEN | Verify current CSV/XML import/export workflow, formats and category parent mapping | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0192 | OPEN | Verify current Product Price Management screen and search controls | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_price_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0193 | OPEN | Verify current Product Price Management workflow and shopper-group quantity rules | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0194 | OPEN | Verify current text-library integration and custom-field output | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0195 | OPEN | Verify deletion side effects and retention requirements | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0196 | OPEN | Verify exact Configuration entry point, tab names and ordering on redSHOP 5.0.6 | redshop_phase6_final/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0197 | OPEN | Verify exact Media navigation labels and available list toolbar actions | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0198 | OPEN | Verify exact New/Edit/Delete toolbar actions on price-rule listing | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_price_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0199 | OPEN | Verify frontend Orders menu, Reorder warning and one-step checkout | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0200 | OPEN | Verify historic category template tags and frontpage/product-category layouts | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0201 | OPEN | Verify historical Inventory **Export Data** CSV action and its columns; current listing explicitly shows print | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0202 | OPEN | Verify Joomla 6 support; do not claim it without test evidence | redshop_stage1_reaudit/FOLLOW-UP-TRACKER.md |
| M-0203 | OPEN | Verify manufacturer form fields, required template selection and default products-per-page on test site | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0204 | OPEN | Verify mass discount and product price discount fields, ordering and shopper-group rules | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0205 | OPEN | Verify mass discounts, product-price discounts and shopper-group precedence on test orders | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0206 | OPEN | Verify media manager category assignments and image cache behaviour | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0207 | OPEN | Verify minimum-stock threshold behaviour | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0208 | OPEN | Verify notification, shipping and payment plugin side effects | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0209 | OPEN | Verify parent/unpublished-child behaviour and category deletion/copy handling | redshop_phase7_categories/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0210 | OPEN | Verify PDF print and CSV/full CSV/GLS/GLS Business exports | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0211 | OPEN | Verify private and company account registration, edit and checkout flows | stage13/users |
| M-0212 | OPEN | Verify product download root isolation from public media paths | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0213 | OPEN | Verify product SEO fieldset, SEF URLs and generated metadata | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0214 | OPEN | Verify product vs category accessory precedence and related-product rendering | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_product_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0215 | OPEN | Verify property and subproperty image selection and storefront behaviour | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_media/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0216 | OPEN | Verify quotation Send email behaviour | redshop_stage10_orders/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0217 | OPEN | Verify rate model persistence and rule precedence | redshop_stage11_shipping/MASTER-ISSUES-AND-GAPS.md |
| M-0218 | OPEN | Verify relative Markdown links render correctly in the published documentation site | redshop_phase6_final/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0219 | OPEN | Verify SEO values in generated frontend metadata and routing | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0220 | OPEN | Verify server-information values on the running site; redact sensitive details in screenshots | redshop_phase6_final/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0221 | OPEN | Verify shared admin list layout columns and toolbar actions in Joomla 5 test installation | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_supplier_products/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0222 | OPEN | Verify shipping box form fields and matching algorithm | redshop_stage11_shipping/MASTER-ISSUES-AND-GAPS.md |
| M-0223 | OPEN | Verify shopper group price, VAT, catalog, quotation and shipping overrides | stage13/users |
| M-0224 | OPEN | Verify stock image template tags and frontend output | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0225 | OPEN | Verify stockroom delivery-time output on frontend | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0226 | OPEN | Verify Stockroom List Inventory, Copy, Publish, Unpublish and search controls | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0227 | OPEN | Verify stockroom list toolbar and actions on redshop6 | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0228 | OPEN | Verify stockroom totals shown in the inventory listing | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0229 | OPEN | Verify storefront unit prices, subtotal, tax and checkout for quantity boundary cases | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_price_management/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0230 | OPEN | Verify supplier deletion impact on product associations and database constraints | redshop_stage8_consolidated/CONSOLIDATED-FOLLOW-UP-TRACKER.md, redshop_stage8_supplier_products/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0231 | OPEN | Verify tax exemption approval and access control | stage13/users |
| M-0232 | OPEN | Verify the historical `redSHOP Stockroom Status notice for admin` plugin and whether minimum-stock notifications are still supported | redshop_stage9_stockroom/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0233 | OPEN | Verify title truncation and suffix behaviour in active frontend templates | redshop_phase6_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0234 | OPEN | Verify watermark application and required watermark image configuration | redshop_phase6_manufacturers/FOLLOW-UP-TRACKER-ADDITIONS.md |
| M-0235 | OPEN | Verify wrapping assignment, frontend display and price calculation | redshop_stage11_shipping/MASTER-ISSUES-AND-GAPS.md |
| M-0236 | OPEN | wizard — Confirm wizard entry point, step navigation, field labels and save behavior | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |
| M-0237 | OPEN | wizard — Test all registration methods, terms and invoice-email settings | redshop004_phase1_3_revised/FOLLOW-UP-TRACKER.md |

## Stage 14 — newly identified issues

| ID | Priority | Status | Finding |
|---|---|---|---|
| VAT-001 | High | OPEN | Verify VAT calculation base: billing vs shipping address and EU mode |
| VAT-002 | High | OPEN | Verify shopper-group condition on tax rates; absent from historical VAT-rate manual |
| VAT-003 | High | OPEN | Test tax-exempt and company VAT approval end-to-end |
| VAT-004 | High | OPEN | Check tax rounding with discounts, shipping and order totals |
| VAT-005 | High | OPEN | Verify currency conversion, precision and completed-order immutability |
| VAT-006 | Medium | OPEN | Replace screenshots for Currency, VAT Group and VAT Rate |
| VAT-007 | Medium | OPEN | Verify current toolbar, publishing and validation of tax rates |
