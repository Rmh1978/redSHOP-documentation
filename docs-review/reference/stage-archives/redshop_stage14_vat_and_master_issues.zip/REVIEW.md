# Stage 14 — VAT/Tax & Currency

Four English articles prepared. Historical fields from three original guides cross-checked against current XML forms `currency.xml`, `taxgroup.xml`, and `taxrate.xml`.

**New important difference:** `taxrate.xml` requires a shopper group, which the original VAT-rate field list did not mention.

Source verification is limited to form declarations. No tax-calculation code review, staging test, legal/tax review, or screenshot verification has been completed.

The master issue register carries forward every stage-13 item with unchanged IDs and appends seven stage-14 issues.
