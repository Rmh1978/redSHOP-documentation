# Internal follow-up additions — Phase 6, Categories

| ID | Status | Topic | Action |
| --- | --- | --- | --- |
| P6-CAT-01 | OPEN | Previous/Next navigation | Verify whether all legacy controls still appear in redSHOP 5.0.6 and whether the active frontend templates consume them. |
| P6-CAT-02 | OPEN | Image configuration | Locate and verify lightbox, watermark, default image and out-of-stock image settings in the current configuration UI. |
| P6-CAT-03 | OPEN | Category ordering | Check exact ordering choices and whether newest means creation or publishing date. |
| P6-CAT-04 | OPEN | Pagination overrides | Confirm which Joomla menu/category settings override the global category count. |
| P6-CAT-05 | OPEN | Discontinued products | Confirm storefront template handling of the discontinued-product message. |
| P6-CAT-06 | OPEN | Text shortening | Test suffix behavior, zero/empty limits and multibyte characters in storefront templates. |
| P6-CAT-07 | OPEN | Template precedence | Verify category-specific template override precedence. |
| P6-CAT-08 | OPEN | Screenshots | Capture and check seven images; remove any legacy-only references that no longer apply. |
