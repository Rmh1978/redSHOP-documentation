# redSHOP documentation — Phase 6, article 1

This is a full-length revision of `manual/en-US/chapters/global-configuration/categories.md` based on the original documentation and current redSHOP configuration templates. It restores substantive material omitted from the earlier short draft.

Public documentation is separated from the internal follow-up tracker. No GitHub files have been modified.

**Scope:** Only the Categories configuration article. Other Phase 6 articles will follow after equivalent source review.

**Source review:** `component/admin/tmpl/configuration/default_category.php`, `default_category_suffix.php`, `default_category_template.php` on `develop`, and original `manual/en-US/chapters/global-configuration/categories.md` on `gh-pages`.

**Review caveat:** Current UI behavior for the historical navigation/image panels remains to be verified. Do not mark this article as fully UI-validated until follow-up items are closed.
