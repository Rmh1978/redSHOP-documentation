# Category configuration

The **Categories** settings in redSHOP control how categories are ordered and displayed in the storefront, how long category and product text may appear in category layouts, which templates are used, and how category images are presented.

To review these settings, sign in to the Joomla administrator, open **Components → redSHOP → Configuration**, and select the **Categories** section. Change the required settings and save the configuration. Check the relevant storefront pages after making changes, especially if your site uses custom redSHOP templates.

![Category configuration overview](img/rs506-config-categories-overview.png)

## Main category settings

![Main category settings](img/rs506-config-categories-main.png)

### Default category sorting

**Default Category Sorting** determines the initial ordering of categories in category listings. The original redSHOP documentation describes three ordering choices:

- **Category:** Sort categories alphabetically by name.
- **Newest:** Display newer categories first.
- **Order:** Use the ordering assigned to categories in the administrator.

The storefront may offer a sorting control that allows customers to change the displayed order. The available choices depend on the active layout. The global default can also be affected by category-specific menu or layout settings.

### Number of categories per page

**No. of Categories per Page** sets the general limit on categories displayed on one listing page. For example, a limit of nine with twelve matching categories normally requires more than one page. Some category menu items or layouts may override this value.

Choose a number that suits the layout and check that pagination works with the site's template.

### Discontinued-product message

**Enter Message You Want to Give When a Product Is Discontinued** stores the text shown for products marked as discontinued. The message can explain that an item is no longer available or direct customers to alternatives. Whether and where it appears depends on the storefront product template.

### Front-page category introduction

**Front Page Category Page Introtext** stores introductory content for the top-level category page. A front-page category template can render the content with the redSHOP template tag `{category_frontpage_introtext}`. For example, the introduction might describe the store's product ranges or help visitors choose a category.

After saving, check the top-level category page. The introduction will not necessarily appear unless the selected template includes the corresponding tag.

## Previous, next, and return links

![Category navigation link settings](img/rs506-config-categories-navigation.png)

The legacy configuration describes controls for the links used to move between catalog pages and return to a category. These controls are relevant when the active storefront layout renders the corresponding navigation links.

### Return to category prefix

**Prefix for Return to Category** adds text or characters before the return link. For example, a prefix such as `« ` can produce a link resembling `« Return to Category`.

### Default previous and next text

**Prefix for Default Text Link to Previous** adds characters before the default Previous label. **Suffix for Default Text Link to Next** adds characters after the default Next label. These additions apply to the default text-link presentation, not necessarily to custom text or image links.

### Custom previous and next labels

**Custom Link to Previous** and **Custom Link to Next** let you supply alternative labels, such as “Earlier products” and “More products”. Select the custom-link presentation when available to use these labels.

### Previous and next images

**Upload Your Image for Link to Previous Page** and **Image for Link to Next** specify images for image-based navigation. Upload suitable images, save the configuration, and inspect the storefront to verify the links remain clear and usable. Provide accessible text in the storefront template when image links are used.

### Navigation link type

The historical manual describes three presentations for **Default Type of Link to Previous/Next**:

| Link type | Display |
| --- | --- |
| Default Link | Standard Previous and Next text, with the configured prefix or suffix |
| Custom Link | Administrator-defined previous and next labels |
| Image Link | Uploaded navigation images |

These navigation controls are retained here because they form part of the original category configuration guide. Their presence in a particular redSHOP 5.0.6 administrator screen should be checked before replacing the associated screenshots.

## Category and product text lengths

![Category text length and suffix settings](img/rs506-config-categories-suffixes.png)

Category listings may have limited room for titles and descriptions. The **Category Suffixes** settings allow the administrator to set character limits and choose a suffix that indicates shortened text. For example, a limit of 100 characters and a suffix of `...` can produce a shortened description followed by an ellipsis.

The current configuration template contains the following pairs of settings:

| Content displayed | Character-limit setting | Suffix setting |
| --- | --- | --- |
| Category description | Max. Characters for Category Description | Category Description Suffix |
| Short category description | Maximum Characters for Short Category Description | Short Category Description Suffix |
| Category title in category view | Max. Characters for Category Title on Category View | Category Title Suffix |
| Product title in category view | Max. Characters for Product Title on Category View | Suffix for Product Title on Category View |
| Product description in category view | Max. Characters for Product Description on Category View | Suffix for Product Description on Category View |
| Short product description in category view | Max. Characters for Short Product Description on Category View | Suffix for Short Product Description on Category View |

For each pair, the character limit controls the length of the displayed text, while the suffix is the text appended when the output is shortened. Use short, recognizable suffixes such as `...` where appropriate.

These settings affect the presentation of text in layouts that use the corresponding configuration values. They do not replace the original title or description stored with the category or product. Check the storefront after adjusting them: a very short limit can cut words or make products difficult to identify.

## Category templates

![Default category templates](img/rs506-config-categories-templates.png)

redSHOP supports different templates for category displays. The configuration contains two distinct default selectors:

- **Default Category Template:** The template used for regular category pages unless a more specific setting overrides it.
- **Main Category List Template:** The template used for the main or top-level category listing.

Choose the appropriate template from the available options and save. An individual category may have its own template selection, which can take precedence over the global default. To change the structure of the page, edit or select the relevant redSHOP template rather than relying only on global configuration.

## Category image settings

![Category image settings](img/rs506-config-categories-images.png)

The original configuration guide describes the following image options:

- **Show Category Image in Lightbox:** Controls whether clicking the category image opens a larger image in a lightbox when supported by the active template. If disabled, the destination and behavior depend on the template.
- **Watermark Category Image:** Enables watermarking for category images where supported by the image-generation workflow.
- **Watermark Category Thumb Image:** Enables watermarking for category thumbnails where supported.

Watermarking requires an appropriate watermark image and compatible image processing. Check both the full-size image and thumbnail in the storefront after changing these options.

## Default images

![Category default images](img/rs506-config-categories-default-images.png)

Default images are fallbacks for products or categories that do not have their own image. The original redSHOP configuration guide includes:

- **Category Default Image:** Used when a category has no assigned image.
- **Product Default Image:** Used when a product has no assigned image.
- **Watermark:** The source image used when watermarking is enabled for a supported image type.
- **Product Out of Stock Image:** An image associated with out-of-stock presentation where supported by the storefront layout.

Use images that match the dimensions and appearance of your catalog. Upload the desired file, save the configuration, and inspect a category or product that uses the fallback. A watermark image is not automatically applied to every image simply because it has been uploaded; the relevant watermark settings must also be enabled.

## Recommended checks after saving

1. Open the main category listing and verify the default ordering and number of items per page.
2. Open a category containing long titles and descriptions and confirm that shortening and suffixes look appropriate.
3. Check a product page for any return, previous, or next links rendered by your template.
4. Verify the selected category templates, including any category-specific overrides.
5. Inspect category images, fallback images, thumbnails, and watermarks where used.

Changes to global configuration may not affect every page identically because menu items, category-specific settings, and custom templates can alter the final output.
