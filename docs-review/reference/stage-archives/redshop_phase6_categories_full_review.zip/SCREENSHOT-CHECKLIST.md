# Screenshot checklist — Category configuration

Capture these from a Joomla 5 administrator running the redSHOP 5.0.6 fork. Use the filenames exactly as referenced in `categories.md` and place the images in `manual/en-US/chapters/global-configuration/img/`.

1. `rs506-config-categories-overview.png` — Full Categories configuration section, including section headings.
2. `rs506-config-categories-main.png` — Default sorting, category count, discontinued message, front-page intro.
3. `rs506-config-categories-navigation.png` — Previous/next and return-link controls, **only if present** in current UI.
4. `rs506-config-categories-suffixes.png` — All character limits and suffix settings.
5. `rs506-config-categories-templates.png` — Default category and main category list template selectors.
6. `rs506-config-categories-images.png` — Lightbox and watermark controls, **only if present**.
7. `rs506-config-categories-default-images.png` — Category/product fallbacks, watermark and out-of-stock images, **only if present**.

If any legacy panel is missing, do not fabricate a screenshot. Mark it in the follow-up tracker so the corresponding paragraph can be revised after functional verification.
