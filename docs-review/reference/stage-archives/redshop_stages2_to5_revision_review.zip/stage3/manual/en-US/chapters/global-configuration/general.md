# General

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **General** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Store Settings

Review store name, contact and business address fields. These values may appear in emails, invoices and storefront templates.

## Modules and Features

Enable only installed and supported features. A visible configuration toggle does not guarantee the associated plugin or module is present.

## General Layout Settings

Check date/time presentation, display defaults and layout-related options. Verify the result in both administrator and frontend views.

## Validation workflow

Save a single changed field, reload the form, inspect the storefront and check customer-facing documents for the expected value.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_general.php`
- `component/admin/tmpl/configuration/default_modules.php`
- `component/admin/tmpl/configuration/default_general_layout_settings.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
