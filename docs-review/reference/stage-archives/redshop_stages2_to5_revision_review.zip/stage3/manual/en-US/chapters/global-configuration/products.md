# Products

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Products** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## General

Review default product display and catalogue settings, including products with variants and accessories.

## Unit Settings

Configure units used for weight, length and dimensions. Verify shipping calculations if carrier rules depend on these units.

## Download

Current code exposes `PRODUCT_DOWNLOAD_LIMIT`, `PRODUCT_DOWNLOAD_DAYS` and `PRODUCT_DOWNLOAD_ROOT`. The root is a filesystem path, not a public download URL. Test access control, path validation and expired links.

## Wrapping Management

Check whether gift wrapping is enabled and how prices, VAT and available choices are shown.

## Catalog Management and Samples

Historical settings cover catalogue mode and product samples. Verify installed modules and storefront workflows.

## Product Template and Image Settings

Check the product detail template and image dimensions. Regenerate or clear cached thumbnails where required.

## Accessory Products

Check accessory product selection, pricing and image dimensions. Test products with no accessories and several accessories.

## Related Products

Check related-product selection, layout and image sizes; verify that the display does not include unpublished products.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_producttab.php`
- `component/admin/tmpl/configuration/default_product_unit.php`
- `component/admin/tmpl/configuration/default_download.php`
- `component/admin/tmpl/configuration/default_wrapping.php`
- `component/admin/tmpl/configuration/default_catalog.php`
- `component/admin/tmpl/configuration/default_product_template_image_settings.php`
- `component/admin/tmpl/configuration/default_accessory_product.php`
- `component/admin/tmpl/configuration/default_related_product.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
