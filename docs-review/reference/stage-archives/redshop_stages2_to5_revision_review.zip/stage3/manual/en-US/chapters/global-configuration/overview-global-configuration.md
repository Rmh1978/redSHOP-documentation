# Global Configuration

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Global Configuration** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## What Global Configuration controls

Settings affect storefront behaviour, product display, registration, checkout, taxation, notifications, SEO and integrations. Changes should be tested as end-to-end workflows.

## Recommended change process

Record the old value, make one change, save, clear relevant caches, test as administrator and customer, and document the result.

## Navigation

The detailed tabs include General, User, Products, Price, Cart, Orders, Features, SEO, Integration and Dashboard. Additional tabs vary by build.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
