# User

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **User** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Registration

Review customer registration type, terms article, welcome and registration introduction text. Current source references `TERMS_ARTICLE_ID`, `WELCOMEPAGE_INTROTEXT`, `REGISTRATION_INTROTEXT` and `REGISTRATION_COMPANY_INTROTEXT`.

## Customer and company forms

Test individual and business registration separately. Required fields, email validation and account creation can differ.

## Shopper Groups

Review default shopper groups, pricing and visibility. Test a guest, a registered customer and a group with special pricing.

## Portal shop

The historical manual describes portal-shop behaviour; verify its current implementation and whether it changes product visibility or registration requirements.

## Security and privacy

Do not expose customer details across accounts. Verify that registration emails contain no reusable passwords.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_registration.php`
- `component/admin/tmpl/configuration/default_shopper_group.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
