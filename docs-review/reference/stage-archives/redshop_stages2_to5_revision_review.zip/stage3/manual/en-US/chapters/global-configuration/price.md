# Price

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Price** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Main Price Settings

The current source references `REDCURRENCY_SYMBOL`, `PRICE_SEPERATOR`, `THOUSAND_SEPERATOR`, `PRICE_DECIMAL`, `CALCULATION_PRICE_DECIMAL` and `ZERO_PRICE_REPLACE`. Distinguish display precision from calculation precision.

## VAT / Tax

Current code references `VAT_RATE_AFTER_DISCOUNT`, `VAT_INTROTEXT`, `WITH_VAT_TEXT_INFO` and `WITHOUT_VAT_TEXT_INFO`. Verify tax rules for customer location, shopper group and discounted items.

## Gift Card Image Settings

The original manual includes gift card image settings; test only if gift card functionality is enabled.

## Discount

Verify interaction between global, product, category and shopper-group discounts; avoid assuming stacking order.

## Discount Mail

Review triggers, recipient rules and templates before enabling customer-facing discount emails.

## Price regression tests

Compare base price, discounted price, shipping, VAT and final order total for a guest and a registered shopper.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_price.php`
- `component/admin/tmpl/configuration/default_vat.php`
- `component/admin/tmpl/configuration/default_discount.php`
- `component/admin/tmpl/configuration/default_discount_mail.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
