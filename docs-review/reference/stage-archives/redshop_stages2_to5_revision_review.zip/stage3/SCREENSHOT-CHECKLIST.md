# Screenshot checklist — stage 3

- [ ] `overview-global-configuration.md` — capture overview, each major group and one frontend example
- [ ] `general.md` — capture overview, each major group and one frontend example
- [ ] `user.md` — capture overview, each major group and one frontend example
- [ ] `products.md` — capture overview, each major group and one frontend example
- [ ] `price.md` — capture overview, each major group and one frontend example
