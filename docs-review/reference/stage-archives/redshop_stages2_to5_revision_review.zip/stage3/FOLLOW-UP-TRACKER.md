# Technical and publication follow-ups — stage 3

- [ ] `overview-global-configuration.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `general.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `user.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `products.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `price.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
