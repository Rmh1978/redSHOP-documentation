# Technical and publication follow-ups — stage 4

- [ ] `cart.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `orders.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `feature-settings.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
