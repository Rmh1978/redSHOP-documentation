# Feature Settings

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Feature Settings** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Rating

Check review display, moderation and customer eligibility. Current code references `RATING_MSG`, `FAVOURED_REVIEWS` and rating thumbnail dimensions.

## Comparison

Enable comparison only if the template supports it; test different product types.

## Inline Edit

Historical feature: verify permissions and CSRF behaviour before enabling in an administrator workflow.

## Wishlist

Test anonymous versus authenticated users, wishlist persistence and access controls.

## Import/Export

Review allowed formats, character encoding and permission checks; test imports against a database backup.

## Stockroom

Current source references stockroom image dimensions and `DEFAULT_STOCKROOM_BELOW_AMOUNT_NUMBER`; verify threshold and stock-status display.

## Feature dependency checklist

Check associated plugins, templates and modules for each feature rather than treating the global toggle as proof of functionality.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_rating_settings.php`
- `component/admin/tmpl/configuration/default_comparison_settings.php`
- `component/admin/tmpl/configuration/default_feature_inline_edit.php`
- `component/admin/tmpl/configuration/default_wishlist_settings.php`
- `component/admin/tmpl/configuration/default_feature_import_export.php`
- `component/admin/tmpl/configuration/default_stockroom_settings.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
