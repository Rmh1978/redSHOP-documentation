# Cart

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Cart** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Add To Cart Settings

Test button availability, minimum quantities, out-of-stock handling and feedback after adding an item.

## Cart Settings

Current code exposes `CART_TIMEOUT`, `AJAX_CART_DISPLAY_TIME`, `AJAX_DETAIL_BOX_WIDTH`, `AJAX_DETAIL_BOX_HEIGHT`, `AJAX_BOX_WIDTH`, `AJAX_BOX_HEIGHT`, `DEFAULT_QUANTITY`, `DEFAULT_QUANTITY_SELECTBOX_VALUE`, `CONTINUE_REDIRECT_LINK` and `MINIMUM_ORDER_TOTAL`.

## Payment

Check whether payment selection is required, and verify each active payment method with its own test credentials.

## Shipping

Review shipping-method requirements and stockroom/container dependencies. Digital-only shops may need different settings.

## Securing checkout

Confirm HTTPS, CSRF protection, checkout validation, session persistence and customer isolation. A configuration option is not a substitute for a security test.

## Cart Image Settings

Verify thumbnail sizes, aspect ratios and layout in cart, mini-cart and checkout.

## Preorders and quotations

Historical cart settings cover preorder messages, stockrooms and quotations. Verify interactions with actual stock counts.

## Regression checklist

Test guest and registered checkout, cart timeout, discounts, shipping, payment failure and retry.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_cart_settings.php`
- `component/admin/tmpl/configuration/default_payment_ship_secure.php`
- `component/admin/tmpl/configuration/default_cart_template_image_setting.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
