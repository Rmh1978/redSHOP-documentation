# Orders

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Orders** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Order Settings

Current source includes order mail timing, invoice mail enablement, invoice mail send option, customer mail and exclusion of products from reorder.

## Order ID reset

The current template includes `resetOrderId()` and a `configuration.resetOrderId` request. Do not run this on production without understanding ID generation and accounting dependencies.

## Invoice Settings

Current fields include `FIRST_INVOICE_NUMBER`, `INVOICE_NUMBER_TEMPLATE`, `REAL_INVOICE_NUMBER_TEMPLATE` and `INVOICE_NUMBER_FOR_FREE_ORDER`. Order numbers and invoice numbers are not interchangeable.

## Notification testing

Create a test order, change its status and verify the actual messages, recipients and timing. Prevent duplicate notifications.

## Invoice safety

Check sequence uniqueness, tax information, credit notes and local accounting requirements before changing invoice-number templates.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_ordertab.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
