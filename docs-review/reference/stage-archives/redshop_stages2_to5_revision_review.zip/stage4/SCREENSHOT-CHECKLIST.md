# Screenshot checklist — stage 4

- [ ] `cart.md` — capture overview, each major group and one frontend example
- [ ] `orders.md` — capture overview, each major group and one frontend example
- [ ] `feature-settings.md` — capture overview, each major group and one frontend example
