# Integration

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Integration** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Overview

The historical manual includes GLS, Clickatell, Pacsoft and e-conomic. Installed providers and supported API versions may differ.

## GLS

Check shipping credentials, labels, service selection and export mapping in a test environment.

## Clickatell

Review SMS credentials, sender identity, recipient opt-in and message costs. Do not send production SMS during testing.

## Pacsoft / PostNord

Verify current provider API and whether historical Pacsoft workflows have been replaced. Confirm pickup and shipment-label functionality.

## e-conomic

Review accounting credentials, VAT mapping, product/customer synchronization and idempotent invoice creation.

## Google Analytics

The historical introduction mentions analytics, but current tracking may be implemented by separate Joomla plugins. Check consent and avoid duplicate GA4 events.

## Integration test matrix

For each integration record authentication method, environment, event trigger, retry behaviour, logs, personal data shared and rollback.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_integration.php`
- `component/admin/tmpl/configuration/default_gls.php`
- `component/admin/tmpl/configuration/default_clicktell.php`
- `component/admin/tmpl/configuration/default_postdk.php`
- `component/admin/tmpl/configuration/default_economic.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
