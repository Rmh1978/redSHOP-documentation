# SEO

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **SEO** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## General

Review SEF routing, language handling and Joomla menu item aliases. Current code exposes default menu aliases and ItemIDs for account, cart, checkout, gift card, manufacturers, orders, quotations, registration and wishlist.

## Category

Configure category metadata and hierarchy-aware URLs. Test nested categories and language variants.

## Products

Current fields `SEO_PAGE_TITLE`, `SEO_PAGE_HEADING`, `SEO_PAGE_DESCRIPTION` and `SEO_PAGE_KEYWORDS` support template-driven metadata. Verify available placeholders before using them.

## Manufacturer

Check manufacturer-specific titles, descriptions and routes.

## Available SEO Tags

The original manual groups placeholders for page titles, headings, descriptions and keywords. Their actual parser support must be checked in the current code before documenting an exhaustive list.

## Canonical and duplicate URLs

Test product URLs reached from multiple categories, pagination, language prefixes and Joomla menu items; avoid duplicate indexed pages.

## Regression checklist

Inspect HTML title, meta description, heading, canonical, hreflang and redirects on a test product, category and manufacturer.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_seo_general.php`
- `component/admin/tmpl/configuration/default_seo_category.php`
- `component/admin/tmpl/configuration/default_seo_product.php`
- `component/admin/tmpl/configuration/default_seo_manufacturer.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
