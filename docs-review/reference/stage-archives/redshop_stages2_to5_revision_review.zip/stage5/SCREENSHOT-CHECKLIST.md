# Screenshot checklist — stage 5

- [ ] `seo.md` — capture overview, each major group and one frontend example
- [ ] `integration.md` — capture overview, each major group and one frontend example
- [ ] `dashboard.md` — capture overview, each major group and one frontend example
