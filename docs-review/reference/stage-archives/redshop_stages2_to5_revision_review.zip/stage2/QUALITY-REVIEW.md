# Stage 2 — revision status

3 English articles revised with original section coverage, examples, code-file anchors and test workflows.

**Not publication-ready:** historical detail and field-by-field original comparison remain incomplete; code execution and screenshots have not been verified. No GitHub changes.
