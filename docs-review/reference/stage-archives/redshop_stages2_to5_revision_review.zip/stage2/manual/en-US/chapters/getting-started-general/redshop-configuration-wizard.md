# Configuration Wizard

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Configuration Wizard** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Access and preparation

Launch from the post-install screen, the redSHOP dashboard, or the configuration start area. Back up configuration and use a test shop before changing tax, currency or customer settings.

## Step 1 — Welcome

Review the six-step workflow and continue. The wizard is designed for initial setup; it is not a substitute for auditing all Global Configuration settings.

## Step 2 — General settings

Enter store identity, address, contact information and shipping countries. Confirm that the country choices correspond to supported shipping methods.

## Step 3 — Terms and Conditions

Choose the terms article and verify that the frontend checkout displays the correct language and requires acceptance where applicable.

## Step 4 — User settings

Review registration, account type and shopper group defaults. Test both new and existing customer checkout paths.

## Step 5 — Price settings

Review currency, tax rules and discounts. Test a taxable product, a discounted product and a shipping charge to detect rounding or VAT differences.

## Step 6 — Finish

Save, inspect the resulting configuration and test a complete order. Confirm each setting actually persists after the wizard closes.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/wizard/default.php`
- `component/admin/tmpl/wizard/general.php`
- `component/admin/tmpl/wizard/terms.php`
- `component/admin/tmpl/wizard/user.php`
- `component/admin/tmpl/wizard/price.php`
- `component/admin/tmpl/wizard/finish.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
