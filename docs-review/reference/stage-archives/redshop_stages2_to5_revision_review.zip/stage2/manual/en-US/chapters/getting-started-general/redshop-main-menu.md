# Main Menu

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Main Menu** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Purpose

The main menu is the administrative hub, not a complete listing of every redSHOP function. The navigation panel exposes more detailed views.

## Product Management

Use this area to manage products, categories, manufacturers, media and product pricing. Check the active menu before documenting individual links.

## Orders

Access orders, quotations and fulfilment-related tools. Payment status and order status are separate.

## Discount and Communication

Historical groups include vouchers, coupons, gift cards, Mail Center and newsletters. These may depend on enabled extensions.

## Shipping, User, Tax and Currency

Configure shipping methods, customers and shopper groups, VAT rules, currencies, countries, states and postal codes.

## Import/Export, Customization and Customer Input

Historical groups include XML import/export, custom fields, templates, text library, product samples, questions and reviews.

## Accounting, Statistics and Configuration

Review accounting integrations, reports, dashboard links and global configuration. Disable or hide obsolete dashboard shortcuts rather than assuming the underlying feature is removed.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_dashboard.php`
- `component/admin/tmpl/configuration/default_menuhide.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
