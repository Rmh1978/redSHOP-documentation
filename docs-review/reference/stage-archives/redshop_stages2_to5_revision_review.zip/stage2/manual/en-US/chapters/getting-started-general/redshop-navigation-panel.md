# Navigation Panel

> **Documentation review:** Confirmed source fields are identified explicitly. Historical UI workflows are retained but must be verified on a current test installation.

## Purpose and prerequisites

This guide covers the **Navigation Panel** area in redSHOP. Before making changes, use a separate Joomla test site, record current values and check administrator permissions.

## Navigation model

Use the sidebar for detailed views. Its availability can depend on permissions, configuration and installed plugins.

## Products and catalogue

Products, Categories, Manufacturers and Media are distinct administration views.

## Orders and stock

Orders, Quotations, Stockrooms, Containers and Delivery Lists were documented historically; verify each view in the current installation.

## Promotions and communication

Discount, Gift Card, Voucher, Coupon, Mail Center and Newsletter are historically documented.

## Shipping and users

Shipping Method, Shipping Box, Shipping Detail, Wrapping Management, Users and Backend Access Management.

## VAT, countries and import

VAT/Tax Group, Currency, Country, State, Zipcode, Import/Export and XML Import/Export.

## Customization and customer input

Custom Fields, Templates, Text Library, Catalog Management, Product Sample, Customer Tags, Attribute Bank, Questions and Reviews.

## Accounting, statistics and configuration

Accounting integration and statistics depend on configured providers. Use Configuration to manage shop-wide defaults.

## Practical verification

1. Record the current settings and the intended outcome.
2. Make one controlled change and save.
3. Reload the administrator page to confirm persistence.
4. Test the affected frontend or order workflow with a test account.
5. Inspect logs, emails, calculated totals and integration effects where relevant.
6. Restore the previous setting if the test fails.

## Source-code reference

Current `develop` branch files used as verification anchors:

- `component/admin/tmpl/configuration/default_menuhide.php`

**Verification boundary:** File presence and selected fields were inspected. The complete runtime behaviour and historical UI actions have not been tested.
