# Screenshot checklist — stage 2

- [ ] `redshop-configuration-wizard.md` — capture overview, each major group and one frontend example
- [ ] `redshop-main-menu.md` — capture overview, each major group and one frontend example
- [ ] `redshop-navigation-panel.md` — capture overview, each major group and one frontend example
