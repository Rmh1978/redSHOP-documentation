# Technical and publication follow-ups — stage 2

- [ ] `redshop-configuration-wizard.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `redshop-main-menu.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
- [ ] `redshop-navigation-panel.md` — original-content field-by-field comparison, exact labels, live test, internal links, screenshots
