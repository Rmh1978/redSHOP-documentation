# Users

Manage customer accounts, billing and shipping addresses, and shopper groups.

- [User Management](user-management.md)
- [Add User](add-user.md)
- [Shopper Groups](shopper-groups.md)

The administrator user editor and shopper-group form are separate workflows. Test private and company accounts, account restrictions and group-specific prices before using these settings in production.
