# Add User

> Review draft for redSHOP on Joomla 5/6. The original manual field coverage below is preserved for verification; source presence does not prove runtime behaviour.

## Purpose and navigation

Open the redSHOP administrator and locate **Users**. Select the appropriate user or shopper-group management view. The exact menu label and permissions depend on the installed version and administrator ACL.

## Historical field reference

| Original manual field | What to verify |
|---|---|
| User name | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| New Password | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Confirm New Password | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Email | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper Groups | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Group | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Block User | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Registered as | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Receive System Email | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| First Name | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Last Name | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Address | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| City | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Country | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| State | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Phone | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Zipcode | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Company name | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| EAN Number | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| VAT Number | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Tax Exempt | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| User requested VAT exempt | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Tax Exempt Approved | Confirm current label, allowed values, persistence and effect on frontend or checkout |

## Original manual workflows retained for review

1. **General User Information:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
2. **Billing Information:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
3. **Private Customer:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
4. **Company Customer:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
5. **Create User on frontend:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
6. **Account Management on Frontend:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
7. **Edit Account Information:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
8. **Add/Edit address:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.

## Source verification

The current user editor has separate templates `edit_user.php`, `edit_billing.php`, `edit_shipping.php`, `edit_extrafield.php` and `edit_order.php`. `edit_user.php` includes username, password, confirmation and email inputs. `edit_billing.php` includes company, VAT/EAN, tax-exemption, customer-type and shopper-group controls. Shipping addresses are rendered separately. Do not treat a missing field in one subtemplate as removal from the whole editor.

## Test scenarios

1. Create a private customer using a test email and confirm the expected shopper group.
2. Create a company customer and verify company-specific VAT/EAN fields and tax exemption approval.
3. Edit billing and shipping addresses separately; verify the checkout result.
4. Check administrator ACL and direct URL access with a restricted account.
5. Verify save errors, duplicate email/username validation and password handling without exposing credentials.

## Screenshots required

- Administrator list and filters
- Edit form with each tab
- Frontend registration and account edit
- Relevant checkout result

## Known limits

No changes have been made to the test installation; actual frontend flows, password security and data persistence are **not certified** by this documentation draft.
