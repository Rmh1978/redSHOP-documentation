# User Management

> Review draft for redSHOP on Joomla 5/6. The original manual field coverage below is preserved for verification; source presence does not prove runtime behaviour.

## Purpose and navigation

Open the redSHOP administrator and locate **Users**. Select the appropriate user or shopper-group management view. The exact menu label and permissions depend on the installed version and administrator ACL.

## Historical field reference

| Original manual field | What to verify |
|---|---|
| First Name | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Last Name | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Registered as | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| User name | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper Group Name | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Customer Sales | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Search field | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Filter | Confirm current label, allowed values, persistence and effect on frontend or checkout |

## Original manual workflows retained for review

1. **User list:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
2. **New:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
3. **Edit:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
4. **Delete:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.

## Source verification

The current repository contains `component/admin/tmpl/users/default.php` and `component/admin/tmpl/user/edit.php`. The listing columns, filters and bulk actions still require direct template and staging verification.

## Test scenarios

1. Create a private customer using a test email and confirm the expected shopper group.
2. Create a company customer and verify company-specific VAT/EAN fields and tax exemption approval.
3. Edit billing and shipping addresses separately; verify the checkout result.
4. Check administrator ACL and direct URL access with a restricted account.
5. Verify save errors, duplicate email/username validation and password handling without exposing credentials.

## Screenshots required

- Administrator list and filters
- Edit form with each tab
- Frontend registration and account edit
- Relevant checkout result

## Known limits

No changes have been made to the test installation; actual frontend flows, password security and data persistence are **not certified** by this documentation draft.
