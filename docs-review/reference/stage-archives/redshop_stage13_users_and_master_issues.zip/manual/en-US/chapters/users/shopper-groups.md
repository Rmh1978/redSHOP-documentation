# Shopper Groups

> Review draft for redSHOP on Joomla 5/6. The original manual field coverage below is preserved for verification; source presence does not prove runtime behaviour.

## Purpose and navigation

Open the redSHOP administrator and locate **Users**. Select the appropriate user or shopper-group management view. The exact menu label and permissions depend on the installed version and administrator ACL.

## Historical field reference

| Original manual field | What to verify |
|---|---|
| Shopper Group Name | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Discount | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Published | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper Group Type | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper Group Customer Type | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper Group Portal | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper Group Category | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper Group Manufacturer | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper Group URL | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Choose Default Shipping Rate | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper group cart item ID override | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Use Default Shipping | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Default Shopper Group Checkout Item ID | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Show Price Without VAT / Tax | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Show Price | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Use as catalogue | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Quotation Mode | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper Group Logo | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper Group Intro text | Confirm current label, allowed values, persistence and effect on frontend or checkout |
| Shopper Group Description | Confirm current label, allowed values, persistence and effect on frontend or checkout |

## Original manual workflows retained for review

1. **Management list:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
2. **Edit shopper group:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
3. **Create shopper group:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.
4. **Add Discount:** open the relevant administrator or frontend screen, inspect its fields, save with a test record and verify the result. Recheck the original screenshots and steps before publication.

## Source verification

The current `component/admin/forms/shoppergroup.xml` defines `name`, `add_discount`, `parent_id`, `customer_type`, `portal`, `categories`, `manufactures`, `url`, `default_shipping`, `default_shipping_rate`, `show_price_without_vat`, `show_price`, `use_as_catalog`, `quotation_mode`, `published`, `logo`, `shopper_group_seo`, `cart_itemid`, `checkout_itemid`, `introtext` and `desc` (plus structural fields). These fields are **confirmed in the form XML**, but the shopper-group pricing, ACL and checkout effects are not yet tested.

## Test scenarios

1. Create a private customer using a test email and confirm the expected shopper group.
2. Create a company customer and verify company-specific VAT/EAN fields and tax exemption approval.
3. Edit billing and shipping addresses separately; verify the checkout result.
4. Check administrator ACL and direct URL access with a restricted account.
5. Verify save errors, duplicate email/username validation and password handling without exposing credentials.

## Screenshots required

- Administrator list and filters
- Edit form with each tab
- Frontend registration and account edit
- Relevant checkout result

## Known limits

No changes have been made to the test installation; actual frontend flows, password security and data persistence are **not certified** by this documentation draft.
