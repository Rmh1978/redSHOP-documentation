# Stage 13 — Users

Four English review drafts created from historical article headings and field inventory. Source-verified current shopper-group XML and user editor subtemplates. Frontend registration, user management, account editing, ACL and tax-exemption workflows need staging tests. **Not approved for publication.**

The shared issue register is consolidated from available earlier files, with source provenance; no tasks have been silently closed.
