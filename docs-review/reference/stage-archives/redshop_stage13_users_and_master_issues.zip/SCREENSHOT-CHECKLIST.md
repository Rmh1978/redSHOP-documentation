# Users screenshot checklist

- [ ] Users list and search/filter
- [ ] Private customer editor
- [ ] Company customer VAT/EAN fields
- [ ] Billing and shipping tabs
- [ ] Shopper-group form
- [ ] Frontend registration and account editing
