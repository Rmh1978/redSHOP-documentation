# Customer Input screenshots

- [ ] Questions administrator list
- [ ] Question edit form
- [ ] Frontend question submission and published answer
- [ ] Ratings administrator list
- [ ] Rating edit form
- [ ] Frontend rating submission and product display
