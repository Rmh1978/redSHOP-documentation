# Customer Input

redSHOP provides [Questions](questions.md) and [Rating/Review](rating-review.md) features.

Before enabling frontend submission, verify administrator moderation, privacy of customer details, spam controls, and safe rendering of comments and answers.

**Status:** Review draft; runtime behaviour and screenshots still require validation.
