# Questions

> **Review draft.** The original manual is the authoritative detailed source until its screenshots and procedures have been compared line by line. Current field names below are verified against `develop`.

## Scope

Customer input can be entered or managed from the administrator and, where enabled, from the storefront. Publication and moderation must be verified before accepting public submissions.

## Historical manual field inventory

| Field | Validation required |
|---|---|
| Order icon | Verify current UI, storage, display and permissions |
| Published | Verify current UI, storage, display and permissions |
| Question | Verify current UI, storage, display and permissions |
| Product name | Verify current UI, storage, display and permissions |
| Answer | Verify current UI, storage, display and permissions |
| User name | Verify current UI, storage, display and permissions |
| Email | Verify current UI, storage, display and permissions |
| User phone | Verify current UI, storage, display and permissions |
| User Address | Verify current UI, storage, display and permissions |

## Current XML form fields

`id`, `product_id`, `user_name`, `user_email`, `telephone`, `address`, `published`, `question`, `answer`.

The current form declares `user_name` and `user_email` as hidden fields. Confirm where these values originate and whether administrators can edit them.

## Original workflows to verify

1. Create a question in the administrator for a test product.
2. Create a question on the storefront using a test account.
3. Confirm publication and the visibility of the answer.
4. Check display type and permissions for guests and registered users.
5. Verify editing, moderation and deletion.

## Administrator actions

The historical guide describes list and detail views with New, Edit, Delete, Publish/Unpublish, Save & Close and Cancel where applicable. Verify the current toolbar and role permissions.

## Security and quality checks

- Check CSRF and authorization for frontend submissions.
- Escape user-provided text to prevent HTML/script injection.
- Verify spam prevention, rate limiting and duplicate-submission controls.
- Ensure private email, phone and address fields are not inadvertently published.
- Test notifications, moderation, deletion and data-retention behaviour.
- Check Joomla 5/6 compatibility without relying on deprecated APIs.

## Screenshots to replace

- Administrator list and edit screen
- Frontend submission form
- Published result and moderation state

## Source references

- Historical guide: `manual/en-US/chapters/customer-input/questions.md` (`gh-pages`)
- Current form: `component/admin/forms/question.xml` (`develop`)
