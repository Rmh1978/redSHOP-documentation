# Rating/Review

> **Review draft.** The original manual is the authoritative detailed source until its screenshots and procedures have been compared line by line. Current field names below are verified against `develop`.

## Scope

Customer input can be entered or managed from the administrator and, where enabled, from the storefront. Publication and moderation must be verified before accepting public submissions.

## Historical manual field inventory

| Field | Validation required |
|---|---|
| Title | Verify current UI, storage, display and permissions |
| Name | Verify current UI, storage, display and permissions |
| Author’s Name | Verify current UI, storage, display and permissions |
| Date | Verify current UI, storage, display and permissions |
| Rating | Verify current UI, storage, display and permissions |
| Favoured | Verify current UI, storage, display and permissions |
| Published | Verify current UI, storage, display and permissions |
| Comment | Verify current UI, storage, display and permissions |
| User | Verify current UI, storage, display and permissions |
| Product | Verify current UI, storage, display and permissions |

## Current XML form fields

`id`, `email`, `company_name`, `images`, `title`, `comment`, `product_id`, `userid`, `time`, `user_rating`, `favoured`, `published`.

The current form includes hidden `email`, `company_name` and `images` fields, and uses `user_rating` for stars. Confirm whether attachments and company attribution are actually supported.

## Original workflows to verify

1. Create a test rating in the administrator.
2. Submit a rating from the storefront as a test user.
3. Verify star rating, comment, product association and publication state.
4. Test moderation, duplicate submissions and guest access.
5. Check whether aggregate product ratings update correctly.

## Administrator actions

The historical guide describes list and detail views with New, Edit, Delete, Publish/Unpublish, Save & Close and Cancel where applicable. Verify the current toolbar and role permissions.

## Security and quality checks

- Check CSRF and authorization for frontend submissions.
- Escape user-provided text to prevent HTML/script injection.
- Verify spam prevention, rate limiting and duplicate-submission controls.
- Ensure private email, phone and address fields are not inadvertently published.
- Test notifications, moderation, deletion and data-retention behaviour.
- Check Joomla 5/6 compatibility without relying on deprecated APIs.

## Screenshots to replace

- Administrator list and edit screen
- Frontend submission form
- Published result and moderation state

## Source references

- Historical guide: `manual/en-US/chapters/customer-input/rating-review.md` (`gh-pages`)
- Current form: `component/admin/forms/rating.xml` (`develop`)
