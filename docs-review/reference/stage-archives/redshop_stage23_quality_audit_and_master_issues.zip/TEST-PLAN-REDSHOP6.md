# Test plan — independent redSHOP6 installation

Target: `https://www.print.dk/tests/redshop6` (reported separate database). **No tests executed during stage 23.**

## Preconditions

- [ ] Record Joomla/PHP/redSHOP versions and Git commit
- [ ] Back up test site and database; confirm test mail delivery only
- [ ] Disable live payment captures, live invoice posting and production notifications
- [ ] Confirm test users and representative products/orders

## Acceptance suites

- [ ] Administrator navigation, ACL and save/cancel flows
- [ ] Products, variants, attributes, categories, images and stock
- [ ] Frontend add-to-cart, validation, customer registration and checkout
- [ ] Discounts, vouchers, gift cards and tax calculations
- [ ] Shipping zones, rates, pickup points and edge cases
- [ ] Upload preflight, MIME checks, permissions, cleanup and invalid files
- [ ] Customer reviews/questions, moderation and privacy
- [ ] Import/export on test data with backup/rollback
- [ ] Release update process and documentation links
- [ ] Joomla 6 installation/upgrade on separate disposable test environment

## Evidence template

Issue ID | Commit | Environment | Steps | Expected | Actual | Screenshot/log | Result | Reviewer

Results must not be marked PASS until reproduced and recorded.
